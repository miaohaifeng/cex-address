# 🚀 每日一键运行工作流程

## 🎯 概述

现在你只需要运行**一个脚本**，就能自动完成所有工作：
1. **收集交易所地址** - 从OKLink获取最新数据
2. **生成数据文件** - 保存到日期文件夹
3. **增量导入Supabase** - 自动跳过重复数据

## 📁 文件结构

```
scripts/
├── daily-run.sh                    # 🎯 每日一键运行脚本（主要使用）
├── schedule-import.sh              # 仅导入脚本（备用）
└── crontab-example.txt            # 定时任务配置示例

src/
├── ultimate-address-collector.js   # 主收集器（已集成增量导入）
└── production-import-addresses.js  # 独立导入脚本（备用）

docs/
└── PRODUCTION_IMPORT_GUIDE.md     # 详细技术文档
```

## 🚀 使用方法

### 方法1：每日手动运行（推荐）

```bash
# 给脚本添加执行权限（只需一次）
chmod +x scripts/daily-run.sh

# 每天运行一次
./scripts/daily-run.sh
```

### 方法2：配置定时任务

```bash
# 编辑crontab
crontab -e

# 添加以下配置（每天凌晨2点运行）
0 2 * * * cd /path/to/your/project && ./scripts/daily-run.sh >> logs/daily-run.log 2>&1
```

## 📊 工作流程详解

### 第一步：地址收集
- 自动获取API密钥
- 收集CEX列表
- 获取每个CEX的链支持信息
- 收集详细地址数据
- 生成汇总报告

### 第二步：文件生成
- 创建日期文件夹（如：`output/20250817/`）
- 生成各种格式的JSON文件
- 包含去重后的地址统计

### 第三步：Supabase导入
- **自动增量导入**：只插入新记录
- **智能查重**：跳过已存在的记录
- **批量处理**：优化性能和稳定性
- **详细报告**：显示导入统计

## 🎉 主要优势

### ✅ 完全自动化
- 一键运行，无需手动干预
- 自动处理所有步骤
- 智能错误处理和重试

### ✅ 增量导入
- 第一次运行：导入所有数据
- 后续运行：只导入新增数据
- 大幅提升效率（通常90%+跳过）

### ✅ 完整监控
- 实时进度显示
- 详细统计报告
- 任务完成状态

### ✅ 生产就绪
- 智能延迟策略
- 内存优化
- 错误恢复机制

## 📈 性能表现

### 典型运行时间
- **第一次运行**：30-60分钟（取决于数据量）
- **后续运行**：5-15分钟（只处理新数据）

### 数据跳过率
- **第一天**：0%（全部导入）
- **第二天**：90-95%（大部分跳过）
- **第三天**：95-98%（几乎全部跳过）

### 资源使用
- **内存**：智能分批加载
- **网络**：优化请求频率
- **存储**：增量更新，不重复

## 🔧 配置要求

### 必需配置
```javascript
// config.js
supabase: {
  url: 'your-supabase-url',
  serviceRoleKey: 'your-service-role-key',
  table: 'cex-address'
}
```

### 可选配置
```javascript
// 批次大小
batchSize: 1000,

// 延迟策略
baseDelay: 100,
```

## 📋 输出文件

### 每次运行生成
```
output/20250817/
├── cex_list.json                    # CEX列表
├── binance_chain_support_token.json # 各CEX链支持
├── binance_addresses.json           # 各CEX地址
├── cex_addresses_summary.json       # 地址汇总
├── cex_addresses_standard.json      # 标准格式
├── import_report_2025-08-17.json   # 导入报告
└── daily_task_completion.json       # 任务完成报告
```

## 🚨 故障排除

### 常见问题

#### 1. 脚本权限问题
```bash
chmod +x scripts/daily-run.sh
```

#### 2. Supabase连接失败
```bash
# 检查配置
node src/test-supabase-connection.js
```

#### 3. 内存不足
```bash
# 减少批次大小
# 编辑 src/ultimate-address-collector.js
this.batchSize = 500; // 从1000减少到500
```

#### 4. 导入失败
```bash
# 检查数据库约束
# 确保唯一约束正确设置
```

### 日志查看
```bash
# 查看运行日志
tail -f logs/daily-run.log

# 查看导入报告
cat output/20250817/import_report_2025-08-17.json
```

## 🔄 维护建议

### 定期检查
- 监控导入成功率
- 检查数据完整性
- 清理旧日志文件

### 性能优化
- 根据服务器性能调整批次大小
- 监控内存和网络使用
- 优化延迟策略

### 备份策略
- 定期备份Supabase数据
- 保存重要的JSON文件
- 记录配置变更

## 📞 技术支持

如果遇到问题，请检查：
1. 配置文件是否正确
2. 网络连接是否稳定
3. 数据库权限是否足够
4. 错误日志详情

## 🎯 总结

现在你只需要：
1. **每天运行一次**：`./scripts/daily-run.sh`
2. **等待完成**：脚本会自动处理一切
3. **查看结果**：检查生成的文件和报告

就是这么简单！🎉
