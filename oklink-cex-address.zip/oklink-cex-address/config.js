import dotenv from 'dotenv';
dotenv.config();

export default {
  browser: {
    headless: true,
    executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--disable-accelerated-2d-canvas',
      '--no-first-run',
      '--no-zygote',
      '--disable-gpu'
    ]
  },
  api: {
    baseURL: 'https://www.oklink.com/api/explorer/v2/por',
    timeout: 30000,
    maxRetries: 3
  },
  headers: {
    'accept': 'application/json',
    'accept-language': 'en,zh-CN;q=0.9,zh;q=0.8',
    'app-type': 'web',
    'priority': 'u=1, i',
    'referer': 'https://www.oklink.com/zh-hans/cex-list',
    'sec-ch-ua': '"Not;A=Brand";v="99", "Google Chrome";v="139", "Chromium";v="139"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"macOS"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36',
    'x-cdn': 'https://static.oklink.com',
    'x-locale': 'zh_CN',
    'x-simulated-trading': 'undefined',
    'x-site-info': '9FjOikHdpRnblJCLiskTJx0SPJiOiUGZvNmIsIySIJiOi42bpdWZyJye',
    'x-utc': '8',
    'x-zkdex-env': '0'
  },
  rateLimit: {
    baseDelay: {
      default: 1000,
      BTC: 800,
      ETH: 1000,
      BSC: 1200,
      SOLANA: 1000,
      TRON: 1000,
      RIPPLE: 800,
      BASE: 1000,
      SUI: 1200,
      APT: 1200,
      ARBITRUM: 1000,
      OPTIMISM: 1000,
      POLYGON: 1000,
      AVAXC: 1000,
      ZKSYNC: 1000,
      UNI: 1000,
      TON: 1200,
      BITLAYER: 800,
      LINEA: 1000,
      SCROLL: 1000,
      STARKNET: 1200,
      FTM: 1000,
      COSMOS: 1200,
      RONIN: 1000,
      OKEXCHAIN: 1000,
      ETC: 800,
      BEACON: 1000,
      DOGE: 800,
      LTC: 800,
      BCH: 800,
      DASH: 800,
      X1: 1000
    },
    cexDelay: {
      default: 2000,
      binance: 1500,
      kraken: 2000,
      okx: 1500,
      bybit: 1800,
      bitfinex: 2000,
      bitget: 1800,
      htx: 1800,
      kucoin: 1800,
      'crypto.com': 2000,
      'gate.io': 2000,
      deribit: 2500
    },
    batchDelay: {
      every10Requests: 200,
      every50Requests: 500,
      every100Requests: 1000
    },
    randomFactor: {
      min: 0.8,
      max: 1.2
    },
    retryDelay: {
      default: 2000,
      RATE_LIMIT: 5000,
      INVALID_PARAM: 1000
    }
  },
  output: {
    basePath: './output',
    dateFormat: 'YYYYMMDD',
    createDateFolders: true,
    overwriteExisting: true,
    saveCEXList: true
  },
  supabase: {
    
  }
};
