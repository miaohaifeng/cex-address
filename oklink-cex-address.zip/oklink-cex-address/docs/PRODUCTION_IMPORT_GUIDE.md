# 生产环境地址数据导入指南

## 🎯 概述

本指南介绍如何在生产环境中使用优化的地址数据导入脚本，实现增量导入，避免重复数据插入。

## 🚀 主要特性

### ✅ 增量导入
- 自动检测数据库中已存在的记录
- 只插入新记录，跳过重复数据
- 大幅提升导入效率

### ✅ 智能优化
- 内存缓存现有记录
- 智能批次大小和延迟策略
- 生产环境性能优化

### ✅ 完整监控
- 详细的导入统计
- 性能指标监控
- 导入报告生成

## 📁 文件结构

```
src/
├── production-import-addresses.js    # 生产环境导入脚本
scripts/
├── schedule-import.sh                # 定时导入脚本
├── crontab-example.txt              # crontab配置示例
docs/
└── PRODUCTION_IMPORT_GUIDE.md       # 本指南
```

## 🔧 使用方法

### 1. 手动导入

```bash
# 导入最新日期的数据
node src/production-import-addresses.js

# 导入指定日期的数据
node src/production-import-addresses.js 20250817
```

### 2. 定时导入

```bash
# 给脚本添加执行权限
chmod +x scripts/schedule-import.sh

# 手动运行定时脚本
./scripts/schedule-import.sh

# 运行指定日期的导入
./scripts/schedule-import.sh 20250817
```

### 3. 配置crontab

```bash
# 编辑crontab
crontab -e

# 添加以下配置（每天凌晨2点运行）
0 2 * * * cd /path/to/your/project && ./scripts/schedule-import.sh >> logs/import.log 2>&1
```

## 📊 导入流程

### 第一步：加载现有记录
- 从数据库分批加载所有现有记录
- 构建内存缓存，用于快速查重
- 显示加载进度和耗时

### 第二步：确定导入文件
- 自动选择最新日期文件夹
- 或使用命令行参数指定日期
- 验证目标文件存在性

### 第三步：增量过滤
- 遍历JSON文件中的所有记录
- 与内存缓存对比，识别新记录
- 统计新记录和跳过记录数量

### 第四步：批量导入
- 将新记录分批处理
- 使用Supabase的ignoreDuplicates选项
- 智能延迟策略，避免被限流

### 第五步：验证和报告
- 验证数据库记录总数
- 按CEX统计记录分布
- 生成详细的导入报告

## 🎛️ 配置参数

### 批次大小
```javascript
this.batchSize = 1000; // 每批处理1000条记录
```

### 延迟策略
```javascript
// 基础延迟
let baseDelay = 100; // 100ms

// 根据批次数量调整
if (totalBatches > 50) {
  baseDelay = 150;
} else if (totalBatches > 20) {
  baseDelay = 120;
}

// 进度因子
if (progressFactor > 0.8) {
  baseDelay = Math.floor(baseDelay * 1.5);
}
```

## 📈 性能指标

### 导入效率
- **新记录比例**: 显示新增记录占总处理记录的比例
- **跳过率**: 显示被跳过的重复记录比例
- **处理速度**: 每秒处理的记录数量

### 资源使用
- **内存使用**: 现有记录缓存大小
- **网络请求**: 数据库查询和插入次数
- **处理时间**: 各步骤的耗时统计

## 🔍 监控和日志

### 导入报告
每次导入完成后，会在目标文件夹中生成导入报告：
```json
{
  "importDate": "2025-08-17",
  "dateFolder": "20250817",
  "timestamp": "2025-08-17T10:30:00.000Z",
  "summary": {
    "totalProcessed": 62874,
    "totalSuccess": 60723,
    "totalSkipped": 2151,
    "totalNew": 60723,
    "existingRecords": 1000
  },
  "performance": {
    "newRecordsPercentage": "96.58",
    "skipRate": "3.42"
  }
}
```

### 日志文件
如果使用crontab，日志会写入到 `logs/import.log` 文件中。

## ⚠️ 注意事项

### 1. 数据库连接
- 确保Supabase连接稳定
- 监控连接池使用情况
- 避免长时间占用连接

### 2. 内存使用
- 现有记录会加载到内存中
- 对于超大数据集，考虑分批加载
- 监控内存使用情况

### 3. 错误处理
- 任何批次失败都会停止整个导入
- 检查错误日志，修复问题后重新运行
- 考虑添加重试机制

### 4. 性能优化
- 根据数据库性能调整批次大小
- 监控导入速度，调整延迟策略
- 避免在业务高峰期运行

## 🚨 故障排除

### 常见问题

#### 1. 导入失败
```bash
# 检查数据库连接
node src/test-supabase-connection.js

# 检查文件是否存在
ls -la output/20250817/
```

#### 2. 内存不足
```bash
# 减少批次大小
# 编辑 src/production-import-addresses.js
this.batchSize = 500; // 从1000减少到500
```

#### 3. 导入速度慢
```bash
# 减少延迟时间
# 编辑 calculateOptimalDelay 方法
let baseDelay = 50; // 从100减少到50
```

#### 4. 重复数据问题
```bash
# 检查数据库约束
# 确保唯一约束正确设置
```

## 📞 技术支持

如果遇到问题，请检查：
1. 数据库连接状态
2. 文件权限和路径
3. 内存使用情况
4. 网络连接状态
5. 错误日志详情

## 🔄 更新和维护

### 定期维护
- 监控导入性能指标
- 清理旧的日志文件
- 更新依赖包版本
- 优化配置参数

### 版本更新
- 备份当前配置
- 测试新版本功能
- 逐步部署到生产环境
- 监控系统稳定性
