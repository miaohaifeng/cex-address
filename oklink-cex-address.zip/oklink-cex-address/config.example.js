import dotenv from 'dotenv';
dotenv.config();

export default {
  browser: {
    headless: true,
    executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--disable-accelerated-2d-canvas',
      '--no-first-run',
      '--no-zygote',
      '--disable-gpu'
    ]
  },
  api: {
    baseURL: 'https://www.oklink.com/api/explorer/v2/por',
    timeout: 30000,
    maxRetries: 3
  },
  headers: {
    'accept': 'application/json',
    'accept-language': 'en,zh-CN;q=0.9,zh;q=0.8',
    'app-type': 'web',
    'priority': 'u=1, i',
    'referer': 'https://www.oklink.com/zh-hans/cex-list',
    'sec-ch-ua': '"Not;A=Brand";v="99", "Google Chrome";v="139", "Chromium";v="139"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"macOS"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36',
    'x-cdn': 'https://static.oklink.com',
    'x-locale': 'zh_CN',
    'x-simulated-trading': 'undefined',
    'x-site-info': '9FjOikHdpRnblJCLiskTJx0SPJiOiUGZvNmIsIySIJiOi42bpdWZyJye',
    'x-utc': '8',
    'x-zkdex-env': '0'
  },
  rateLimit: {
    baseDelay: 1000,
    cexDelay: 2000,
    batchDelay: 500,
    randomFactor: 0.3,
    retryDelay: {
      default: 2000,
      RATE_LIMIT: 5000,
      INVALID_PARAM: 1000
    }
  },
  output: {
    basePath: './output',
    dateFormat: 'YYYYMMDD',
    createDateFolders: true,
    overwriteExisting: true,
    saveCEXList: true
  },
  supabase: {
    url: process.env.SUPABASE_URL || 'your_supabase_url_here',
    key: process.env.SUPABASE_ANON_KEY || 'your_supabase_anon_key_here',
    table: 'cex-address'
  }
};
