#!/bin/bash

# 每日一键运行脚本
# 自动完成：收集地址 → 生成文件 → 增量导入Supabase
# 使用方法: ./daily-run.sh

# 设置工作目录
cd "$(dirname "$0")/.."

# 获取当前日期
CURRENT_DATE=$(date +%Y%m%d)
echo "🚀 开始每日地址收集和导入任务..."
echo "📅 当前日期: $CURRENT_DATE"
echo "⏰ 开始时间: $(date '+%Y-%m-%d %H:%M:%S')"

# 创建日志目录
mkdir -p logs

# 记录开始时间
START_TIME=$(date +%s)

# 第一步：运行地址收集器
echo "\n📥 第一步：开始收集交易所地址..."
if node src/oklink/index.js; then
    echo "✅ 地址收集完成"
else
    echo "❌ 地址收集失败"
    exit 1
fi

# 第二步：检查生成的文件
echo "\n📋 第二步：检查生成的文件..."
if [ -d "output/$CURRENT_DATE" ]; then
    echo "✅ 日期文件夹已创建: output/$CURRENT_DATE"
    
    # 列出生成的文件
    echo "📁 生成的文件列表:"
    ls -la "output/$CURRENT_DATE/" | grep "\.json$"
    
    # 检查关键文件
    if [ -f "output/$CURRENT_DATE/cex_addresses_standard.json" ]; then
        echo "✅ 标准地址文件已生成"
    else
        echo "❌ 标准地址文件未生成"
        exit 1
    fi
    
    if [ -f "output/$CURRENT_DATE/cex_addresses_summary.json" ]; then
        echo "✅ 地址汇总文件已生成"
    else
        echo "❌ 地址汇总文件未生成"
        exit 1
    fi
else
    echo "❌ 日期文件夹未创建"
    exit 1
fi

# 第三步：检查Supabase导入状态
echo "\n🗄️ 第三步：检查Supabase导入状态..."
if [ -f "output/$CURRENT_DATE/import_report_$(date +%Y-%m-%d).json" ]; then
    echo "✅ Supabase导入报告已生成"
    
    # 显示导入统计
    echo "📊 导入统计:"
    cat "output/$CURRENT_DATE/import_report_$(date +%Y-%m-%d).json" | jq '.summary' 2>/dev/null || echo "无法解析导入报告"
else
    echo "⚠️ Supabase导入报告未生成，可能导入失败或跳过"
fi

# 计算总耗时
END_TIME=$(date +%s)
TOTAL_TIME=$((END_TIME - START_TIME))
TOTAL_TIME_MINUTES=$((TOTAL_TIME / 60))
TOTAL_TIME_SECONDS=$((TOTAL_TIME % 60))

echo "\n🎉 每日任务完成！"
echo "⏰ 结束时间: $(date '+%Y-%m-%d %H:%M:%S')"
echo "⏱️ 总耗时: ${TOTAL_TIME_MINUTES}分${TOTAL_TIME_SECONDS}秒"

# 生成任务完成报告
COMPLETION_REPORT="output/$CURRENT_DATE/daily_task_completion.json"
cat > "$COMPLETION_REPORT" << EOF
{
  "taskDate": "$CURRENT_DATE",
  "startTime": "$(date -d @$START_TIME '+%Y-%m-%d %H:%M:%S')",
  "endTime": "$(date '+%Y-%m-%d %H:%M:%S')",
  "totalDurationSeconds": $TOTAL_TIME,
  "totalDurationFormatted": "${TOTAL_TIME_MINUTES}分${TOTAL_TIME_SECONDS}秒",
  "status": "completed",
  "filesGenerated": [
    "cex_list.json",
    "cex_addresses_summary.json",
    "cex_addresses_standard.json"
  ],
  "supabaseImport": {
    "status": "$([ -f "output/$CURRENT_DATE/import_report_$(date +%Y-%m-%d).json" ] && echo "completed" || echo "skipped_or_failed")",
    "reportFile": "$([ -f "output/$CURRENT_DATE/import_report_$(date +%Y-%m-%d).json" ] && echo "import_report_$(date +%Y-%m-%d).json" || echo "none")"
  }
}
EOF

echo "📝 任务完成报告已保存到: $COMPLETION_REPORT"

# 显示最终状态
echo "\n📊 最终状态:"
echo "   📁 输出文件夹: output/$CURRENT_DATE/"
echo "   📄 生成文件数: $(ls -1 "output/$CURRENT_DATE/"*.json 2>/dev/null | wc -l)"
echo "   🗄️ Supabase导入: $([ -f "output/$CURRENT_DATE/import_report_$(date +%Y-%m-%d).json" ] && echo "✅ 完成" || echo "⚠️ 跳过/失败")"

echo "\n🎯 明天继续运行: ./scripts/daily-run.sh"
