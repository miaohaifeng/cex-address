#!/bin/bash

# 生产环境定时导入脚本
# 使用方法: ./schedule-import.sh [YYYYMMDD]

# 设置工作目录
cd "$(dirname "$0")/.."

# 获取当前日期
CURRENT_DATE=$(date +%Y%m%d)
TARGET_DATE=${1:-$CURRENT_DATE}

echo "🚀 开始定时导入任务..."
echo "📅 当前日期: $CURRENT_DATE"
echo "🎯 目标日期: $TARGET_DATE"

# 检查目标文件夹是否存在
if [ ! -d "output/$TARGET_DATE" ]; then
    echo "❌ 目标文件夹 output/$TARGET_DATE 不存在"
    echo "💡 请先运行地址收集器生成数据"
    exit 1
fi

# 检查标准地址文件是否存在
if [ ! -f "output/$TARGET_DATE/cex_addresses_standard.json" ]; then
    echo "❌ 标准地址文件 output/$TARGET_DATE/cex_addresses_standard.json 不存在"
    exit 1
fi

# 运行导入脚本
echo "📥 开始导入 $TARGET_DATE 的数据..."
node src/production-import-addresses.js "$TARGET_DATE"

# 检查导入结果
if [ $? -eq 0 ]; then
    echo "✅ 导入任务完成"
    
    # 生成导入完成标记
    echo "📝 生成导入完成标记..."
    echo "{\"importDate\":\"$(date -u +%Y-%m-%dT%H:%M:%S.%3NZ)\",\"status\":\"completed\",\"targetFolder\":\"$TARGET_DATE\"}" > "output/$TARGET_DATE/import_completed.json"
    
    echo "🎉 所有任务完成！"
else
    echo "❌ 导入任务失败"
    exit 1
fi
