# 🎯 功能特性总结

## ✨ 核心功能

### 1. 🔑 自动API Key获取
- **无需手动操作**: 完全自动化获取OKLink的API Key
- **多种获取方式**: 网络请求监听、localStorage、页面源码分析
- **实时更新**: 自动处理API Key过期问题

### 2. 📊 完整CEX数据采集
- **全交易所覆盖**: 自动遍历所有CEX（Binance、OKX、Kraken等）
- **多链支持**: 支持BTC、ETH、SOLANA、POLYGON等主流链
- **多币种支持**: 支持BTC、ETH、USDT、USDC等主要币种

### 3. 🚀 智能频率控制
- **基础延迟**: 根据链和CEX类型动态调整（150-250ms）
- **随机化**: 添加随机因子，避免被识别为机器人
- **批量控制**: 每10/50/100个请求后自动增加延迟
- **CEX特定**: 大交易所使用更保守的延迟策略

### 4. 🔄 自动重试机制
- **网络错误重试**: 连接超时、DNS解析失败等自动重试
- **API错误重试**: 根据错误类型智能重试
- **最大重试次数**: 可配置的重试次数（默认3次）
- **错误分类处理**: 不同错误类型使用不同的重试延迟

## 📁 文件组织系统

### 1. 日期文件夹结构
```
output/
├── 20250817/                    # 2025年8月17日的数据
│   ├── cex_list.json            # CEX列表和基本信息
│   ├── binance_addresses.json   # Binance交易所地址数据
│   ├── okx_addresses.json       # OKX交易所地址数据
│   ├── kraken_addresses.json    # Kraken交易所地址数据
│   ├── cex_addresses_summary.json    # 汇总统计信息
│   └── cex_addresses_standard.json   # 标准格式地址数据
├── 20250818/                    # 2025年8月18日的数据
│   └── ...
└── ...
```

### 2. 文件覆盖机制
- **同一天重复运行**: 所有文件自动覆盖，保持最新数据
- **不同日期**: 创建新日期文件夹，保留历史数据
- **智能命名**: 每个交易所使用独立的JSON文件
- **完整数据**: 每天包含CEX列表、地址数据、汇总信息等完整数据集

### 3. 数据清理工具
- **存储信息查看**: 显示文件夹数量、文件数量、总大小
- **旧数据清理**: 可配置保留天数，自动清理过期数据
- **安全删除**: 删除前显示将要删除的文件列表

## 🛡️ 防封禁策略

### 1. 请求频率控制
```javascript
// 保守模式（推荐长期运行）
baseDelay: 300-500ms
batchDelay: 每10请求+1秒，每50请求+3秒

// 平衡模式（推荐日常使用）
baseDelay: 150-250ms  
batchDelay: 每10请求+500ms，每50请求+2秒

// 快速模式（短期使用）
baseDelay: 100-150ms
batchDelay: 每10请求+300ms，每50请求+1秒
```

### 2. 智能延迟算法
- **链类型延迟**: BTC/ETH链150ms，其他链200-250ms
- **CEX特定延迟**: Binance/OKX额外50ms，Kraken额外30ms
- **随机化**: 0.8-1.2倍随机因子
- **批量控制**: 10/50/100请求阈值，自动增加延迟

## 🔍 错误处理系统

### 1. 详细错误日志
```
⚠️ 获取地址详情失败 [binance-BTC-BTC]
   请求URL: https://www.oklink.com/api/explorer/v2/por/binance/assets/detail?offset=0&blockChain=BTC&symbols=BTC&limit=20&t=1755399781510
   错误代码: 5001
   错误信息: API_KEY_NOT_FIND
   详细错误: API_KEY_NOT_FIND
```

### 2. 错误代码映射
| 错误代码 | 错误信息 | 说明 | 处理方式 |
|---------|---------|------|----------|
| 0 | success | 请求成功 | 正常处理数据 |
| 5001 | API_KEY_NOT_FIND | API Key未找到 | 自动重新获取API Key |
| 5004 | INVALID_PARAM | 参数无效 | 跳过该请求，记录日志 |
| 5004 | VISIT_ALREADY_EXPIRED | 访问已过期 | 自动重新获取API Key |
| 429 | RATE_LIMIT | 频率限制 | 增加延迟后重试 |

### 3. 自动错误恢复
- **API Key过期**: 自动重新获取
- **参数错误**: 智能跳过，继续处理其他请求
- **网络错误**: 自动重试，指数退避
- **频率限制**: 自动增加延迟

## 📊 输出数据格式

### 1. CEX列表数据
```json
{
  "timestamp": "2025-01-17T03:00:00.000Z",
  "totalCEX": 11,
  "cexList": [
    {
      "cexTag": "Binance",
      "seoCexTag": "binance",
      "totalValue": 192186499551.14044,
      "blockChainList": [
        {
          "chainIndex": "0",
          "blockChain": "BTC",
          "logo": "https://static.oklink.com/cdn/explorer/admin/1686558172927.png"
        }
      ],
      "symbolList": [
        {
          "symbol": "BTC",
          "symbolIndex": "1"
        }
      ]
    }
  ]
}
```

### 2. 标准格式地址数据
```json
{
  "timestamp": "2025-01-17T03:00:00.000Z",
  "totalAddresses": 15000,
  "addresses": [
    {
      "cexTag": "Binance",
      "symbol": "BTC",
      "address": "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa",
      "value": 100.5,
      "usdValue": 4500000,
      "isContract": false
    }
  ]
}
```

### 2. 单个CEX地址文件
```json
{
  "timestamp": "2025-01-17T03:00:00.000Z",
  "cexTag": "Binance",
  "totalAddresses": 3732,
  "addresses": [...]
}
```

### 3. 汇总统计信息
```json
{
  "timestamp": "2025-01-17T03:00:00.000Z",
  "totalCEX": 11,
  "totalAddresses": 15000,
  "cexResults": {
    "Binance": {
      "totalAddresses": 3732,
      "totalValue": "191.75B",
      "blockChains": 30,
      "symbols": 4
    }
  }
}
```

## ⚙️ 配置系统

### 1. 配置文件结构
```javascript
// src/config.js
export default {
  api: { /* API配置 */ },
  browser: { /* 浏览器配置 */ },
  rateLimit: { /* 频率控制配置 */ },
  output: { /* 输出配置 */ },
  logging: { /* 日志配置 */ }
}
```

### 2. 环境变量支持
```bash
export HEADLESS=true              # 无头模式
export BROWSER_TIMEOUT=60000     # 浏览器超时
export CHROME_PATH=/path/to/chrome  # Chrome路径
export LOG_LEVEL=debug           # 日志级别
```

## 🚀 使用方法

### 1. 基本使用
```bash
# 运行完整的地址收集
node src/ultimate-address-collector.js

# 快速测试功能
node src/quick-test.js
```

### 2. 数据管理
```bash
# 查看存储信息
node src/cleanup-old-data.js info

# 清理旧数据
node src/cleanup-old-data.js clean 30  # 保留30天
```

### 3. 定时任务
```bash
# 每天运行一次（使用cron）
0 2 * * * cd /path/to/project && node src/ultimate-address-collector.js

# 或者使用systemd timer
```

## 🎯 适用场景

### 1. 数据分析
- **市场研究**: 分析CEX资产分布和变化趋势
- **风险评估**: 监控CEX资产流动和集中度
- **合规检查**: 验证CEX储备证明数据

### 2. 自动化运维
- **每日数据采集**: 定时收集最新数据
- **数据备份**: 按日期组织，便于管理和查询
- **异常监控**: 自动检测和报告数据异常

### 3. 研究开发
- **API研究**: 了解OKLink API的使用方式
- **数据挖掘**: 分析区块链地址模式
- **工具开发**: 基于采集数据开发其他工具

## 🚨 注意事项

### 1. 合规使用
- 遵守OKLink的使用条款和API限制
- 仅用于合法合规的数据分析
- 不要设置过于激进的请求频率

### 2. 数据安全
- 重要数据及时备份
- 定期清理过期数据
- 注意数据隐私保护

### 3. 系统要求
- Node.js 18+ 版本
- Chrome/Chromium浏览器
- 稳定的网络连接
- 足够的存储空间

## 🔮 未来规划

### 1. 功能增强
- 支持更多区块链和币种
- 增加数据可视化功能
- 支持实时数据流

### 2. 性能优化
- 并行处理优化
- 内存使用优化
- 网络请求优化

### 3. 扩展性
- 插件系统支持
- 多数据源支持
- 分布式部署支持
