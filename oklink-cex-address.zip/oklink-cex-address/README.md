# OKLink CEX 地址采集工具

一个完全自动化的工具，用于收集OKLink上所有CEX（中心化交易所）的链上地址数据。

## ✨ 主要特性

- 🔑 **自动获取API Key**: 无需手动获取，自动从页面中提取最新的认证信息
- 📊 **完整CEX覆盖**: 自动遍历所有CEX，获取每个交易所的地址数据
- 🚀 **智能频率控制**: 内置智能延迟策略，防止被OKLink封禁
- 🔄 **自动重试机制**: 网络错误和API错误自动重试
- 📁 **多格式输出**: 支持单个CEX文件、汇总文件和标准格式文件
- ⚙️ **灵活配置**: 通过配置文件轻松调整各种参数

## 🏗️ 项目结构

```
oklink-cex-address/
├── src/
│   ├── ultimate-address-collector.js  # 🎯 终极地址收集器（推荐使用）
│   ├── index.js                       # 主要CEX数据采集器
│   ├── apiKeyExtractor.js             # API Key提取器
│   ├── example.js                     # 使用示例
│   ├── test.js                        # 测试脚本
│   └── config.js                      # 配置文件
├── output/                            # 输出数据目录
├── package.json                       # 项目依赖
└── README.md                          # 说明文档
```

## 🚀 快速开始

### 1. 安装依赖

```bash
npm install
```

### 2. 运行地址收集器

```bash
# 运行终极地址收集器（推荐）
node src/ultimate-address-collector.js

# 或者运行其他脚本
node src/index.js          # 主要CEX数据采集
node src/example.js        # 查看使用示例
node src/test.js           # 运行测试
```

### 3. 数据管理

```bash
# 查看存储信息
node src/cleanup-old-data.js info

# 列出所有日期文件夹
node src/cleanup-old-data.js list

# 清理旧数据（默认保留7天）
node src/cleanup-old-data.js clean

# 清理指定天数前的数据
node src/cleanup-old-data.js clean 30  # 保留30天
```

## ⚙️ 配置说明

### 输出文件配置

在 `src/config.js` 中可以调整以下参数：

```javascript
output: {
  directory: './output',           // 输出根目录
  maxAddressesPerFile: 1000,      // 每个文件最大地址数量
  saveIndividualCEX: true,        // 是否保存单个CEX文件
  saveCEXList: true,              // 是否保存CEX列表文件
  saveSummary: true,              // 是否保存汇总文件
  saveStandardFormat: true,       // 是否保存标准格式文件
  // 日期文件夹配置
  dateFormat: 'YYYYMMDD',         // 日期格式：20250117
  createDateFolders: true,        // 是否创建日期文件夹
  overwriteExisting: true         // 是否覆盖已存在的文件
}
```

### 请求频率控制

在 `src/config.js` 中可以调整以下参数：

```javascript
rateLimit: {
  // 基础延迟配置
  baseDelay: {
    BTC: 150,      // BTC链基础延迟150ms
    ETH: 150,      // ETH链基础延迟150ms
    SOLANA: 250,   // SOLANA链基础延迟250ms
    default: 200   // 其他链默认延迟200ms
  },
  
  // 批量请求延迟配置
  batchDelay: {
    every10Requests: 500,    // 每10个请求后额外延迟500ms
    every50Requests: 2000,   // 每50个请求后额外延迟2秒
    every100Requests: 5000   // 每100个请求后额外延迟5秒
  }
}
```

### 环境变量

```bash
# 设置浏览器为无头模式
export HEADLESS=true

# 设置浏览器超时时间
export BROWSER_TIMEOUT=60000

# 设置Chrome路径
export CHROME_PATH=/path/to/chrome

# 设置日志级别
export LOG_LEVEL=debug
```

## 📁 输出文件组织

### 日期文件夹结构

脚本会自动创建按日期命名的文件夹，格式为 `YYYYMMDD`（如 `20250817`）：

```
output/
├── 20250817/                    # 2025年8月17日的数据
│   ├── cex_list.json            # CEX列表和基本信息
│   ├── binance_addresses.json   # Binance交易所地址数据
│   ├── okx_addresses.json       # OKX交易所地址数据
│   ├── kraken_addresses.json    # Kraken交易所地址数据
│   ├── cex_addresses_summary.json    # 汇总统计信息
│   └── cex_addresses_standard.json   # 标准格式地址数据
├── 20250818/                    # 2025年8月18日的数据
│   └── ...
└── ...
```

### 文件覆盖机制

- **同一天内重复运行**: 文件会自动覆盖，保持最新的数据
- **不同日期**: 会创建新的日期文件夹，保留历史数据
- **文件命名**: 每个交易所使用独立的JSON文件，便于管理和查询

## 📊 输出数据格式

### CEX列表数据

```json
{
  "timestamp": "2025-01-17T03:00:00.000Z",
  "totalCEX": 11,
  "cexList": [
    {
      "cexTag": "Binance",
      "seoCexTag": "binance",
      "totalValue": "191.75B",
      "totalValueChange": "0.24%",
      "netInflow": "-233.6M",
      "addressCount": 26866401,
      "rank": 1,
      "blockChainList": [
        {
          "blockChain": "BTC",
          "chainIndex": 1
        }
      ],
      "symbolList": [
        {
          "symbol": "BTC",
          "symbolIndex": 1
        }
      ]
    }
  ]
}
```

### 标准格式地址数据

```json
{
  "timestamp": "2025-01-17T03:00:00.000Z",
  "totalAddresses": 15000,
  "addresses": [
    {
      "cexTag": "Binance",
      "symbol": "BTC",
      "address": "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa",
      "value": 100.5,
      "usdValue": 4500000,
      "isContract": false
    }
  ]
}
```

### 单个CEX地址文件

```json
{
  "timestamp": "2025-01-17T03:00:00.000Z",
  "cexTag": "Binance",
  "totalAddresses": 3732,
  "addresses": [...]
}
```

## 🔗 API接口格式

### 地址详情接口

```
GET https://www.oklink.com/api/explorer/v2/por/{cexTag}/assets/detail
```

**请求参数:**
- `cexTag`: CEX标识符（如 binance, okx, kraken）
- `blockChain`: 区块链名称（如 BTC, ETH, SOLANA）
- `symbols`: 币种符号（如 BTC, ETH, USDT）
- `offset`: 偏移量，用于分页
- `limit`: 返回数量限制（最大100）
- `t`: 时间戳

**示例请求:**
```
https://www.oklink.com/api/explorer/v2/por/binance/assets/detail?offset=0&blockChain=BTC&symbols=BTC&limit=20&t=1755399781510
```

**响应格式:**
```json
{
  "code": 0,
  "msg": "success",
  "data": {
    "hits": [
      {
        "address": "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa",
        "value": 100.5,
        "usdValue": 4500000,
        "isContract": false
      }
    ]
  }
}
```

## 🛡️ 防封禁策略

### 智能延迟控制

1. **基础延迟**: 根据链和CEX类型设置不同的基础延迟
2. **随机化**: 添加随机因子，避免被识别为机器人
3. **批量控制**: 每10/50/100个请求后增加额外延迟
4. **错误重试**: 网络错误和API错误自动重试

### 请求频率建议

- **保守模式**: 基础延迟300-500ms，适合长期运行
- **平衡模式**: 基础延迟150-250ms，平衡速度和安全性
- **快速模式**: 基础延迟100-150ms，适合短期快速收集

## 🔍 错误处理

### 常见错误及解决方案

1. **API_KEY_NOT_FIND (5001)**: API Key未找到或无效，自动重新获取
2. **INVALID_PARAM (5004)**: 链和币种组合不支持，自动跳过
3. **VISIT_ALREADY_EXPIRED (5004)**: API Key过期，自动重新获取
4. **RATE_LIMIT**: 频率限制，自动延迟重试
5. **网络错误**: 连接超时、DNS解析失败等，自动重试最多3次

### 错误代码参考表

| 错误代码 | 错误信息 | 说明 | 处理方式 |
|---------|---------|------|----------|
| 0 | success | 请求成功 | 正常处理数据 |
| 5001 | API_KEY_NOT_FIND | API Key未找到 | 自动重新获取API Key |
| 5004 | INVALID_PARAM | 参数无效 | 跳过该请求，记录日志 |
| 5004 | VISIT_ALREADY_EXPIRED | 访问已过期 | 自动重新获取API Key |
| 429 | RATE_LIMIT | 频率限制 | 增加延迟后重试 |
| 500 | INTERNAL_ERROR | 服务器内部错误 | 延迟后重试 |
| 502/503/504 | 网关错误 | 网络或服务器问题 | 延迟后重试 |

### 错误日志示例

```
⚠️ 获取地址详情失败 [binance-BTC-BTC]
   请求URL: https://www.oklink.com/api/explorer/v2/por/binance/assets/detail?offset=0&blockChain=BTC&symbols=BTC&limit=20&t=1755399781510
   错误代码: 5001
   错误信息: API_KEY_NOT_FIND
   详细错误: API_KEY_NOT_FIND

⚠️ 获取地址详情失败 [kraken-BCH-ETH]
   请求URL: https://www.oklink.com/api/explorer/v2/por/kraken/assets/detail?offset=0&blockChain=BCH&symbols=ETH&limit=100&t=1755399781510
   错误代码: 5004
   错误信息: INVALID_PARAM
   详细错误: 该链不支持该币种

⚠️ 获取地址详情失败 [okx-SOLANA-BTC]
   请求URL: https://www.oklink.com/api/explorer/v2/por/okx/assets/detail?offset=0&blockChain=SOLANA&symbols=BTC&limit=100&t=1755399781510
   错误代码: 5004
   错误信息: INVALID_PARAM
   详细错误: SOLANA链不支持BTC币种
```

## 📈 性能优化

### 并行处理

- 支持多个CEX并行处理（可配置）
- 智能队列管理，避免过载

### 内存管理

- 分批保存数据，避免内存溢出
- 自动清理临时数据

## 🚨 注意事项

1. **遵守规则**: 请遵守OKLink的使用条款和API限制
2. **合理频率**: 不要设置过于激进的请求频率
3. **数据用途**: 仅用于合法合规的数据分析
4. **备份数据**: 重要数据请及时备份

## 🤝 贡献

欢迎提交Issue和Pull Request来改进这个工具！

## 📄 许可证

MIT License

## 🔗 相关链接

- [OKLink官网](https://www.oklink.com)
- [OKLink API文档](https://www.oklink.com/docs)
- [项目GitHub](https://github.com/your-username/oklink-cex-address)
