import fs from 'fs/promises';
import path from 'path';

// 清理旧数据的脚本
class DataCleanup {
  constructor() {
    this.outputDir = './output';
  }

  async listDateFolders() {
    try {
      const items = await fs.readdir(this.outputDir);
      const dateFolders = [];
      
      for (const item of items) {
        const itemPath = path.join(this.outputDir, item);
        const stats = await fs.stat(itemPath);
        
        if (stats.isDirectory() && /^\d{8}$/.test(item)) {
          dateFolders.push(item);
        }
      }
      
      return dateFolders.sort();
    } catch (error) {
      console.error('❌ 读取输出目录失败:', error.message);
      return [];
    }
  }

  async showFolderInfo(folderName) {
    try {
      const folderPath = path.join(this.outputDir, folderName);
      const files = await fs.readdir(folderPath);
      const jsonFiles = files.filter(file => file.endsWith('.json'));
      
      let totalSize = 0;
      for (const file of jsonFiles) {
        const filePath = path.join(folderPath, file);
        const stats = await fs.stat(filePath);
        totalSize += stats.size;
      }
      
      return {
        folderName,
        fileCount: jsonFiles.length,
        totalSize: (totalSize / 1024).toFixed(2), // KB
        files: jsonFiles
      };
    } catch (error) {
      return {
        folderName,
        fileCount: 0,
        totalSize: '0',
        files: [],
        error: error.message
      };
    }
  }

  async cleanupOldFolders(keepDays = 7) {
    console.log(`🧹 开始清理 ${keepDays} 天前的数据文件夹...`);
    
    try {
      const dateFolders = await this.listDateFolders();
      if (dateFolders.length === 0) {
        console.log('📁 没有找到日期文件夹');
        return;
      }

      console.log(`📋 找到 ${dateFolders.length} 个日期文件夹:`);
      
      const now = new Date();
      const cutoffDate = new Date(now.getTime() - keepDays * 24 * 60 * 60 * 1000);
      
      for (const folder of dateFolders) {
        const info = await this.showFolderInfo(folder);
        const folderDate = this.parseDateFolder(folder);
        
        if (folderDate < cutoffDate) {
          console.log(`  🗑️  ${folder} (${info.fileCount} 文件, ${info.totalSize} KB) - 将被删除`);
        } else {
          console.log(`  ✅  ${folder} (${info.fileCount} 文件, ${info.totalSize} KB) - 保留`);
        }
      }

      // 询问用户确认
      console.log(`\n⚠️ 将删除 ${dateFolders.filter(f => this.parseDateFolder(f) < cutoffDate).length} 个旧文件夹`);
      console.log('💡 建议: 在删除前备份重要数据');
      
      // 这里可以添加用户确认逻辑
      // 为了演示，我们直接执行清理
      
      let deletedCount = 0;
      for (const folder of dateFolders) {
        const folderDate = this.parseDateFolder(folder);
        if (folderDate < cutoffDate) {
          try {
            const folderPath = path.join(this.outputDir, folder);
            await fs.rm(folderPath, { recursive: true, force: true });
            console.log(`  ✅ 已删除: ${folder}`);
            deletedCount++;
          } catch (error) {
            console.log(`  ❌ 删除失败: ${folder} - ${error.message}`);
          }
        }
      }
      
      console.log(`\n🎉 清理完成! 删除了 ${deletedCount} 个旧文件夹`);
      
    } catch (error) {
      console.error('❌ 清理失败:', error.message);
    }
  }

  parseDateFolder(folderName) {
    // 解析 YYYYMMDD 格式的文件夹名
    const year = parseInt(folderName.substring(0, 4));
    const month = parseInt(folderName.substring(4, 6)) - 1; // 月份从0开始
    const day = parseInt(folderName.substring(6, 8));
    return new Date(year, month, day);
  }

  async showStorageInfo() {
    console.log('📊 存储空间使用情况...');
    
    try {
      const dateFolders = await this.listDateFolders();
      let totalFolders = 0;
      let totalFiles = 0;
      let totalSize = 0;
      
      for (const folder of dateFolders) {
        const info = await this.showFolderInfo(folder);
        if (!info.error) {
          totalFolders++;
          totalFiles += info.fileCount;
          totalSize += parseFloat(info.totalSize);
        }
      }
      
      console.log(`📁 总文件夹数: ${totalFolders}`);
      console.log(`📄 总文件数: ${totalFiles}`);
      console.log(`💾 总大小: ${totalSize.toFixed(2)} KB (${(totalSize / 1024).toFixed(2)} MB)`);
      
      // 显示每个文件夹的详细信息
      console.log('\n📋 各文件夹详细信息:');
      for (const folder of dateFolders) {
        const info = await this.showFolderInfo(folder);
        if (!info.error) {
          console.log(`  📁 ${folder}: ${info.fileCount} 文件, ${info.totalSize} KB`);
        }
      }
      
    } catch (error) {
      console.error('❌ 获取存储信息失败:', error.message);
    }
  }
}

// 主函数
async function main() {
  const cleanup = new DataCleanup();
  
  const args = process.argv.slice(2);
  const command = args[0];
  
  switch (command) {
    case 'list':
      console.log('📋 列出所有日期文件夹...');
      const folders = await cleanup.listDateFolders();
      for (const folder of folders) {
        const info = await cleanup.showFolderInfo(folder);
        console.log(`  📁 ${info.folderName}: ${info.fileCount} 文件, ${info.totalSize} KB`);
      }
      break;
      
    case 'clean':
      const keepDays = parseInt(args[1]) || 7;
      await cleanup.cleanupOldFolders(keepDays);
      break;
      
    case 'info':
      await cleanup.showStorageInfo();
      break;
      
    default:
      console.log('🧹 数据清理工具');
      console.log('\n使用方法:');
      console.log('  node src/cleanup-old-data.js list          # 列出所有日期文件夹');
      console.log('  node src/cleanup-old-data.js info          # 显示存储信息');
      console.log('  node src/cleanup-old-data.js clean [天数]  # 清理指定天数前的数据 (默认7天)');
      console.log('\n示例:');
      console.log('  node src/cleanup-old-data.js clean 30     # 清理30天前的数据');
      break;
  }
}

// 运行主函数
main().catch(console.error);
