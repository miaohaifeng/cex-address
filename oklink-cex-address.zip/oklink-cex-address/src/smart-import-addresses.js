import { createClient } from '@supabase/supabase-js';
import fs from 'fs/promises';
import path from 'path';
import config from '../config.js';

class SmartAddressImporter {
  constructor() {
    this.supabase = createClient(config.supabase.url, config.supabase.serviceRoleKey);
    this.batchSize = 1000; // 减小批次大小
    this.totalProcessed = 0;
    this.totalSuccess = 0;
    this.totalSkipped = 0;
    this.existingRecords = new Set(); // 缓存已存在的记录
  }

  async importAddresses() {
    console.log('🚀 开始智能导入地址数据到Supabase...');
    
    try {
      // 第一步：获取数据库中已存在的记录
      await this.loadExistingRecords();
      
      // 第二步：读取并处理JSON文件
      await this.processJsonFile();
      
      // 第三步：验证结果
      await this.validateData();
      
      console.log('\n🎉 智能导入完成！');
      
    } catch (error) {
      console.error('❌ 导入失败:', error.message);
      console.error('   堆栈:', error.stack);
    }
  }

  async loadExistingRecords() {
    console.log('\n📊 第一步：加载数据库中已存在的记录...');
    
    try {
      let offset = 0;
      const limit = 1000;
      let totalLoaded = 0;
      
      while (true) {
        const { data: records, error: queryError } = await this.supabase
          .from(config.supabase.table)
          .select('cexTag, symbol, address')
          .range(offset, offset + limit - 1);

        if (queryError) {
          console.error('❌ 查询现有记录失败:', queryError.message);
          break;
        }

        if (!records || records.length === 0) {
          break;
        }

        // 添加到缓存
        records.forEach(record => {
          const key = `${record.cexTag}-${record.symbol}-${record.address}`;
          this.existingRecords.add(key);
        });

        totalLoaded += records.length;
        console.log(`   📥 已加载 ${totalLoaded} 条现有记录...`);

        if (records.length < limit) {
          break; // 最后一页
        }

        offset += limit;
      }

      console.log(`✅ 数据库中有 ${this.existingRecords.size} 条现有记录`);
      
    } catch (error) {
      console.error('❌ 加载现有记录失败:', error.message);
      throw error;
    }
  }

  async processJsonFile() {
    console.log('\n📥 第二步：处理JSON文件...');
    
    try {
      // 读取JSON文件
      const filePath = path.join('./output/20250817/cex_addresses_standard.json');
      console.log(`📁 读取文件: ${filePath}`);
      
      const fileContent = await fs.readFile(filePath, 'utf8');
      const data = JSON.parse(fileContent);
      
      console.log(`📊 文件信息:`);
      console.log(`   时间戳: ${data.timestamp}`);
      console.log(`   总地址数: ${data.totalAddresses}`);
      console.log(`   地址数组长度: ${data.addresses.length}`);
      
      if (!data.addresses || !Array.isArray(data.addresses)) {
        throw new Error('地址数据格式错误');
      }
      
      // 过滤出新记录
      const newAddresses = this.filterNewAddresses(data.addresses);
      
      console.log(`📊 过滤结果:`);
      console.log(`   原始记录数: ${data.addresses.length}`);
      console.log(`   新记录数: ${newAddresses.length}`);
      console.log(`   跳过记录数: ${data.addresses.length - newAddresses.length}`);
      
      if (newAddresses.length === 0) {
        console.log('✅ 所有记录都已存在，无需导入');
        return;
      }
      
      // 开始批量导入新记录
      await this.processAddresses(newAddresses);
      
    } catch (error) {
      console.error('❌ 处理JSON文件失败:', error.message);
      throw error;
    }
  }

  filterNewAddresses(addresses) {
    console.log('🔍 过滤新记录...');
    
    const newAddresses = [];
    let skippedCount = 0;
    
    addresses.forEach((addr, index) => {
      const key = `${addr.cexTag}-${addr.symbol}-${addr.address}`;
      
      if (this.existingRecords.has(key)) {
        skippedCount++;
      } else {
        newAddresses.push(addr);
      }
      
      // 显示进度
      if ((index + 1) % 10000 === 0) {
        console.log(`   📊 已处理 ${index + 1}/${addresses.length} 条记录...`);
      }
    });
    
    console.log(`✅ 过滤完成: 新记录 ${newAddresses.length}, 跳过 ${skippedCount}`);
    return newAddresses;
  }

  async processAddresses(addresses) {
    console.log(`\n📦 开始处理 ${addresses.length} 条新地址记录...`);
    
    // 分批处理
    for (let i = 0; i < addresses.length; i += this.batchSize) {
      const batch = addresses.slice(i, i + this.batchSize);
      const batchNumber = Math.floor(i / this.batchSize) + 1;
      const totalBatches = Math.ceil(addresses.length / this.batchSize);
      
      console.log(`\n📦 处理第 ${batchNumber}/${totalBatches} 批 (${batch.length} 条记录)...`);
      
      try {
        const result = await this.processBatch(batch);
        this.totalSuccess += result.successCount;
        this.totalProcessed += batch.length;
        
        console.log(`   ✅ 第 ${batchNumber} 批完成: 成功 ${result.successCount}`);
        
        // 批次间延迟
        if (i + this.batchSize < addresses.length) {
          console.log(`   ⏰ 等待100ms后处理下一批...`);
          await this.sleep(100);
        }
        
      } catch (error) {
        console.error(`   ❌ 第 ${batchNumber} 批处理失败:`, error.message);
        throw error;
      }
    }
  }

  async processBatch(batchData) {
    try {
      // 准备插入数据
      const insertData = batchData.map(addr => ({
        cexTag: addr.cexTag,
        symbol: addr.symbol,
        address: addr.address,
        isContract: addr.isContract || false
      }));

      // 直接插入（因为已经过滤了重复）
      const { data: insertResult, error: insertError } = await this.supabase
        .from(config.supabase.table)
        .insert(insertData)
        .select();

      if (insertError) {
        console.error(`   ❌ 批次insert失败:`, insertError.message);
        throw insertError;
      }

      // 统计结果
      const successCount = insertResult ? insertResult.length : 0;

      return {
        successCount,
        data: insertResult
      };
      
    } catch (error) {
      console.error(`   ❌ 批次处理失败:`, error.message);
      throw error;
    }
  }

  async sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  async validateData() {
    console.log('\n🔍 第三步：验证数据完整性...');
    
    try {
      // 查询数据库中的总记录数
      const { data: totalRecords, error: countError } = await this.supabase
        .from(config.supabase.table)
        .select('id', { count: 'exact' });

      if (countError) {
        console.error('❌ 查询总记录数失败:', countError.message);
        return;
      }

      console.log(`📊 数据库中的总记录数: ${totalRecords.length}`);
      
      // 按CEX统计
      const { data: cexStats, error: cexError } = await this.supabase
        .from(config.supabase.table)
        .select('cexTag')
        .order('cexTag');

      if (!cexError && cexStats) {
        const cexCounts = {};
        cexStats.forEach(record => {
          cexCounts[record.cexTag] = (cexCounts[record.cexTag] || 0) + 1;
        });
        
        console.log('📋 按CEX统计:');
        Object.entries(cexCounts).forEach(([cex, count]) => {
          console.log(`   ${cex}: ${count} 条记录`);
        });
      }
      
      // 输出导入统计
      console.log('\n📊 导入统计:');
      console.log(`   总处理: ${this.totalProcessed}`);
      console.log(`   成功插入: ${this.totalSuccess}`);
      console.log(`   跳过重复: ${this.totalSkipped}`);
      
    } catch (error) {
      console.error('❌ 数据验证失败:', error.message);
    }
  }
}

// 主函数
async function main() {
  const importer = new SmartAddressImporter();
  
  try {
    await importer.importAddresses();
  } catch (error) {
    console.error('❌ 主程序执行失败:', error.message);
    process.exit(1);
  }
}

// 运行脚本
main();
