import { createClient } from '@supabase/supabase-js';
import fs from 'fs/promises';
import path from 'path';
import config from '../config.js';

class ProductionAddressImporter {
  constructor() {
    this.supabase = createClient(config.supabase.url, config.supabase.serviceRoleKey);
    this.batchSize = 1000; // 生产环境批次大小
    this.totalProcessed = 0;
    this.totalSuccess = 0;
    this.totalSkipped = 0;
    this.totalNew = 0;
    this.existingRecords = new Set(); // 缓存已存在的记录
    this.importDate = new Date().toISOString().split('T')[0]; // 当前日期 YYYY-MM-DD
  }

  async importAddresses(dateFolder = null) {
    console.log('🚀 开始生产环境地址数据导入...');
    console.log(`📅 导入日期: ${this.importDate}`);
    
    try {
      // 第一步：加载数据库中已存在的记录
      await this.loadExistingRecords();
      
      // 第二步：确定要导入的文件
      const targetFolder = dateFolder || this.getLatestDateFolder();
      if (!targetFolder) {
        throw new Error('未找到可导入的日期文件夹');
      }
      
      // 第三步：导入指定日期的数据
      await this.importDateFolderData(targetFolder);
      
      // 第四步：验证结果
      await this.validateData();
      
      // 第五步：生成导入报告
      await this.generateImportReport(targetFolder);
      
      console.log('\n🎉 生产环境导入完成！');
      
    } catch (error) {
      console.error('❌ 导入失败:', error.message);
      console.error('   堆栈:', error.stack);
    }
  }

  async loadExistingRecords() {
    console.log('\n📊 第一步：加载数据库中已存在的记录...');
    
    try {
      let offset = 0;
      const limit = 1000;
      let totalLoaded = 0;
      let startTime = Date.now();
      
      while (true) {
        const { data: records, error: queryError } = await this.supabase
          .from(config.supabase.table)
          .select('cexTag, symbol, address')
          .range(offset, offset + limit - 1);

        if (queryError) {
          console.error('❌ 查询现有记录失败:', queryError.message);
          break;
        }

        if (!records || records.length === 0) {
          break;
        }

        // 添加到缓存
        records.forEach(record => {
          const key = `${record.cexTag}-${record.symbol}-${record.address}`;
          this.existingRecords.add(key);
        });

        totalLoaded += records.length;
        const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
        console.log(`   📥 已加载 ${totalLoaded} 条现有记录 (耗时: ${elapsed}s)...`);

        if (records.length < limit) {
          break; // 最后一页
        }

        offset += limit;
        
        // 避免长时间占用连接
        if (totalLoaded % 10000 === 0) {
          await this.sleep(100);
        }
      }

      const totalTime = ((Date.now() - startTime) / 1000).toFixed(1);
      console.log(`✅ 数据库中有 ${this.existingRecords.size} 条现有记录 (总耗时: ${totalTime}s)`);
      
    } catch (error) {
      console.error('❌ 加载现有记录失败:', error.message);
      throw error;
    }
  }

  getLatestDateFolder() {
    // 获取最新的日期文件夹
    const outputDir = './output';
    try {
      const folders = fs.readdirSync(outputDir, { withFileTypes: true })
        .filter(dirent => dirent.isDirectory())
        .map(dirent => dirent.name)
        .filter(name => /^\d{8}$/.test(name)) // 匹配 YYYYMMDD 格式
        .sort()
        .reverse();
      
      return folders.length > 0 ? folders[0] : null;
    } catch (error) {
      console.error('❌ 无法读取输出目录:', error.message);
      return null;
    }
  }

  async importDateFolderData(dateFolder) {
    console.log(`\n📥 第二步：导入 ${dateFolder} 文件夹的数据...`);
    
    try {
      const folderPath = `./output/${dateFolder}`;
      const files = await fs.readdir(folderPath);
      
      // 查找标准地址文件
      const standardFile = files.find(file => file === 'cex_addresses_standard.json');
      if (!standardFile) {
        console.log(`⚠️ 在 ${dateFolder} 文件夹中未找到 cex_addresses_standard.json`);
        return;
      }
      
      const filePath = path.join(folderPath, standardFile);
      console.log(`📁 找到文件: ${filePath}`);
      
      // 读取并处理文件
      await this.processStandardFile(filePath, dateFolder);
      
    } catch (error) {
      console.error('❌ 导入日期文件夹数据失败:', error.message);
      throw error;
    }
  }

  async processStandardFile(filePath, dateFolder) {
    try {
      const fileContent = await fs.readFile(filePath, 'utf8');
      const data = JSON.parse(fileContent);
      
      console.log(`📊 文件信息:`);
      console.log(`   时间戳: ${data.timestamp}`);
      console.log(`   总地址数: ${data.totalAddresses}`);
      console.log(`   地址数组长度: ${data.addresses.length}`);
      
      if (!data.addresses || !Array.isArray(data.addresses)) {
        throw new Error('地址数据格式错误');
      }
      
      // 过滤出新记录
      console.log('\n🔍 开始过滤新记录...');
      const newAddresses = this.filterNewAddresses(data.addresses);
      
      console.log(`📊 过滤结果:`);
      console.log(`   原始记录数: ${data.addresses.length}`);
      console.log(`   新记录数: ${newAddresses.length}`);
      console.log(`   跳过记录数: ${data.addresses.length - newAddresses.length}`);
      
      if (newAddresses.length === 0) {
        console.log('✅ 所有记录都已存在，无需导入');
        return;
      }
      
      // 开始批量导入新记录
      await this.processAddresses(newAddresses);
      
    } catch (error) {
      console.error('❌ 处理标准文件失败:', error.message);
      throw error;
    }
  }

  filterNewAddresses(addresses) {
    console.log('🔄 执行增量过滤逻辑...');
    
    const newAddresses = [];
    let skippedCount = 0;
    let startTime = Date.now();
    
    addresses.forEach((addr, index) => {
      const key = `${addr.cexTag}-${addr.symbol}-${addr.address}`;
      
      if (this.existingRecords.has(key)) {
        skippedCount++;
      } else {
        newAddresses.push(addr);
      }
      
      // 显示进度
      if ((index + 1) % 10000 === 0) {
        const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
        console.log(`   📊 已处理 ${index + 1}/${addresses.length} 条记录 (耗时: ${elapsed}s)...`);
      }
    });
    
    const totalTime = ((Date.now() - startTime) / 1000).toFixed(1);
    console.log(`✅ 过滤完成: 新记录 ${newAddresses.length}, 跳过 ${skippedCount} (总耗时: ${totalTime}s)`);
    
    this.totalSkipped = skippedCount;
    this.totalNew = newAddresses.length;
    
    return newAddresses;
  }

  async processAddresses(addresses) {
    console.log(`\n📦 开始处理 ${addresses.length} 条新地址记录...`);
    
    // 分批处理
    for (let i = 0; i < addresses.length; i += this.batchSize) {
      const batch = addresses.slice(i, i + this.batchSize);
      const batchNumber = Math.floor(i / this.batchSize) + 1;
      const totalBatches = Math.ceil(addresses.length / this.batchSize);
      
      console.log(`\n📦 处理第 ${batchNumber}/${totalBatches} 批 (${batch.length} 条记录)...`);
      
      try {
        const result = await this.processBatch(batch);
        this.totalSuccess += result.successCount;
        this.totalProcessed += batch.length;
        
        console.log(`   ✅ 第 ${batchNumber} 批完成: 成功 ${result.successCount}`);
        
        // 批次间延迟（生产环境优化）
        if (i + this.batchSize < addresses.length) {
          const delay = this.calculateOptimalDelay(batchNumber, totalBatches);
          console.log(`   ⏰ 等待${delay}ms后处理下一批...`);
          await this.sleep(delay);
        }
        
      } catch (error) {
        console.error(`   ❌ 第 ${batchNumber} 批处理失败:`, error.message);
        throw error;
      }
    }
  }

  calculateOptimalDelay(batchNumber, totalBatches) {
    // 智能延迟策略
    let baseDelay = 100;
    
    // 根据批次数量调整延迟
    if (totalBatches > 50) {
      baseDelay = 150;
    } else if (totalBatches > 20) {
      baseDelay = 120;
    }
    
    // 批次越往后，延迟越长（避免被限流）
    const progressFactor = batchNumber / totalBatches;
    if (progressFactor > 0.8) {
      baseDelay = Math.floor(baseDelay * 1.5);
    }
    
    // 添加随机因子
    const randomFactor = 0.8 + Math.random() * 0.4; // 0.8-1.2
    
    return Math.floor(baseDelay * randomFactor);
  }

  async processBatch(batchData) {
    try {
      // 准备插入数据
      const insertData = batchData.map(addr => ({
        cexTag: addr.cexTag,
        symbol: addr.symbol,
        address: addr.address,
        isContract: addr.isContract || false
      }));

      // 使用upsert，设置ignoreDuplicates为true
      const { data: insertResult, error: insertError } = await this.supabase
        .from(config.supabase.table)
        .insert(insertData, {
          ignoreDuplicates: true // 忽略重复，只插入新记录
        })
        .select();

      if (insertError) {
        console.error(`   ❌ 批次insert失败:`, insertError.message);
        throw insertError;
      }

      // 统计结果
      const successCount = insertResult ? insertResult.length : 0;

      return {
        successCount,
        data: insertResult
      };
      
    } catch (error) {
      console.error(`   ❌ 批次处理失败:`, error.message);
      throw error;
    }
  }

  async sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  async validateData() {
    console.log('\n🔍 第三步：验证数据完整性...');
    
    try {
      // 查询数据库中的总记录数
      const { data: totalRecords, error: countError } = await this.supabase
        .from(config.supabase.table)
        .select('id', { count: 'exact' });

      if (countError) {
        console.error('❌ 查询总记录数失败:', countError.message);
        return;
      }

      console.log(`📊 数据库中的总记录数: ${totalRecords.length}`);
      
      // 按CEX统计
      const { data: cexStats, error: cexError } = await this.supabase
        .from(config.supabase.table)
        .select('cexTag')
        .order('cexTag');

      if (!cexError && cexStats) {
        const cexCounts = {};
        cexStats.forEach(record => {
          cexCounts[record.cexTag] = (cexCounts[record.cexTag] || 0) + 1;
        });
        
        console.log('📋 按CEX统计:');
        Object.entries(cexCounts).forEach(([cex, count]) => {
          console.log(`   ${cex}: ${count} 条记录`);
        });
      }
      
    } catch (error) {
      console.error('❌ 数据验证失败:', error.message);
    }
  }

  async generateImportReport(dateFolder) {
    console.log('\n📊 第四步：生成导入报告...');
    
    try {
      const report = {
        importDate: this.importDate,
        dateFolder: dateFolder,
        timestamp: new Date().toISOString(),
        summary: {
          totalProcessed: this.totalProcessed,
          totalSuccess: this.totalSuccess,
          totalSkipped: this.totalSkipped,
          totalNew: this.totalNew,
          existingRecords: this.existingRecords.size
        },
        performance: {
          newRecordsPercentage: this.totalProcessed > 0 ? ((this.totalNew / this.totalProcessed) * 100).toFixed(2) : 0,
          skipRate: this.totalProcessed > 0 ? ((this.totalSkipped / this.totalProcessed) * 100).toFixed(2) : 0
        }
      };

      // 保存报告到文件
      const reportPath = `./output/${dateFolder}/import_report_${this.importDate}.json`;
      await fs.writeFile(reportPath, JSON.stringify(report, null, 2));
      
      console.log('📋 导入报告:');
      console.log(`   导入日期: ${report.importDate}`);
      console.log(`   目标文件夹: ${report.dateFolder}`);
      console.log(`   总处理: ${report.summary.totalProcessed}`);
      console.log(`   成功插入: ${report.summary.totalSuccess}`);
      console.log(`   跳过重复: ${report.summary.totalSkipped}`);
      console.log(`   新增记录: ${report.summary.totalNew}`);
      console.log(`   新记录比例: ${report.performance.newRecordsPercentage}%`);
      console.log(`   跳过率: ${report.performance.skipRate}%`);
      console.log(`   报告已保存到: ${reportPath}`);
      
    } catch (error) {
      console.error('❌ 生成导入报告失败:', error.message);
    }
  }
}

// 主函数
async function main() {
  const importer = new ProductionAddressImporter();
  
  try {
    // 可以通过命令行参数指定日期文件夹，否则自动选择最新的
    const args = process.argv.slice(2);
    const targetFolder = args[0] || null;
    
    if (targetFolder) {
      console.log(`🎯 指定导入文件夹: ${targetFolder}`);
    } else {
      console.log('🎯 自动选择最新日期文件夹');
    }
    
    await importer.importAddresses(targetFolder);
    
  } catch (error) {
    console.error('❌ 主程序执行失败:', error.message);
    process.exit(1);
  }
}

// 运行脚本
main();
