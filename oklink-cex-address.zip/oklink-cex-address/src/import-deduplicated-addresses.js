import { createClient } from '@supabase/supabase-js';
import fs from 'fs/promises';
import path from 'path';
import config from '../config.js';

class DeduplicatedAddressImporter {
  constructor() {
    this.supabase = createClient(config.supabase.url, config.supabase.serviceRoleKey);
    this.batchSize = 2000;
    this.totalProcessed = 0;
    this.totalSuccess = 0;
    this.totalSkipped = 0;
  }

  async importDeduplicatedAddresses() {
    console.log('🚀 开始导入去重后的地址数据到Supabase...');
    
    try {
      // 读取JSON文件
      const filePath = path.join('./output/20250817/cex_addresses_standard.json');
      console.log(`📁 读取文件: ${filePath}`);
      
      const fileContent = await fs.readFile(filePath, 'utf8');
      const data = JSON.parse(fileContent);
      
      console.log(`📊 原始文件信息:`);
      console.log(`   时间戳: ${data.timestamp}`);
      console.log(`   总地址数: ${data.totalAddresses}`);
      console.log(`   地址数组长度: ${data.addresses.length}`);
      
      if (!data.addresses || !Array.isArray(data.addresses)) {
        throw new Error('地址数据格式错误');
      }
      
      // 去重处理
      console.log('\n🔍 开始去重处理...');
      const deduplicatedAddresses = this.deduplicateAddresses(data.addresses);
      
      console.log(`📊 去重后信息:`);
      console.log(`   去重前记录数: ${data.addresses.length}`);
      console.log(`   去重后记录数: ${deduplicatedAddresses.length}`);
      console.log(`   重复记录数: ${data.addresses.length - deduplicatedAddresses.length}`);
      
      // 开始批量导入
      await this.processAddresses(deduplicatedAddresses);
      
      // 输出最终统计
      console.log('\n🎯 导入完成！');
      console.log(`📊 统计结果:`);
      console.log(`   总处理: ${this.totalProcessed}`);
      console.log(`   成功插入: ${this.totalSuccess}`);
      console.log(`   跳过重复: ${this.totalSkipped}`);
      
    } catch (error) {
      console.error('❌ 导入失败:', error.message);
      console.error('   堆栈:', error.stack);
    }
  }

  deduplicateAddresses(addresses) {
    console.log('🔄 执行去重逻辑...');
    
    const uniqueMap = new Map();
    const duplicates = [];
    
    addresses.forEach((addr, index) => {
      const key = `${addr.cexTag}-${addr.symbol}-${addr.address}`;
      
      if (uniqueMap.has(key)) {
        duplicates.push({
          index,
          key,
          addr,
          existing: uniqueMap.get(key)
        });
      } else {
        uniqueMap.set(key, addr);
      }
    });
    
    console.log(`📊 去重统计:`);
    console.log(`   唯一记录: ${uniqueMap.size}`);
    console.log(`   重复记录: ${duplicates.length}`);
    
    if (duplicates.length > 0) {
      console.log('📋 重复记录示例（前5条）:');
      duplicates.slice(0, 5).forEach((dup, index) => {
        console.log(`   ${index + 1}. ${dup.addr.cexTag} - ${dup.addr.symbol} - ${dup.addr.address}`);
      });
    }
    
    // 返回去重后的数组
    return Array.from(uniqueMap.values());
  }

  async processAddresses(addresses) {
    console.log(`\n📦 开始处理 ${addresses.length} 条去重后的地址记录...`);
    
    // 分批处理
    for (let i = 0; i < addresses.length; i += this.batchSize) {
      const batch = addresses.slice(i, i + this.batchSize);
      const batchNumber = Math.floor(i / this.batchSize) + 1;
      const totalBatches = Math.ceil(addresses.length / this.batchSize);
      
      console.log(`\n📦 处理第 ${batchNumber}/${totalBatches} 批 (${batch.length} 条记录)...`);
      
      try {
        const result = await this.processBatch(batch);
        this.totalSuccess += result.successCount;
        this.totalProcessed += batch.length;
        
        console.log(`   ✅ 第 ${batchNumber} 批完成: 成功 ${result.successCount}`);
        
        // 批次间延迟
        if (i + this.batchSize < addresses.length) {
          console.log(`   ⏰ 等待50ms后处理下一批...`);
          await this.sleep(50);
        }
        
      } catch (error) {
        console.error(`   ❌ 第 ${batchNumber} 批处理失败:`, error.message);
        throw error; // 重新导入时，任何错误都应该停止
      }
    }
  }

  async processBatch(batchData) {
    try {
      // 准备插入数据
      const insertData = batchData.map(addr => ({
        cexTag: addr.cexTag,
        symbol: addr.symbol,
        address: addr.address,
        isContract: addr.isContract || false
      }));

      // 直接插入（因为已经去重）
      const { data: insertResult, error: insertError } = await this.supabase
        .from(config.supabase.table)
        .insert(insertData)
        .select();

      if (insertError) {
        console.error(`   ❌ 批次insert失败:`, insertError.message);
        throw insertError;
      }

      // 统计结果
      const successCount = insertResult ? insertResult.length : 0;

      return {
        successCount,
        data: insertResult
      };
      
    } catch (error) {
      console.error(`   ❌ 批次处理失败:`, error.message);
      throw error;
    }
  }

  async sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // 验证数据完整性
  async validateData() {
    console.log('\n🔍 验证数据完整性...');
    
    try {
      // 查询数据库中的总记录数
      const { data: totalRecords, error: countError } = await this.supabase
        .from(config.supabase.table)
        .select('id', { count: 'exact' });

      if (countError) {
        console.error('❌ 查询总记录数失败:', countError.message);
        return;
      }

      console.log(`📊 数据库中的总记录数: ${totalRecords.length}`);
      
      // 按CEX统计
      const { data: cexStats, error: cexError } = await this.supabase
        .from(config.supabase.table)
        .select('cexTag')
        .order('cexTag');

      if (!cexError && cexStats) {
        const cexCounts = {};
        cexStats.forEach(record => {
          cexCounts[record.cexTag] = (cexCounts[record.cexTag] || 0) + 1;
        });
        
        console.log('📋 按CEX统计:');
        Object.entries(cexCounts).forEach(([cex, count]) => {
          console.log(`   ${cex}: ${count} 条记录`);
        });
      }
      
    } catch (error) {
      console.error('❌ 数据验证失败:', error.message);
    }
  }
}

// 主函数
async function main() {
  const importer = new DeduplicatedAddressImporter();
  
  try {
    // 导入去重后的数据
    await importer.importDeduplicatedAddresses();
    
    // 验证数据完整性
    await importer.validateData();
    
    console.log('\n🎉 所有操作完成！');
    
  } catch (error) {
    console.error('❌ 主程序执行失败:', error.message);
    process.exit(1);
  }
}

// 运行脚本
main();
