console.log('🧪 开始调试配置...\n');

try {
  console.log('📁 当前工作目录:', process.cwd());
  
  const config = await import('./config.js');
  console.log('✅ 配置文件导入成功');
  console.log('📋 配置对象:', config);
  
  if (config.default && config.default.supabase) {
    console.log('✅ Supabase配置存在');
    console.log('  URL:', config.default.supabase.url);
  } else {
    console.log('❌ Supabase配置不存在');
  }
  
} catch (error) {
  console.error('❌ 导入失败:', error.message);
  console.error('   堆栈:', error.stack);
}
