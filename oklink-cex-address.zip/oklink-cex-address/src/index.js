import axios from 'axios';
import puppeteer from 'puppeteer';
import fs from 'fs/promises';
import path from 'path';

class OKLinkCEXCollector {
  constructor() {
    this.baseURL = 'https://www.oklink.com';
    this.apiURL = 'https://www.oklink.com/api/explorer/v2/por/cexAssetDashboard';
    this.browser = null;
    this.page = null;
  }

  async init() {
    console.log('🚀 初始化浏览器...');
    this.browser = await puppeteer.launch({
      headless: false, // 设置为true可以隐藏浏览器界面
      executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
    this.page = await this.browser.newPage();
    
    // 设置用户代理
    await this.page.setUserAgent('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36');
    
    // 设置视口
    await this.page.setViewport({ width: 1920, height: 1080 });
  }

  async getAPIKey() {
    console.log('🔑 获取API Key...');
    
    try {
      // 访问CEX列表页面
      await this.page.goto(`${this.baseURL}/zh-hans/cex-list`, {
        waitUntil: 'networkidle2',
        timeout: 30000
      });

      // 等待页面加载完成
      await this.page.waitForTimeout(3000);

      // 监听网络请求，找到包含x-apikey的请求
      const apiKey = await this.page.evaluate(() => {
        return new Promise((resolve) => {
          const originalFetch = window.fetch;
          window.fetch = function(...args) {
            const url = args[0];
            if (typeof url === 'string' && url.includes('cexAssetDashboard')) {
              // 从请求头中提取x-apikey
              const headers = args[1]?.headers;
              if (headers && headers['x-apikey']) {
                resolve(headers['x-apikey']);
              }
            }
            return originalFetch.apply(this, args);
          };

          // 触发页面上的某些操作来发起API请求
          setTimeout(() => {
            // 尝试点击某些元素或滚动来触发API调用
            window.scrollTo(0, document.body.scrollHeight);
          }, 1000);
        });
      });

      if (apiKey) {
        console.log('✅ 成功获取API Key:', apiKey);
        return apiKey;
      }

      // 如果上面的方法没有获取到，尝试从localStorage或sessionStorage中获取
      const storageAPIKey = await this.page.evaluate(() => {
        return localStorage.getItem('x-apikey') || 
               sessionStorage.getItem('x-apikey') ||
               localStorage.getItem('apiKey') ||
               sessionStorage.getItem('apiKey');
      });

      if (storageAPIKey) {
        console.log('✅ 从存储中获取API Key:', storageAPIKey);
        return storageAPIKey;
      }

      // 尝试从页面源码中查找
      const pageContent = await this.page.content();
      const apiKeyMatch = pageContent.match(/x-apikey["\s]*:["\s]*([^"'\s]+)/i);
      
      if (apiKeyMatch) {
        console.log('✅ 从页面源码中获取API Key:', apiKeyMatch[1]);
        return apiKeyMatch[1];
      }

      throw new Error('无法获取API Key');
    } catch (error) {
      console.error('❌ 获取API Key失败:', error.message);
      throw error;
    }
  }

  async getCEXList(apiKey) {
    console.log('📊 获取CEX列表...');
    
    try {
      const headers = {
        'accept': 'application/json',
        'accept-language': 'en,zh-CN;q=0.9,zh;q=0.8',
        'app-type': 'web',
        'devid': '42cd1d80-81d4-4d91-9d30-d88f7810f9b5',
        'priority': 'u=1, i',
        'referer': 'https://www.oklink.com/zh-hans/cex-list',
        'sec-ch-ua': '"Not;A=Brand";v="99", "Google Chrome";v="139", "Chromium";v="139"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"macOS"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36',
        'x-apikey': apiKey,
        'x-cdn': 'https://static.oklink.com',
        'x-id-group': '2930153127995960001-c-24',
        'x-locale': 'zh_CN',
        'x-simulated-trading': 'undefined',
        'x-site-info': '9FjOikHdpRnblJCLiskTJx0SPJiOiUGZvNmIsIySIJiOi42bpdWZyJye',
        'x-utc': '8',
        'x-zkdex-env': '0'
      };

      const params = {
        offset: 0,
        scale: '24h',
        sort: 'totalValue,desc',
        t: Date.now()
      };

      const response = await axios.get(this.apiURL, {
        headers,
        params,
        timeout: 30000
      });

      console.log('✅ 成功获取CEX数据');
      return response.data;
    } catch (error) {
      console.error('❌ 获取CEX列表失败:', error.message);
      if (error.response) {
        console.error('响应状态:', error.response.status);
        console.error('响应数据:', error.response.data);
      }
      throw error;
    }
  }

  async saveData(data, filename = 'cex_data.json') {
    try {
      const outputDir = './output';
      await fs.mkdir(outputDir, { recursive: true });
      
      const filepath = path.join(outputDir, filename);
      await fs.writeFile(filepath, JSON.stringify(data, null, 2), 'utf8');
      
      console.log(`💾 数据已保存到: ${filepath}`);
    } catch (error) {
      console.error('❌ 保存数据失败:', error.message);
      throw error;
    }
  }

  async collectAllData() {
    try {
      await this.init();
      
      // 获取API Key
      const apiKey = await this.getAPIKey();
      
      // 获取CEX数据
      const cexData = await this.getCEXList(apiKey);
      
      // 保存数据
      await this.saveData(cexData);
      
      // 分析数据
      this.analyzeData(cexData);
      
      return cexData;
    } catch (error) {
      console.error('❌ 数据采集失败:', error.message);
      throw error;
    } finally {
      if (this.browser) {
        await this.browser.close();
      }
    }
  }

  analyzeData(data) {
    console.log('\n📈 数据分析结果:');
    console.log('='.repeat(50));
    
    if (data && data.data && data.data.cexList) {
      const cexList = data.data.cexList;
      console.log(`总CEX数量: ${cexList.length}`);
      
      // 按总价值排序
      const sortedByValue = [...cexList].sort((a, b) => 
        parseFloat(b.totalValue || 0) - parseFloat(a.totalValue || 0)
      );
      
      console.log('\n🏆 前10名CEX (按总价值排序):');
      sortedByValue.slice(0, 10).forEach((cex, index) => {
        console.log(`${index + 1}. ${cex.name || 'Unknown'} - 总价值: ${cex.totalValue || 'N/A'}`);
      });
      
      // 统计不同状态
      const statusCount = {};
      cexList.forEach(cex => {
        const status = cex.status || 'unknown';
        statusCount[status] = (statusCount[status] || 0) + 1;
      });
      
      console.log('\n📊 状态统计:');
      Object.entries(statusCount).forEach(([status, count]) => {
        console.log(`${status}: ${count}`);
      });
    } else {
      console.log('数据结构:', JSON.stringify(data, null, 2));
    }
  }

  async close() {
    if (this.browser) {
      await this.browser.close();
      console.log('🔒 浏览器已关闭');
    }
  }
}

// 主函数
async function main() {
  const collector = new OKLinkCEXCollector();
  
  try {
    console.log('🚀 开始CEX地址采集...');
    const result = await collector.collectAllData();
    console.log('✅ 采集完成!');
    return result;
  } catch (error) {
    console.error('❌ 程序执行失败:', error.message);
    process.exit(1);
  } finally {
    await collector.close();
  }
}

// 如果直接运行此文件
if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}

export default OKLinkCEXCollector;
