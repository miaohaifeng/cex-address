// 配置文件
export default {
  // API配置
  api: {
    baseURL: 'https://www.oklink.com/api/explorer/v2/por',
    timeout: 30000,
    maxRetries: 3
  },

  // 浏览器配置
  browser: {
    headless: process.env.HEADLESS === 'true' || false,
    timeout: parseInt(process.env.BROWSER_TIMEOUT) || 30000,
    executablePath: process.env.CHROME_PATH || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  },

  // 请求频率控制配置
  rateLimit: {
    // 基础延迟配置
    baseDelay: {
      BTC: 150,      // BTC链基础延迟150ms
      ETH: 150,      // ETH链基础延迟150ms
      SOLANA: 250,   // SOLANA链基础延迟250ms
      POLYGON: 250,  // POLYGON链基础延迟250ms
      default: 200   // 其他链默认延迟200ms
    },
    
    // CEX特定延迟配置
    cexDelay: {
      Binance: 50,   // Binance额外延迟50ms
      OKX: 50,       // OKX额外延迟50ms
      Kraken: 30,    // Kraken额外延迟30ms
      default: 0     // 其他CEX无额外延迟
    },
    
    // 批量请求延迟配置
    batchDelay: {
      every10Requests: 500,    // 每10个请求后额外延迟500ms
      every50Requests: 2000,   // 每50个请求后额外延迟2秒
      every100Requests: 5000   // 每100个请求后额外延迟5秒
    },
    
    // 随机化因子
    randomFactor: {
      min: 0.8,      // 最小随机因子
      max: 1.2       // 最大随机因子
    },
    
    // 错误重试延迟
    retryDelay: {
      INVALID_PARAM: 1000,     // 参数错误重试延迟1秒
      RATE_LIMIT: 5000,        // 频率限制重试延迟5秒
      default: 2000            // 其他错误重试延迟2秒
    }
  },

  // 输出配置
  output: {
    directory: './output',
    maxAddressesPerFile: 1000,
    saveIndividualCEX: true,
    saveCEXList: true,        // 是否保存CEX列表
    saveSummary: true,
    saveStandardFormat: true,
    // 日期文件夹配置
    dateFormat: 'YYYYMMDD', // 日期格式：20250117
    createDateFolders: true, // 是否创建日期文件夹
    overwriteExisting: true  // 是否覆盖已存在的文件
  },

  // 日志配置
  logging: {
    level: process.env.LOG_LEVEL || 'info',
    showProgress: true,
    showErrors: true,
    showWarnings: true
  }
};
