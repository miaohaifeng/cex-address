import SupabaseIntegration from './oklink/supabase-integration.js';

// 测试Supabase连接
async function testSupabaseConnection() {
  console.log('🧪 测试Supabase连接...\n');
  
  const supabase = new SupabaseIntegration();
  
  try {
    // 初始化连接
    console.log('🔗 初始化Supabase连接...');
    const initResult = supabase.init();
    
    if (initResult) {
      console.log('✅ Supabase连接初始化成功');
      
      // 检查连接状态
      const isConnected = supabase.isConnected();
      console.log(`🔍 连接状态: ${isConnected ? '已连接' : '未连接'}`);
      
      if (isConnected) {
        console.log('🎉 Supabase连接测试成功！');
      } else {
        console.log('❌ Supabase连接状态异常');
      }
      
    } else {
      console.log('❌ Supabase连接初始化失败');
    }
    
  } catch (error) {
    console.error('❌ 测试失败:', error.message);
  }
}

// 运行测试
if (import.meta.url === `file://${process.argv[1]}`) {
  testSupabaseConnection();
}

export default testSupabaseConnection;
