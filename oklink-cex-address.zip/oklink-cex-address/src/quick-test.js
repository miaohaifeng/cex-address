import UltimateAddressCollector from './ultimate-address-collector.js';

// 快速测试脚本
async function quickTest() {
  console.log('🧪 快速测试优化后的地址收集器...');
  
  const collector = new UltimateAddressCollector();
  
  try {
    // 初始化
    await collector.init();
    console.log('✅ 初始化成功');
    
    // 获取认证信息
    await collector.getLatestCredentials();
    console.log('✅ 认证信息获取成功');
    
    // 获取CEX列表
    const cexList = await collector.getCEXList();
    console.log(`✅ 获取到 ${cexList.length} 个CEX`);
    
    // 测试获取第一个CEX的第一个有效地址
    if (cexList.length > 0) {
      const firstCex = cexList[0];
      console.log(`\n🔍 测试获取 ${firstCex.cexTag} 的地址数据...`);
      
      if (firstCex.blockChainList && firstCex.blockChainList.length > 0 && 
          firstCex.symbolList && firstCex.symbolList.length > 0) {
        
        const chain = firstCex.blockChainList[0];
        const symbol = firstCex.symbolList[0];
        
        console.log(`📡 测试获取 ${chain.blockChain} 链上的 ${symbol.symbol} 地址...`);
        
        const addressData = await collector.getAddressDetails(
          firstCex.seoCexTag || firstCex.cexTag.toLowerCase(),
          chain.blockChain,
          symbol.symbol
        );
        
        if (addressData && addressData.hits) {
          console.log(`✅ 成功获取 ${addressData.hits.length} 个地址`);
          
          // 显示第一个地址的详细信息
          if (addressData.hits.length > 0) {
            const firstAddr = addressData.hits[0];
            console.log('\n🏆 第一个地址详情:');
            console.log(`   地址: ${firstAddr.address || firstAddr.walletAddress || 'N/A'}`);
            console.log(`   余额: ${firstAddr.value || firstAddr.balance || 'N/A'}`);
            console.log(`   美元价值: $${(firstAddr.usdValue || firstAddr.balanceUsd || 0).toFixed(2)}`);
            console.log(`   是否合约: ${firstAddr.isContract || false}`);
          }
        } else {
          console.log('⚠️ 未获取到地址数据');
        }
      }
    }
    
    console.log('\n✅ 快速测试完成!');
    
  } catch (error) {
    console.error('❌ 测试失败:', error.message);
  } finally {
    await collector.close();
  }
}

// 运行测试
quickTest();
