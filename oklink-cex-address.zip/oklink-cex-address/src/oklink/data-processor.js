import fs from 'fs/promises';
import path from 'path';

class DataProcessor {
  constructor() {
    this.dateFolderPath = null;
    this.dateFolderName = null;
  }

  // 设置日期文件夹
  setDateFolder(dateFolderName) {
    this.dateFolderName = dateFolderName;
    this.dateFolderPath = path.resolve(`./output/${dateFolderName}`);
  }

  // 创建输出目录
  async createOutputDirectory() {
    try {
      await fs.mkdir(this.dateFolderPath, { recursive: true });
      console.log(`📁 创建输出目录: ${this.dateFolderPath}`);
    } catch (error) {
      throw new Error(`创建输出目录失败: ${error.message}`);
    }
  }

  // 保存CEX列表
  async saveCexList(cexList) {
    try {
      const filePath = path.join(this.dateFolderPath, 'cex_list.json');
      const data = {
        timestamp: new Date().toISOString(),
        totalCEX: cexList.length,
        cexList: cexList
      };
      
      await fs.writeFile(filePath, JSON.stringify(data, null, 2));
      console.log(`💾 CEX列表已保存到: ${this.dateFolderName}/cex_list.json`);
      
      return data;
    } catch (error) {
      throw new Error(`保存CEX列表失败: ${error.message}`);
    }
  }

  // 保存链支持信息
  async saveChainSupportToken(cexTag, chainSupportData, isImmediate = false) {
    try {
      const filename = `${cexTag}_chain_support_token.json`;
      const filepath = path.join(this.dateFolderPath, filename);
      
      await fs.writeFile(filepath, JSON.stringify(chainSupportData, null, 2));
      
      if (isImmediate) {
        console.log(`💾 ${cexTag} 链支持信息已立即保存到: ${this.dateFolderName}/${filename}`);
      } else {
        console.log(`💾 ${cexTag} 链支持信息已保存到: ${this.dateFolderName}/${filename}`);
      }
      
      return filepath;
    } catch (error) {
      throw new Error(`保存${cexTag}链支持信息失败: ${error.message}`);
    }
  }

  // 保存CEX地址数据
  async saveCEXAddresses(cexTag, addresses) {
    try {
      const filename = `${cexTag}_addresses.json`;
      const filepath = path.join(this.dateFolderPath, filename);
      
      // 计算去重后的地址数量
      const uniqueAddresses = new Set();
      addresses.forEach(addr => {
        if (addr.address && addr.address.trim()) {
          uniqueAddresses.add(addr.address.trim());
        }
      });
      
      const data = {
        timestamp: new Date().toISOString(),
        cexTag: cexTag,
        totalAddresses: addresses.length,
        totalUniqueAddresses: uniqueAddresses.size,
        addresses: addresses
      };
      
      await fs.writeFile(filepath, JSON.stringify(data, null, 2));
      console.log(`💾 ${cexTag} 地址数据已保存到: ${this.dateFolderName}/${filename}`);
      console.log(`   📊 总地址数: ${addresses.length}, 唯一地址数: ${uniqueAddresses.size}`);
      
      return data;
    } catch (error) {
      throw new Error(`保存${cexTag}地址数据失败: ${error.message}`);
    }
  }

  // 保存标准格式数据
  async saveStandardFormat(addresses) {
    try {
      const standardData = {
        timestamp: new Date().toISOString(),
        totalAddresses: addresses.length,
        addresses: addresses.map(addr => ({
          cexTag: addr.cexTag,
          symbol: addr.symbol,
          address: addr.address,
          value: addr.value,
          usdValue: addr.usdValue,
          isContract: addr.isContract,
          blockChain: addr.blockChain
        }))
      };
      
      const filename = 'cex_addresses_standard.json';
      const filepath = path.join(this.dateFolderPath, filename);
      await fs.writeFile(filepath, JSON.stringify(standardData, null, 2));
      console.log(`💾 标准格式地址数据已保存到: ${this.dateFolderName}/${filename}`);
      
      return standardData;
    } catch (error) {
      throw new Error(`保存标准格式数据失败: ${error.message}`);
    }
  }

  // 保存汇总数据
  async saveSummary(cexResults) {
    try {
      const summary = {
        timestamp: new Date().toISOString(),
        totalCEX: cexResults.length,
        totalUniqueAddresses: 0,
        cexResults: {}
      };
      
      // 计算总地址数和各CEX的地址数
      for (const cexResult of cexResults) {
        const cexTag = cexResult.cexTag;
        const totalAddresses = cexResult.totalAddresses;
        const totalUniqueAddresses = cexResult.totalUniqueAddresses;
        
        summary.totalUniqueAddresses += totalUniqueAddresses;
        summary.cexResults[cexTag] = {
          totalAddresses,
          totalUniqueAddresses
        };
      }
      
      const filename = 'cex_addresses_summary.json';
      const filepath = path.join(this.dateFolderPath, filename);
      await fs.writeFile(filepath, JSON.stringify(summary, null, 2));
      console.log(`💾 汇总数据已保存到: ${this.dateFolderName}/${filename}`);
      
      return summary;
    } catch (error) {
      throw new Error(`保存汇总数据失败: ${error.message}`);
    }
  }

  // 保存总地址汇总
  async saveTotalAddressesSummary(cexResults, allAddresses) {
    try {
      const filePath = path.join(this.dateFolderPath, 'cex_addresses_total_summary.json');
      
      // 计算去重后的总地址数
      const uniqueAddresses = new Set();
      allAddresses.forEach(addr => {
        if (addr.address && addr.address.trim()) {
          uniqueAddresses.add(addr.address.trim());
        }
      });
      
      // 为每个CEX计算去重后的地址数量
      const cexUniqueResults = {};
      for (const [cexTag, result] of Object.entries(cexResults)) {
        if (result.error) {
          cexUniqueResults[cexTag] = { error: result.error };
        } else {
          // 获取该CEX的地址进行去重
          const cexAddresses = allAddresses.filter(addr => addr.cexTag === cexTag);
          const cexUniqueAddresses = new Set();
          cexAddresses.forEach(addr => {
            if (addr.address && addr.address.trim()) {
              cexUniqueAddresses.add(addr.address.trim());
            }
          });
          cexUniqueResults[cexTag] = {
            totalUniqueAddresses: cexUniqueAddresses.size
          };
        }
      }
      
      const data = {
        timestamp: new Date().toISOString(),
        totalCEX: Object.keys(cexResults).length,
        totalUniqueAddresses: uniqueAddresses.size,
        cexResults: cexUniqueResults
      };
      
      await fs.writeFile(filePath, JSON.stringify(data, null, 2), 'utf8');
      console.log(`📊 总地址汇总已保存到: ${this.dateFolderName}/cex_addresses_total_summary.json (去重后总计: ${uniqueAddresses.size} 个地址)`);
      
      return data;
    } catch (error) {
      throw new Error(`保存总地址汇总失败: ${error.message}`);
    }
  }

  // 显示保存的文件
  async showSavedFiles() {
    try {
      const files = await fs.readdir(this.dateFolderPath);
      const jsonFiles = files.filter(file => file.endsWith('.json'));
      
      console.log(`\n📋 日期文件夹 ${this.dateFolderName} 中的文件列表:`);
      for (const file of jsonFiles) {
        const filePath = path.join(this.dateFolderPath, file);
        const stats = await fs.stat(filePath);
        const fileSize = (stats.size / 1024).toFixed(2);
        console.log(`  📄 ${file} (${fileSize} KB)`);
      }
    } catch (error) {
      console.log('⚠️ 无法读取文件列表:', error.message);
    }
  }

  // 检查文件是否存在
  async fileExists(filePath) {
    try {
      await fs.access(filePath);
      return true;
    } catch {
      return false;
    }
  }

  // 获取日期文件夹路径
  getDateFolderPath() {
    return this.dateFolderPath;
  }

  // 获取日期文件夹名称
  getDateFolderName() {
    return this.dateFolderName;
  }
}

export default DataProcessor;
