import fs from 'fs/promises';
import path from 'path';

// 工具函数集合
export class Utils {
  // 生成当前日期文件夹名称
  static generateDateFolderName() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    return `${year}${month}${day}`;
  }

  // 智能延迟策略
  static calculateSmartDelay(cexTag, blockChain, symbol, requestCount) {
    let delay = 100; // 基础延迟
    
    // 根据链调整延迟
    const chainDelays = {
      'BTC': 150,
      'ETH': 120,
      'DOGE': 200,
      'BCH': 180,
      'LTC': 160
    };
    
    if (chainDelays[blockChain]) {
      delay = chainDelays[blockChain];
    }
    
    // 根据CEX调整延迟
    const cexDelays = {
      'binance': 80,
      'okx': 100,
      'kucoin': 120,
      'kraken': 150,
      'coinbase': 130
    };
    
    if (cexDelays[cexTag.toLowerCase()]) {
      delay += cexDelays[cexTag.toLowerCase()];
    }
    
    // 随机化延迟，避免被识别为机器人
    const randomFactor = 0.8 + Math.random() * 0.4; // 0.8-1.2
    delay = Math.floor(delay * randomFactor);
    
    // 批量请求延迟控制
    if (requestCount % 10 === 0) {
      delay += 50;
    }
    
    if (requestCount % 50 === 0) {
      delay += 100;
    }
    
    if (requestCount % 100 === 0) {
      delay += 200;
    }
    
    return delay;
  }

  // 睡眠函数
  static async sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // 检查是否应该重试
  static shouldRetry(error, maxRetries = 3) {
    if (error.message.includes('5004') || error.message.includes('VISIT_ALREADY_EXPIRED')) {
      return false; // 不重试过期错误
    }
    
    if (error.message.includes('5001') || error.message.includes('API_KEY_NOT_FIND')) {
      return false; // 不重试API密钥错误
    }
    
    if (error.message.includes('4001') || error.message.includes('INVALID_PARAM')) {
      return false; // 不重试参数错误
    }
    
    return true;
  }

  // 格式化错误信息
  static formatError(error, context = '') {
    const timestamp = new Date().toISOString();
    const errorInfo = {
      timestamp,
      context,
      message: error.message,
      stack: error.stack,
      type: error.constructor.name
    };
    
    return JSON.stringify(errorInfo, null, 2);
  }

  // 验证地址格式
  static isValidAddress(address) {
    if (!address || typeof address !== 'string') {
      return false;
    }
    
    const trimmedAddress = address.trim();
    if (trimmedAddress.length === 0) {
      return false;
    }
    
    // 基本的地址格式验证（可以根据需要扩展）
    const addressPatterns = {
      'BTC': /^[13][a-km-zA-HJ-NP-Z1-9]{25,34}$/,
      'ETH': /^0x[a-fA-F0-9]{40}$/,
      'DOGE': /^D{1}[5-9A-HJ-NP-U]{1}[1-9A-HJ-NP-Za-km-z]{32}$/,
      'BCH': /^[13][a-km-zA-HJ-NP-Z1-9]{25,34}$/,
      'LTC': /^[LM3][a-km-zA-HJ-NP-Z1-9]{26,33}$/
    };
    
    // 尝试匹配各种格式
    for (const [chain, pattern] of Object.entries(addressPatterns)) {
      if (pattern.test(trimmedAddress)) {
        return true;
      }
    }
    
    // 如果都不匹配，但长度合理，也认为是有效的
    return trimmedAddress.length >= 26 && trimmedAddress.length <= 100;
  }

  // 清理和标准化地址数据
  static cleanAddressData(addresses) {
    return addresses
      .filter(addr => {
        // 过滤掉无效地址
        if (!this.isValidAddress(addr.address)) {
          return false;
        }
        
        // 过滤掉缺少必要字段的记录
        if (!addr.cexTag || !addr.symbol) {
          return false;
        }
        
        return true;
      })
      .map(addr => ({
        ...addr,
        address: addr.address.trim(),
        cexTag: addr.cexTag.trim(),
        symbol: addr.symbol.trim(),
        value: parseFloat(addr.value) || 0,
        usdValue: parseFloat(addr.usdValue) || 0,
        isContract: Boolean(addr.isContract)
      }));
  }

  // 计算去重后的地址数量
  static countUniqueAddresses(addresses) {
    const uniqueAddresses = new Set();
    addresses.forEach(addr => {
      if (this.isValidAddress(addr.address)) {
        uniqueAddresses.add(addr.address.trim());
      }
    });
    return uniqueAddresses.size;
  }

  // 生成进度条
  static generateProgressBar(current, total, width = 30) {
    const percentage = total > 0 ? (current / total) : 0;
    const filledWidth = Math.round(width * percentage);
    const emptyWidth = width - filledWidth;
    
    const filled = '█'.repeat(filledWidth);
    const empty = '░'.repeat(emptyWidth);
    
    return `[${filled}${empty}] ${(percentage * 100).toFixed(1)}% (${current}/${total})`;
  }

  // 格式化文件大小
  static formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  // 获取文件统计信息
  static async getFileStats(filePath) {
    try {
      const stats = await fs.stat(filePath);
      return {
        size: stats.size,
        sizeFormatted: this.formatFileSize(stats.size),
        created: stats.birthtime,
        modified: stats.mtime,
        isFile: stats.isFile(),
        isDirectory: stats.isDirectory()
      };
    } catch (error) {
      return null;
    }
  }

  // 检查目录是否存在
  static async directoryExists(dirPath) {
    try {
      const stats = await fs.stat(dirPath);
      return stats.isDirectory();
    } catch {
      return false;
    }
  }

  // 创建目录（如果不存在）
  static async ensureDirectory(dirPath) {
    try {
      await fs.mkdir(dirPath, { recursive: true });
      return true;
    } catch (error) {
      console.error(`创建目录失败: ${dirPath}`, error.message);
      return false;
    }
  }

  // 清理旧文件
  static async cleanupOldFiles(directory, maxAge = 7 * 24 * 60 * 60 * 1000) { // 默认7天
    try {
      const files = await fs.readdir(directory);
      const now = Date.now();
      
      for (const file of files) {
        const filePath = path.join(directory, file);
        const stats = await fs.stat(filePath);
        
        if (now - stats.mtime.getTime() > maxAge) {
          await fs.unlink(filePath);
          console.log(`🗑️ 已删除旧文件: ${file}`);
        }
      }
    } catch (error) {
      console.error('清理旧文件失败:', error.message);
    }
  }
}

export default Utils;
