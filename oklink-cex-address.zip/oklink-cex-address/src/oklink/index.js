import OKLinkAddressCollector from './address-collector.js';

// 主函数
async function main() {
  const collector = new OKLinkAddressCollector();
  
  try {
    await collector.init();
    console.log('🎯 开始收集所有交易所地址...');
    
    // 收集所有CEX地址
    const result = await collector.collectAllAddresses();
    
    // 生成汇总数据
    console.log('\n📊 开始生成汇总数据...');
    await collector.generateSummaryData();
    
    // 执行Supabase导入
    console.log('\n🚀 开始执行Supabase数据导入...');
    await collector.importToSupabase();
    
    console.log('✅ 程序执行完成!');
    console.log('✅ 所有CEX地址已成功导入到Supabase!');
    return result;
    
  } catch (error) {
    console.error('❌ 程序执行失败:', error.message);
    process.exit(1);
  } finally {
    await collector.close();
  }
}

// 如果直接运行此文件
if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}

export default OKLinkAddressCollector;
