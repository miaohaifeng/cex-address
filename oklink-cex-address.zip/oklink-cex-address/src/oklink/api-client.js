import axios from 'axios';
import config from '../../config.js';

class OKLinkAPIClient {
  constructor() {
    this.baseURL = 'https://www.oklink.com/api/explorer/v2/por';
    this.headers = {};
    this.requestCount = 0;
  }

  // 设置认证头
  setAuthHeaders(apiKey, devId, xIdGroup) {
    this.headers = {
      'accept': 'application/json',
      'accept-language': 'en,zh-CN;q=0.9,zh;q=0.8',
      'app-type': 'web',
      'devid': devId,
      'priority': 'u=1, i',
      'sec-ch-ua': '"Not;A=Brand";v="99", "Google Chrome";v="139", "Chromium";v="139"',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-platform': '"macOS"',
      'sec-fetch-dest': 'empty',
      'sec-fetch-mode': 'cors',
      'sec-fetch-site': 'same-origin',
      'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36',
      'x-apikey': apiKey,
      'x-cdn': 'https://static.oklink.com',
      'x-id-group': xIdGroup,
      'x-locale': 'zh_CN',
      'x-simulated-trading': 'undefined',
      'x-site-info': '9FjOikHdpRnblJCLiskTJx0SPJiOiUGZvNmIsIySIJiOi42bpdWZyJye',
      'x-utc': '8',
      'x-zkdex-env': '0'
    };
  }

  // 获取CEX列表
  async getCexList() {
    try {
      const timestamp = Date.now();
      const url = `${this.baseURL}/cexAssetDashboard?offset=0&scale=24h&sort=totalValue%2Cdesc&t=${timestamp}`;
      
      console.log(`🌐 请求URL: ${url}`);
      console.log(`🔑 使用API密钥: ${this.headers['x-apikey'] ? '已设置' : '未设置'}`);
      
      const response = await axios.get(url, { headers: this.headers });
      
      console.log(`📡 API响应状态: ${response.status}`);
      
      // 调试：打印响应结构
      console.log(`🔍 响应数据结构:`, {
        hasData: !!response.data,
        hasCode: !!response.data?.code,
        hasDataField: !!response.data?.data,
        dataType: typeof response.data?.data,
        isArray: Array.isArray(response.data?.data),
        dataLength: response.data?.data?.length
      });
      
      // 首先检查API错误代码
      if (response.data && response.data.code && response.data.code !== 0 && response.data.code !== '0') {
        // 有错误代码，抛出相应的错误
        const errorCode = response.data.code;
        const errorMsg = response.data.msg || '未知错误';
        
        if (errorCode === 5004 || errorCode === '5004') {
          throw new Error(`VISIT_ALREADY_EXPIRED: ${errorMsg}`);
        } else if (errorCode === 5005 || errorCode === '5005') {
          throw new Error(`API_DECODE_ERROR: ${errorMsg}`);
        } else if (errorCode === 5001 || errorCode === '5001') {
          throw new Error(`API_KEY_NOT_FIND: ${errorMsg}`);
        } else {
          throw new Error(`API错误 (${errorCode}): ${errorMsg}`);
        }
      }
      
      // 检查响应结构
      if (response.data && response.data.code === 0 && response.data.data && response.data.data.hits) {
        // 标准格式：code=0, data.hits包含CEX列表
        console.log(`✅ API调用成功，返回 ${response.data.data.hits.length} 个CEX`);
        return response.data.data.hits;
      } else if (response.data && response.data.code === '0' && response.data.data && response.data.data.hits) {
        // 字符串格式的code
        console.log(`✅ API调用成功，返回 ${response.data.data.hits.length} 个CEX`);
        return response.data.data.hits;
      } else if (response.data && response.data.data && response.data.data.hits && Array.isArray(response.data.data.hits)) {
        // 没有code字段，但有data.hits
        console.log(`✅ API调用成功（无code字段），返回 ${response.data.data.hits.length} 个CEX`);
        return response.data.data.hits;
      } else if (response.data && Array.isArray(response.data)) {
        // 如果响应本身就是数组
        console.log(`✅ API调用成功（响应为数组），返回 ${response.data.length} 个CEX`);
        return response.data;
      } else {
        console.error(`❌ API响应格式异常:`, {
          data: response.data,
          dataType: typeof response.data,
          isArray: Array.isArray(response.data),
          hasHits: !!response.data?.data?.hits,
          hitsLength: response.data?.data?.hits?.length
        });
        throw new Error(`API返回错误: 响应格式异常`);
      }
    } catch (error) {
      if (error.response) {
        console.error(`❌ HTTP错误: ${error.response.status} - ${error.response.statusText}`);
        console.error(`❌ 响应数据:`, error.response.data);
      }
      throw new Error(`获取CEX列表失败: ${error.message}`);
    }
  }

  // 获取CEX支持的链列表（不包含币种信息）
  async getCexChainList(cexTag) {
    try {
      const timestamp = Date.now();
      const url = `${this.baseURL}/${cexTag}/getCexTokenList?t=${timestamp}`;
      
      console.log(`   🌐 请求${cexTag}链支持URL: ${url}`);
      
      const response = await axios.post(url, {}, { headers: this.headers });
      
      console.log(`   📡 ${cexTag} API响应状态: ${response.status}`);
      console.log(`   🔍 ${cexTag}响应数据结构:`, {
        hasData: !!response.data,
        hasCode: !!response.data?.code,
        hasDataField: !!response.data?.data,
        code: response.data?.code,
        msg: response.data?.msg
      });
      
      if (response.data && response.data.code === '0') {
        return response.data.data;
      } else if (response.data && response.data.code === 0) {
        return response.data.data;
      } else {
        throw new Error(`API返回错误: ${response.data?.msg || '未知错误'} (代码: ${response.data?.code || 'N/A'})`);
      }
    } catch (error) {
      if (error.response) {
        console.error(`   ❌ ${cexTag} HTTP错误: ${error.response.status} - ${error.response.statusText}`);
        console.error(`   ❌ ${cexTag}响应数据:`, error.response.data);
      }
      throw new Error(`获取${cexTag}支持的链列表失败: ${error.message}`);
    }
  }

  // 获取CEX支持的链和币种
  async getCexTokenList(cexTag, blockChain) {
    try {
      const timestamp = Date.now();
      const url = `${this.baseURL}/${cexTag}/getCexTokenList`;
      
      // 构建请求体，指定要查询的链
      const requestBody = { chains: [blockChain] };
      
      console.log(`   🌐 请求${cexTag}链支持URL: ${url}`);
      console.log(`   📋 请求参数: ${JSON.stringify(requestBody)}`);
      
      const response = await axios.post(url, requestBody, { 
        headers: {
          ...this.headers,
          'content-type': 'application/json',
          'origin': 'https://www.oklink.com',
          'referer': `https://www.oklink.com/zh-hans/cex-asset/${cexTag.toLowerCase()}/top100`
        }
      });
      
      console.log(`   📡 ${cexTag} API响应状态: ${response.status}`);
      console.log(`   🔍 ${cexTag}响应数据结构:`, {
        hasData: !!response.data,
        hasCode: !!response.data?.code,
        hasDataField: !!response.data?.data,
        code: response.data?.code,
        msg: response.data?.msg
      });
      
      if (response.data && response.data.code === '0') {
        return response.data.data;
      } else if (response.data && response.data.code === 0) {
        return response.data.data;
      } else {
        throw new Error(`API返回错误: ${response.data?.msg || '未知错误'} (代码: ${response.data?.code || 'N/A'})`);
      }
    } catch (error) {
      if (error.response) {
        console.error(`   ❌ ${cexTag} HTTP错误: ${error.response.status} - ${error.response.statusText}`);
        console.error(`   ❌ ${cexTag}响应数据:`, error.response.data);
      }
      throw new Error(`获取${cexTag}支持的链和币种失败: ${error.message}`);
    }
  }

  // 获取地址详情
  async getAddressDetails(cexTag, blockChain, symbol, limit = 100) {
    try {
      const timestamp = Date.now();
      // 修复：使用小写的cexTag，因为OKLink API对大小写敏感
      const lowerCexTag = cexTag.toLowerCase();
      const url = `${this.baseURL}/${lowerCexTag}/assets/detail?offset=0&blockChain=${blockChain}&symbols=${symbol}&limit=${limit}&t=${timestamp}`;
      
      console.log(`       🌐 请求地址详情URL: ${url}`);
      console.log(`       🔑 使用认证头: x-apikey=${this.headers['x-apikey'] ? '已设置' : '未设置'}, devid=${this.headers['devid'] ? '已设置' : '未设置'}`);
      
      const response = await axios.get(url, { headers: this.headers });
      
      console.log(`       📡 地址详情API响应状态: ${response.status}`);
      
      if (response.data && response.data.code === '0') {
        console.log(`       ✅ 成功获取 ${response.data.data?.hits?.length || 0} 个地址`);
        return response.data.data.hits || [];
      } else if (response.data && response.data.code === 0) {
        console.log(`       ✅ 成功获取 ${response.data.data?.hits?.length || 0} 个地址`);
        return response.data.data.hits || [];
      } else {
        throw new Error(`API返回错误: ${response.data?.msg || '未知错误'} (代码: ${response.data?.code || 'N/A'})`);
      }
    } catch (error) {
      if (error.response) {
        console.error(`       ❌ HTTP错误: ${error.response.status} - ${error.response.statusText}`);
        console.error(`       ❌ 响应数据:`, error.response.data);
      }
      throw new Error(`获取${cexTag}-${blockChain}-${symbol}地址详情失败: ${error.message}`);
    }
  }

  // 检查API响应错误
  checkAPIError(response, context) {
    if (response.code !== '0') {
      const errorMap = {
        '5001': 'API_KEY_NOT_FIND',
        '5004': 'VISIT_ALREADY_EXPIRED',
        '5005': 'API_DECODE_ERROR', // 修复：5005是API_DECODE_ERROR，不是RATE_LIMIT
        '5006': 'RATE_LIMIT',       // 添加：实际的限流错误码
        '4001': 'INVALID_PARAM'
      };
      
      const errorType = errorMap[response.code] || 'UNKNOWN_ERROR';
      const errorMessage = `${errorType}: ${response.msg || '未知错误'}`;
      
      throw new Error(`${context} - ${errorMessage}`);
    }
  }

  // 增加请求计数
  incrementRequestCount() {
    this.requestCount++;
  }

  // 获取请求计数
  getRequestCount() {
    return this.requestCount;
  }
}

export default OKLinkAPIClient;
