import { createClient } from '@supabase/supabase-js';
import config from '../../config.js';

class SupabaseIntegration {
  constructor() {
    this.supabase = null;
    this.existingRecordsForImport = new Set();
    this.importStats = {};
  }

  // 初始化Supabase连接
  init() {
    if (!config.supabase || !config.supabase.url || !config.supabase.serviceRoleKey) {
      console.log('⚠️ Supabase配置缺失，跳过数据库集成');
      return false;
    }

    try {
      this.supabase = createClient(config.supabase.url, config.supabase.serviceRoleKey);
      console.log('✅ Supabase连接初始化成功');
      return true;
    } catch (error) {
      console.error('❌ Supabase连接初始化失败:', error.message);
      return false;
    }
  }

  // 检查连接状态
  isConnected() {
    return this.supabase !== null;
  }

  // 加载数据库中已存在的记录
  async loadExistingRecordsForImport() {
    if (!this.isConnected()) {
      throw new Error('Supabase未连接');
    }

    console.log('📊 加载数据库中已存在的记录...');
    
    try {
      let offset = 0;
      const limit = 1000;
      let totalLoaded = 0;
      let startTime = Date.now();
      
      this.existingRecordsForImport.clear();
      
      while (true) {
        const { data: records, error: queryError } = await this.supabase
          .from(config.supabase.table)
          .select('cexTag, symbol, address')
          .range(offset, offset + limit - 1);

        if (queryError) {
          console.error('❌ 查询现有记录失败:', queryError.message);
          break;
        }

        if (!records || records.length === 0) {
          break;
        }

        // 添加到缓存
        records.forEach(record => {
          const key = `${record.cexTag}-${record.symbol}-${record.address}`;
          this.existingRecordsForImport.add(key);
        });

        totalLoaded += records.length;
        const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
        console.log(`   📥 已加载 ${totalLoaded} 条现有记录 (耗时: ${elapsed}s)...`);

        if (records.length < limit) {
          break; // 最后一页
        }

        offset += limit;
        
        // 避免长时间占用连接
        if (totalLoaded % 10000 === 0) {
          await this.sleep(100);
        }
      }

      const totalTime = ((Date.now() - startTime) / 1000).toFixed(1);
      console.log(`✅ 数据库中有 ${this.existingRecordsForImport.size} 条现有记录 (总耗时: ${totalTime}s)`);
      
    } catch (error) {
      console.error('❌ 加载现有记录失败:', error.message);
      throw error;
    }
  }

  // 过滤新记录
  filterNewAddresses(addresses) {
    console.log('🔍 过滤新记录...');
    
    const newAddresses = [];
    let skippedCount = 0;
    let startTime = Date.now();
    
    addresses.forEach((addr, index) => {
      const key = `${addr.cexTag}-${addr.symbol}-${addr.address}`;
      
      if (this.existingRecordsForImport.has(key)) {
        skippedCount++;
      } else {
        newAddresses.push(addr);
      }
      
      // 显示进度
      if ((index + 1) % 10000 === 0) {
        const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
        console.log(`   📊 已处理 ${index + 1}/${addresses.length} 条记录 (耗时: ${elapsed}s)...`);
      }
    });
    
    const totalTime = ((Date.now() - startTime) / 1000).toFixed(1);
    console.log(`✅ 过滤完成: 新记录 ${newAddresses.length}, 跳过 ${skippedCount} (总耗时: ${totalTime}s)`);
    
    this.importStats = {
      totalProcessed: addresses.length,
      totalNew: newAddresses.length,
      totalSkipped: skippedCount
    };
    
    return newAddresses;
  }

  // 批量导入到Supabase
  async batchImportToSupabase(newAddresses) {
    if (!this.isConnected()) {
      throw new Error('Supabase未连接');
    }

    console.log(`📦 开始批量导入 ${newAddresses.length} 条新记录...`);
    
    const BATCH_SIZE = 1000;
    let totalSuccess = 0;
    
    for (let i = 0; i < newAddresses.length; i += BATCH_SIZE) {
      const batch = newAddresses.slice(i, i + BATCH_SIZE);
      const batchNumber = Math.floor(i / BATCH_SIZE) + 1;
      const totalBatches = Math.ceil(newAddresses.length / BATCH_SIZE);
      
      console.log(`\n📦 处理第 ${batchNumber}/${totalBatches} 批 (${batch.length} 条记录)...`);
      
      try {
        const result = await this.processImportBatch(batch);
        totalSuccess += result.successCount;
        
        console.log(`   ✅ 第 ${batchNumber} 批完成: 成功 ${result.successCount}`);
        
        // 批次间延迟
        if (i + BATCH_SIZE < newAddresses.length) {
          const delay = this.calculateImportDelay(batchNumber, totalBatches);
          console.log(`   ⏰ 等待${delay}ms后处理下一批...`);
          await this.sleep(delay);
        }
        
      } catch (error) {
        console.error(`   ❌ 第 ${batchNumber} 批处理失败:`, error.message);
        throw error;
      }
    }
    
    this.importStats.totalSuccess = totalSuccess;
    console.log(`✅ 批量导入完成: 成功 ${totalSuccess}/${newAddresses.length} 条记录`);
  }

  // 处理单个批次
  async processImportBatch(batchData) {
    try {
      // 准备插入数据
      const insertData = batchData.map(addr => ({
        cexTag: addr.cexTag,
        symbol: addr.symbol,
        address: addr.address,
        isContract: addr.isContract || false,
        blockChain: addr.blockChain || null
      }));

      // 使用insert，设置ignoreDuplicates为true
      const { data: insertResult, error: insertError } = await this.supabase
        .from(config.supabase.table)
        .insert(insertData, {
          ignoreDuplicates: true // 忽略重复，只插入新记录
        })
        .select();

      if (insertError) {
        console.error(`   ❌ 批次insert失败:`, insertError.message);
        throw insertError;
      }

      return {
        successCount: insertResult ? insertResult.length : 0,
        data: insertResult
      };
      
    } catch (error) {
      console.error(`   ❌ 批次处理失败:`, error.message);
      throw error;
    }
  }

  // 计算导入延迟
  calculateImportDelay(batchNumber, totalBatches) {
    // 智能延迟策略
    let baseDelay = 100;
    
    // 根据批次数量调整延迟
    if (totalBatches > 50) {
      baseDelay = 150;
    } else if (totalBatches > 20) {
      baseDelay = 120;
    }
    
    // 批次越往后，延迟越长（避免被限流）
    const progressFactor = batchNumber / totalBatches;
    if (progressFactor > 0.8) {
      baseDelay = Math.floor(baseDelay * 1.5);
    }
    
    // 添加随机因子
    const randomFactor = 0.8 + Math.random() * 0.4; // 0.8-1.2
    
    return Math.floor(baseDelay * randomFactor);
  }

  // 生成导入报告
  async generateImportReport(newAddresses, dateFolderName) {
    console.log('📊 生成导入报告...');
    
    try {
      const report = {
        importDate: new Date().toISOString().split('T')[0],
        dateFolder: dateFolderName,
        timestamp: new Date().toISOString(),
        summary: {
          totalProcessed: this.importStats.totalProcessed,
          totalSuccess: this.importStats.totalSuccess,
          totalSkipped: this.importStats.totalSkipped,
          totalNew: this.importStats.totalNew,
          existingRecords: this.existingRecordsForImport.size
        },
        performance: {
          newRecordsPercentage: this.importStats.totalProcessed > 0 ? ((this.importStats.totalNew / this.importStats.totalProcessed) * 100).toFixed(2) : 0,
          skipRate: this.importStats.totalProcessed > 0 ? ((this.importStats.totalSkipped / this.importStats.totalProcessed) * 100).toFixed(2) : 0
        }
      };

      return report;
      
    } catch (error) {
      console.error('❌ 生成导入报告失败:', error.message);
      throw error;
    }
  }

  // 获取导入统计
  getImportStats() {
    return this.importStats;
  }

  // 获取现有记录数量
  getExistingRecordsCount() {
    return this.existingRecordsForImport.size;
  }

  // 睡眠函数
  async sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

export default SupabaseIntegration;
