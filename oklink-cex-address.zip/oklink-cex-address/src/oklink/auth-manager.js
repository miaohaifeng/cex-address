import puppeteer from 'puppeteer';
import config from '../../config.js';

class AuthManager {
  constructor() {
    this.browser = null;
    this.credentials = null;
  }

  // 获取最新的认证信息
  async getLatestCredentials() {
    try {
      console.log('🔑 开始获取最新认证信息...');
      
      // 启动新的浏览器实例
      this.browser = await puppeteer.launch({
        headless: config.browser.headless,
        executablePath: config.browser.executablePath,
        args: config.browser.args
      });

      const page = await this.browser.newPage();
      
      // 设置请求拦截
      await page.setRequestInterception(true);
      
      let apiKey = null;
      let devId = null;
      let xIdGroup = null;
      
      // 监听网络请求
      page.on('request', (request) => {
        const url = request.url();
        
        // 查找包含认证信息的请求
        if (url.includes('all-chain-list') || url.includes('cexAssetDashboard')) {
          const headers = request.headers();
          
          if (headers['x-apikey'] && !apiKey) {
            apiKey = headers['x-apikey'];
            console.log('✅ 获取到 x-apikey');
          }
          
          if (headers['devid'] && !devId) {
            devId = headers['devid'];
            console.log('✅ 获取到 devId');
          }
          
          if (headers['x-id-group'] && !xIdGroup) {
            xIdGroup = headers['x-id-group'];
            console.log('✅ 获取到 x-id-group');
          }
        }
        
        request.continue();
      });

      // 访问页面
      await page.goto('https://www.oklink.com/zh-hans/cex-list', {
        waitUntil: 'networkidle2',
        timeout: 30000
      });

      // 等待认证信息获取完成
      let attempts = 0;
      const maxAttempts = 10;
      
      while ((!apiKey || !devId || !xIdGroup) && attempts < maxAttempts) {
        await page.waitForTimeout(1000);
        attempts++;
        
        if (attempts % 2 === 0) {
          console.log(`   ⏳ 等待认证信息... (${attempts}/${maxAttempts})`);
        }
      }

      // 关闭浏览器
      await this.browser.close();
      this.browser = null;

      // 验证认证信息完整性
      if (!apiKey || !devId || !xIdGroup) {
        throw new Error(`认证信息不完整: apiKey=${!!apiKey}, devId=${!!devId}, xIdGroup=${!!xIdGroup}`);
      }

      this.credentials = { apiKey, devId, xIdGroup };
      
      console.log('🎉 认证信息获取成功！');
      return this.credentials;
      
    } catch (error) {
      if (this.browser) {
        await this.browser.close();
        this.browser = null;
      }
      throw new Error(`获取认证信息失败: ${error.message}`);
    }
  }

  // 获取当前认证信息
  getCredentials() {
    return this.credentials;
  }

  // 检查认证信息是否有效
  hasValidCredentials() {
    return this.credentials && 
           this.credentials.apiKey && 
           this.credentials.devId && 
           this.credentials.xIdGroup;
  }

  // 清除认证信息
  clearCredentials() {
    this.credentials = null;
  }

  // 关闭浏览器
  async close() {
    if (this.browser) {
      await this.browser.close();
      this.browser = null;
    }
  }
}

export default AuthManager;
