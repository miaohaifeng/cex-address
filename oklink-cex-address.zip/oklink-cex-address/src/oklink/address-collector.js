import AuthManager from './auth-manager.js';
import OKLinkAPIClient from './api-client.js';
import DataProcessor from './data-processor.js';
import SupabaseIntegration from './supabase-integration.js';
import Utils from './utils.js';
import config from '../../config.js';
import fs from 'fs/promises';
import path from 'path';

class OKLinkAddressCollector {
  constructor() {
    this.authManager = new AuthManager();
    this.apiClient = new OKLinkAPIClient();
    this.dataProcessor = new DataProcessor();
    this.supabaseIntegration = new SupabaseIntegration();
    
    this.cexResults = [];
    this.allAddresses = [];
    this.requestCount = 0;
    this.dateFolderName = null;
  }

  // 初始化收集器
  async init() {
    try {
      console.log('🚀 初始化OKLink地址收集器...');
      
      // 生成日期文件夹名称
      this.dateFolderName = Utils.generateDateFolderName();
      this.dataProcessor.setDateFolder(this.dateFolderName);
      
      // 创建输出目录
      await this.dataProcessor.createOutputDirectory();
      
      // 初始化Supabase连接
      if (config.supabase) {
        console.log('🔗 初始化Supabase连接...');
        const supabaseInitResult = this.supabaseIntegration.init();
        if (supabaseInitResult) {
          console.log('✅ Supabase连接初始化成功');
        } else {
          console.log('⚠️ Supabase连接初始化失败，将跳过数据库导入');
        }
      } else {
        console.log('⚠️ 未配置Supabase，将跳过数据库导入');
      }
      
      console.log('✅ 收集器初始化完成');
      
    } catch (error) {
      throw new Error(`初始化失败: ${error.message}`);
    }
  }

  // 收集所有地址
  async collectAllAddresses() {
    try {
      console.log('🎯 开始收集所有交易所地址...');
      
      // 第一步：获取认证信息
      await this.getLatestCredentials();
      
      // 第二步：获取CEX列表
      const cexList = await this.getCexList();
      
      // 第三步：保存CEX列表
      await this.dataProcessor.saveCexList(cexList);
      
      // 第四步：收集每个CEX的地址
      await this.collectAllCexAddresses(cexList);
      
      // 第五步：生成汇总数据
      await this.generateSummaryData();
      
      // 第六步：显示结果
      await this.dataProcessor.showSavedFiles();
      
      console.log('🎉 地址收集完成！');
      return true;
      
    } catch (error) {
      console.error('❌ 地址收集失败:', error.message);
      throw error;
    }
  }

  // 获取最新认证信息
  async getLatestCredentials() {
    try {
      const credentials = await this.authManager.getLatestCredentials();
      
      // 设置API客户端的认证头
      this.apiClient.setAuthHeaders(
        credentials.apiKey,
        credentials.devId,
        credentials.xIdGroup
      );
      
      console.log('✅ 认证信息设置完成');
      
    } catch (error) {
      throw new Error(`获取认证信息失败: ${error.message}`);
    }
  }

  // 获取CEX列表
  async getCexList() {
    try {
      console.log('📋 获取CEX列表...');
      const cexList = await this.apiClient.getCexList();
      console.log(`✅ 获取到 ${cexList.length} 个CEX`);
      return cexList;
      
    } catch (error) {
      throw new Error(`获取CEX列表失败: ${error.message}`);
    }
  }

  // 收集所有CEX的地址
  async collectAllCexAddresses(cexList) {
    // 🧪 测试模式：只处理Kraken（可以改为false来处理所有CEX）
    const testMode = true;
    let targetCexList = cexList;
    
    if (testMode) {
      targetCexList = cexList.filter(cex => cex.cexTag === 'Kraken');
      console.log(`🧪 测试模式：只处理 ${targetCexList.length} 个CEX (Kraken)`);
    } else {
      console.log(`🚀 生产模式：处理所有 ${targetCexList.length} 个CEX`);
    }
    
    console.log(`\n🔄 开始收集 ${targetCexList.length} 个CEX的地址...`);
    
    for (let i = 0; i < targetCexList.length; i++) {
      const cex = targetCexList[i];
      const cexTag = cex.cexTag;
      
      console.log(`\n📊 处理第 ${i + 1}/${targetCexList.length} 个CEX: ${cexTag}`);
      
      try {
        // 收集单个CEX的地址
        const result = await this.collectSingleCexAddresses(cexTag);
        this.cexResults.push(result);
        
        // 显示进度
        const progress = Utils.generateProgressBar(i + 1, targetCexList.length);
        console.log(`   ${progress}`);
        
      } catch (error) {
        console.error(`❌ 处理 ${cexTag} 失败:`, error.message);
        
        // 记录错误结果
        this.cexResults.push({
          cexTag,
          error: error.message,
          totalAddresses: 0,
          totalUniqueAddresses: 0
        });
      }
      
      // 智能延迟
      if (i < targetCexList.length - 1) {
        // CEX间智能延迟控制
        await this.smartDelay(cexTag, 'default', 'cex_complete');
      }
    }
  }

  // 收集单个CEX的地址
  async collectSingleCexAddresses(cexTag) {
    try {
      // 获取CEX支持的链列表（不包含币种信息）
      const chainListData = await this.getCexChainList(cexTag);
      
      // 保存链支持信息（初始版本，不包含币种）
      await this.dataProcessor.saveChainSupportToken(cexTag, chainListData, true);
      
      // 收集地址（按照ultimate-address-collector.js的逻辑）
      const addresses = await this.getAllAddressesForCEX(cexTag, chainListData.blockChainList);
      
      // 保存CEX地址数据
      const result = await this.dataProcessor.saveCEXAddresses(cexTag, addresses);
      
      // 添加到总地址列表
      this.allAddresses.push(...addresses);
      
      return {
        cexTag,
        totalAddresses: addresses.length,
        totalUniqueAddresses: result.totalUniqueAddresses
      };
      
    } catch (error) {
      throw new Error(`收集${cexTag}地址失败: ${error.message}`);
    }
  }

  // 获取CEX支持的链列表（不包含币种信息）
  async getCexChainList(cexTag) {
    try {
      const chainListData = await this.apiClient.getCexChainList(cexTag);
      
      if (!chainListData || !chainListData.blockChainList) {
        throw new Error('返回数据格式错误');
      }
      
      console.log(`   📊 ${cexTag} 支持 ${chainListData.blockChainList.length} 条链`);
      
      return chainListData;
      
    } catch (error) {
      // 检查是否需要重新获取认证信息
      if (error.message.includes('5004') || error.message.includes('VISIT_ALREADY_EXPIRED') || 
          error.message.includes('5005') || error.message.includes('API_DECODE_ERROR')) {
        console.log(`   🔄 ${cexTag} 认证信息过期或无效，重新获取...`);
        await this.getLatestCredentials();
        return await this.apiClient.getCexChainList(cexTag);
      }
      
      throw error;
    }
  }

  // 获取CEX支持的链和币种（按照ultimate-address-collector.js的逻辑）
  async getCexTokenList(cexTag, blockChain) {
    try {
      const tokenListData = await this.apiClient.getCexTokenList(cexTag, blockChain);
      
      if (!tokenListData) {
        return null;
      }
      
      return tokenListData;
      
    } catch (error) {
      // 检查是否需要重新获取认证信息
      if (error.message.includes('5004') || error.message.includes('VISIT_ALREADY_EXPIRED') || 
          error.message.includes('5005') || error.message.includes('API_DECODE_ERROR')) {
        console.log(`   🔄 ${cexTag}-${blockChain} 认证信息过期或无效，重新获取...`);
        await this.getLatestCredentials();
        return await this.apiClient.getCexTokenList(cexTag, blockChain);
      }
      
      throw error;
    }
  }

  // 获取CEX的所有地址（按照ultimate-address-collector.js的逻辑）
  async getAllAddressesForCEX(cexTag, blockChains) {
    const allAddresses = [];
    const chainSupportData = [];
    
    // 第一步：获取每个链支持的币种列表
    for (const chain of blockChains) {
      const blockChain = chain.blockChain;
      console.log(`     🔗 获取 ${blockChain} 链支持的币种列表...`);
      
      try {
        // 获取该链支持的币种列表
        const tokenListData = await this.getCexTokenList(cexTag, blockChain);
        
        if (tokenListData && tokenListData.tokenList && tokenListData.tokenList.length > 0) {
          const supportedTokens = tokenListData.tokenList;
          console.log(`       ✅ ${blockChain} 链支持 ${supportedTokens.length} 个币种: ${supportedTokens.map(t => t.symbol).join(', ')}`);
          
          // 保存链支持币种信息
          chainSupportData.push({
            blockChain: chain.blockChain,
            blockChainId: chain.blockChainId,
            logo: chain.logo,
            lightLogo: chain.lightLogo,
            supportedTokens: supportedTokens
          });
          
          // 第二步：为每个支持的币种获取地址详情
          for (const token of supportedTokens) {
            console.log(`         📡 获取 ${blockChain} 链上的 ${token.symbol} 地址...`);
            
            try {
              const addressData = await this.getAddressDetails(cexTag, blockChain, token.symbol);
              
              if (addressData && addressData.hits) {
                // 处理地址数据，按照要求的格式
                const addresses = addressData.hits.map(hit => ({
                  cexTag: cexTag,
                  symbol: token.symbol,
                  address: hit.address || hit.walletAddress || '',
                  value: hit.value || hit.balance || 0,
                  usdValue: hit.usdValue || hit.balanceUsd || 0,
                  isContract: hit.isContract || false,
                  blockChain: blockChain
                }));
                
                allAddresses.push(...addresses);
                console.log(`           ✅ 获取到 ${addresses.length} 个地址`);
              }
              
              // 智能延迟控制
              await this.smartDelay(cexTag, blockChain, token.symbol);
              
            } catch (error) {
              console.error(`           ❌ 获取失败: ${error.message}`);
            }
          }
        } else {
          console.warn(`       ⚠️ ${blockChain} 链没有返回币种列表或币种列表为空`);
          console.warn(`       返回数据:`, JSON.stringify(tokenListData, null, 2));
          
          // 即使没有币种列表，也保存链信息
          chainSupportData.push({
            blockChain: chain.blockChain,
            blockChainId: chain.blockChainId,
            logo: chain.logo,
            lightLogo: chain.lightLogo,
            supportedTokens: []
          });
        }
        
      } catch (error) {
        console.error(`     ❌ 获取 ${blockChain} 链币种列表失败: ${error.message}`);
        // 即使失败，也保存链信息
        chainSupportData.push({
          blockChain: chain.blockChain,
          blockChainId: chain.blockChainId,
          logo: chain.logo,
          lightLogo: chain.lightLogo,
          supportedTokens: []
        });
      }
      
      // 链间智能延迟控制
      await this.smartDelay(cexTag, blockChain, 'chain_complete');
    }
    
    // 所有链处理完成后，保存完整的链支持币种列表
    await this.dataProcessor.saveChainSupportToken(cexTag, chainSupportData, false);
    
    console.log(`  ✅ ${cexTag} 总共收集到 ${allAddresses.length} 个地址`);
    return allAddresses;
  }

  // 智能延迟控制（按照ultimate-address-collector.js的逻辑）
  async smartDelay(cexTag, blockChain, symbol) {
    // 智能延迟策略，防止被OKLink封禁
    let delay = config.rateLimit.baseDelay[blockChain] || config.rateLimit.baseDelay.default;
    
    // 根据CEX调整延迟
    delay += config.rateLimit.cexDelay[cexTag.toLowerCase()] || config.rateLimit.cexDelay.default;
    
    // 随机化延迟，避免被识别为机器人
    const randomFactor = config.rateLimit.randomFactor.min + 
                        Math.random() * (config.rateLimit.randomFactor.max - config.rateLimit.randomFactor.min);
    delay = Math.floor(delay * randomFactor);
    
    // 批量请求延迟控制
    this.requestCount++;
    if (this.requestCount % 10 === 0) {
      delay += config.rateLimit.batchDelay.every10Requests;
      console.log(`    ⏰ 已发送${this.requestCount}个请求，增加额外延迟${config.rateLimit.batchDelay.every10Requests}ms`);
    }
    
    if (this.requestCount % 50 === 0) {
      delay += config.rateLimit.batchDelay.every50Requests;
      console.log(`    ⏰ 已发送${this.requestCount}个请求，增加额外延迟${config.rateLimit.batchDelay.every50Requests}ms`);
    }
    
    if (this.requestCount % 100 === 0) {
      delay += config.rateLimit.batchDelay.every100Requests;
      console.log(`    ⏰ 已发送${this.requestCount}个请求，增加额外延迟${config.rateLimit.batchDelay.every100Requests}ms`);
    }
    
    console.log(`    ⏰ 智能延迟: ${delay}ms (${cexTag}-${blockChain}-${symbol})`);
    await Utils.sleep(delay);
  }

  // 获取地址详情
  async getAddressDetails(cexTag, blockChain, symbol) {
    try {
      this.requestCount++;
      this.apiClient.incrementRequestCount();
      
      const addressData = await this.apiClient.getAddressDetails(cexTag, blockChain, symbol);
      
      // 修复：api-client.js 已经返回了 hits 数组，直接使用
      if (!addressData || !Array.isArray(addressData)) {
        console.log(`       ⚠️ ${cexTag}-${blockChain}-${symbol}: 无地址数据或格式错误`);
        return [];
      }
      
      console.log(`       📊 ${cexTag}-${blockChain}-${symbol}: 获取到 ${addressData.length} 个地址`);
      return addressData;
      
    } catch (error) {
      // 检查是否需要重新获取认证信息
      if (error.message.includes('5004') || error.message.includes('VISIT_ALREADY_EXPIRED') || 
          error.message.includes('5005') || error.message.includes('API_DECODE_ERROR')) {
        console.log(`       🔄 ${cexTag}-${blockChain}-${symbol} 认证信息过期或无效，重新获取...`);
        await this.getLatestCredentials();
        return await this.apiClient.getAddressDetails(cexTag, blockChain, symbol);
      }
      
      throw error;
    }
  }

  // 生成汇总数据
  async generateSummaryData() {
    try {
      console.log('\n📊 生成汇总数据...');
      
      // 清理和标准化地址数据
      const cleanedAddresses = Utils.cleanAddressData(this.allAddresses);
      
      // 保存标准格式数据
      await this.dataProcessor.saveStandardFormat(cleanedAddresses);
      
      // 保存汇总数据
      await this.dataProcessor.saveSummary(this.cexResults);
      
      // 保存总地址汇总
      await this.dataProcessor.saveTotalAddressesSummary(this.cexResults, cleanedAddresses);
      
      // 注意：Supabase导入现在由外部调用，不在这里执行
      
    } catch (error) {
      console.error('❌ 生成汇总数据失败:', error.message);
    }
  }

  // 增量导入到Supabase
  async importToSupabase() {
    try {
      // 第一步：加载数据库中已存在的记录
      await this.supabaseIntegration.loadExistingRecordsForImport();
      
      // 第二步：读取并过滤新记录
      const standardFilePath = path.join(this.dataProcessor.getDateFolderPath(), 'cex_addresses_standard.json');
      if (!await this.dataProcessor.fileExists(standardFilePath)) {
        console.log('⚠️ 标准地址文件不存在，跳过数据库导入');
        return;
      }
      
      const fileContent = await fs.readFile(standardFilePath, 'utf8');
      const data = JSON.parse(fileContent);
      
      if (!data.addresses || !Array.isArray(data.addresses)) {
        throw new Error('地址数据格式错误');
      }
      
      // 过滤新记录
      const newAddresses = this.supabaseIntegration.filterNewAddresses(data.addresses);
      
      if (newAddresses.length === 0) {
        console.log('✅ 所有记录都已存在，无需导入');
        return;
      }
      
      // 第三步：批量导入新记录
      await this.supabaseIntegration.batchImportToSupabase(newAddresses);
      
      // 第四步：生成导入报告
      const report = await this.supabaseIntegration.generateImportReport(newAddresses, this.dataProcessor.getDateFolderName());
      
      // 保存导入报告
      const reportPath = path.join(this.dataProcessor.getDateFolderPath(), `import_report_${report.importDate}.json`);
      await fs.writeFile(reportPath, JSON.stringify(report, null, 2));
      
      console.log('📋 导入报告:');
      console.log(`   导入日期: ${report.importDate}`);
      console.log(`   目标文件夹: ${report.dateFolder}`);
      console.log(`   总处理: ${report.summary.totalProcessed}`);
      console.log(`   成功插入: ${report.summary.totalSuccess}`);
      console.log(`   跳过重复: ${report.summary.totalSkipped}`);
      console.log(`   新增记录: ${report.summary.totalNew}`);
      console.log(`   新记录比例: ${report.performance.newRecordsPercentage}%`);
      console.log(`   跳过率: ${report.performance.skipRate}%`);
      console.log(`   报告已保存到: ${reportPath}`);
      
    } catch (error) {
      console.error('❌ Supabase导入失败:', error.message);
    }
  }




  // 关闭收集器
  async close() {
    try {
      await this.authManager.close();
      console.log('✅ 收集器已关闭');
    } catch (error) {
      console.error('❌ 关闭收集器失败:', error.message);
    }
  }
}

export default OKLinkAddressCollector;
