# 🏗️ OKLink 模块化架构

## 📁 模块结构

```
src/oklink/
├── index.js                    # 🎯 主入口文件
├── address-collector.js        # 🚀 主收集器（协调所有模块）
├── api-client.js              # 🌐 API客户端（处理HTTP请求）
├── auth-manager.js            # 🔑 认证管理器（获取API密钥）
├── data-processor.js          # 💾 数据处理器（文件操作）
├── supabase-integration.js    # 🗄️ Supabase集成（数据库操作）
├── utils.js                   # 🛠️ 工具函数（通用功能）
└── README.md                  # 📖 本说明文档
```

## 🔧 各模块职责

### 1. `index.js` - 主入口
- **职责**: 程序入口点，初始化主收集器
- **功能**: 启动程序，错误处理，资源清理
- **依赖**: `address-collector.js`

### 2. `address-collector.js` - 主收集器
- **职责**: 协调所有模块，实现主要业务逻辑
- **功能**: 
  - 初始化所有子模块
  - 控制数据收集流程
  - 错误处理和重试逻辑
  - 进度监控和报告
- **依赖**: 所有其他模块

### 3. `api-client.js` - API客户端
- **职责**: 处理与OKLink API的所有HTTP请求
- **功能**:
  - 设置认证头
  - 发送API请求
  - 处理API响应
  - 错误检查
- **依赖**: `axios`, `config.js`

### 4. `auth-manager.js` - 认证管理器
- **职责**: 获取和管理API认证信息
- **功能**:
  - 使用Puppeteer获取动态API密钥
  - 管理认证状态
  - 浏览器资源管理
- **依赖**: `puppeteer`, `config.js`

### 5. `data-processor.js` - 数据处理器
- **职责**: 处理所有文件和数据操作
- **功能**:
  - 创建输出目录
  - 保存各种格式的JSON文件
  - 文件存在性检查
  - 数据统计和汇总
- **依赖**: `fs/promises`, `path`

### 6. `supabase-integration.js` - Supabase集成
- **职责**: 处理数据库操作
- **功能**:
  - 连接管理
  - 增量导入
  - 批量处理
  - 性能优化
- **依赖**: `@supabase/supabase-js`, `config.js`

### 7. `utils.js` - 工具函数
- **职责**: 提供通用工具函数
- **功能**:
  - 智能延迟计算
  - 数据验证和清理
  - 进度条生成
  - 文件操作辅助
- **依赖**: `fs/promises`, `path`

## 🔄 数据流向

```
认证管理器 → API客户端 → 主收集器 → 数据处理器 → 文件系统
                ↓
            Supabase集成 → 数据库
```

## 🎯 设计原则

### 1. **单一职责原则**
- 每个模块只负责一个特定功能
- 模块间职责清晰，边界明确

### 2. **高内聚低耦合**
- 模块内部功能紧密相关
- 模块间通过明确的接口通信

### 3. **可复用性**
- 工具函数可在多个模块中使用
- API客户端可独立使用
- 数据处理器可处理不同类型的数据

### 4. **可测试性**
- 每个模块可独立测试
- 依赖注入，便于模拟测试

### 5. **可维护性**
- 代码结构清晰，易于理解
- 错误处理统一，便于调试

## 🚀 使用方法

### 基本使用
```javascript
import OKLinkAddressCollector from './oklink/index.js';

const collector = new OKLinkAddressCollector();
await collector.init();
await collector.collectAllAddresses();
await collector.close();
```

### 单独使用模块
```javascript
// 只使用API客户端
import OKLinkAPIClient from './oklink/api-client.js';
const apiClient = new OKLinkAPIClient();

// 只使用数据处理器
import DataProcessor from './oklink/data-processor.js';
const dataProcessor = new DataProcessor();

// 只使用工具函数
import Utils from './oklink/utils.js';
const delay = Utils.calculateSmartDelay('binance', 'BTC', 'BTC', 1);
```

## 🔧 扩展指南

### 添加新的API端点
1. 在 `api-client.js` 中添加新方法
2. 在 `address-collector.js` 中调用新方法
3. 在 `data-processor.js` 中添加相应的数据处理逻辑

### 添加新的数据格式
1. 在 `data-processor.js` 中添加新的保存方法
2. 在 `address-collector.js` 中调用新方法
3. 更新相关的数据结构

### 添加新的数据库支持
1. 创建新的集成模块（如 `mysql-integration.js`）
2. 实现相同的接口
3. 在 `address-collector.js` 中替换或添加新的集成

## 📊 性能优化

### 1. **批量处理**
- 数据保存使用批量操作
- 数据库导入使用批次处理

### 2. **智能延迟**
- 根据CEX和链类型调整延迟
- 避免被API限流

### 3. **内存管理**
- 分批加载数据库记录
- 及时清理不需要的数据

### 4. **错误恢复**
- 自动重试机制
- 认证信息自动刷新

## 🚨 注意事项

### 1. **模块依赖**
- 确保模块加载顺序正确
- 避免循环依赖

### 2. **错误处理**
- 每个模块都要有适当的错误处理
- 错误信息要包含足够的上下文

### 3. **资源管理**
- 及时关闭数据库连接
- 清理浏览器资源

### 4. **配置管理**
- 敏感信息通过配置文件管理
- 支持环境变量覆盖

## 🔄 版本兼容性

- **Node.js**: >= 16.0.0
- **ES Modules**: 支持
- **依赖包**: 见 `package.json`

## 📞 技术支持

如果遇到问题，请检查：
1. 模块依赖是否正确
2. 配置文件是否完整
3. 错误日志中的具体信息
4. 各模块的初始化状态
