import UltimateAddressCollector from './ultimate-address-collector.js';

async function testSupabase() {
  const collector = new UltimateAddressCollector();
  
  try {
    await collector.init();
    
    // 检查Supabase连接
    if (!collector.supabase) {
      console.log('❌ Supabase未配置，请检查环境变量');
      return;
    }
    
    console.log('✅ Supabase客户端已初始化');
    
    // 测试数据库连接
    try {
      const { data, error } = await collector.supabase
        .from('cex-address')
        .select('count')
        .limit(1);
      
      if (error) {
        console.error('❌ 数据库连接测试失败:', error.message);
        return;
      }
      
      console.log('✅ 数据库连接测试成功');
      
    } catch (error) {
      console.error('❌ 数据库连接失败:', error.message);
      return;
    }
    
    // 获取最新认证信息
    await collector.getLatestCredentials();
    
    // 获取CEX列表
    const cexList = await collector.getCEXList();
    
    console.log(`\n🧪 测试Supabase数据保存功能`);
    console.log(`📊 总共 ${cexList.length} 个CEX`);
    
    // 只测试第一个CEX来验证逻辑
    const firstCex = cexList[0];
    console.log(`\n🔍 测试CEX: ${firstCex.cexTag}`);
    
    try {
      const addresses = await collector.getAllAddressesForCEX(firstCex);
      console.log(`✅ ${firstCex.cexTag} 处理完成，收集到 ${addresses.length} 个地址`);
      
      // 保存结果（会自动保存到Supabase）
      await collector.saveCEXAddresses(firstCex.cexTag, addresses);
      
    } catch (error) {
      console.error(`❌ 处理失败:`, error.message);
    }
    
    console.log('\n✅ Supabase集成测试完成！');
    
  } catch (error) {
    console.error('❌ 测试失败:', error.message);
  } finally {
    await collector.close();
  }
}

// 运行测试
testSupabase();
