import OKLinkCEXCollector from './index.js';
import APIKeyExtractor from './apiKeyExtractor.js';

// 示例1: 只提取API Key
async function extractAPIKeyOnly() {
  console.log('🔑 示例1: 只提取API Key');
  
  const extractor = new APIKeyExtractor();
  
  try {
    await extractor.init();
    const apiKey = await extractor.extractAPIKey();
    
    if (apiKey) {
      console.log('✅ 成功提取API Key:', apiKey);
      
      // 可以保存API Key供后续使用
      console.log('💡 你可以保存这个API Key用于其他用途');
    } else {
      console.log('❌ 未能提取到API Key');
    }
    
  } catch (error) {
    console.error('❌ 提取失败:', error.message);
  } finally {
    await extractor.close();
  }
}

// 示例2: 使用已知的API Key获取数据
async function getDataWithKnownAPIKey(apiKey) {
  console.log('📊 示例2: 使用已知API Key获取数据');
  
  if (!apiKey) {
    console.log('❌ 请提供有效的API Key');
    return;
  }
  
  const collector = new OKLinkCEXCollector();
  
  try {
    await collector.init();
    const cexData = await collector.getCEXList(apiKey);
    
    console.log('✅ 数据获取成功!');
    console.log('📈 数据概览:');
    
    if (cexData && cexData.data && cexData.data.cexList) {
      const cexList = cexData.data.cexList;
      console.log(`- 总CEX数量: ${cexList.length}`);
      
      // 显示前5个CEX
      cexList.slice(0, 5).forEach((cex, index) => {
        console.log(`  ${index + 1}. ${cex.name || 'Unknown'} - 总价值: ${cex.totalValue || 'N/A'}`);
      });
    }
    
    // 保存数据
    await collector.saveData(cexData, 'example_cex_data.json');
    
  } catch (error) {
    console.error('❌ 数据获取失败:', error.message);
  } finally {
    await collector.close();
  }
}

// 示例3: 完整的数据采集流程
async function fullDataCollection() {
  console.log('🚀 示例3: 完整的数据采集流程');
  
  const collector = new OKLinkCEXCollector();
  
  try {
    const result = await collector.collectAllData();
    console.log('✅ 完整采集成功!');
    return result;
  } catch (error) {
    console.error('❌ 完整采集失败:', error.message);
    throw error;
  }
}

// 示例4: 批量获取不同时间范围的数据
async function batchDataCollection() {
  console.log('📅 示例4: 批量获取不同时间范围的数据');
  
  const timeScales = ['1h', '24h', '7d', '30d'];
  const results = {};
  
  for (const scale of timeScales) {
    console.log(`\n🕐 获取 ${scale} 时间范围的数据...`);
    
    try {
      const collector = new OKLinkCEXCollector();
      await collector.init();
      
      // 获取API Key
      const apiKey = await collector.getAPIKey();
      
      // 获取数据
      const cexData = await collector.getCEXList(apiKey);
      
      // 保存数据
      await collector.saveData(cexData, `cex_data_${scale}.json`);
      
      results[scale] = cexData;
      console.log(`✅ ${scale} 数据获取成功`);
      
      await collector.close();
      
      // 避免请求过于频繁
      await new Promise(resolve => setTimeout(resolve, 2000));
      
    } catch (error) {
      console.error(`❌ ${scale} 数据获取失败:`, error.message);
      results[scale] = null;
    }
  }
  
  console.log('\n📊 批量采集完成!');
  console.log('结果概览:', Object.keys(results).map(scale => `${scale}: ${results[scale] ? '成功' : '失败'}`).join(', '));
  
  return results;
}

// 示例5: 自定义数据分析
async function customDataAnalysis() {
  console.log('🔍 示例5: 自定义数据分析');
  
  try {
    const collector = new OKLinkCEXCollector();
    const result = await collector.collectAllData();
    
    if (result && result.data && result.data.cexList) {
      const cexList = result.data.cexList;
      
      // 自定义分析1: 按资产类型分组
      const assetTypeGroups = {};
      cexList.forEach(cex => {
        const assetType = cex.assetType || 'unknown';
        if (!assetTypeGroups[assetType]) {
          assetTypeGroups[assetType] = [];
        }
        assetTypeGroups[assetType].push(cex);
      });
      
      console.log('\n📊 按资产类型分组:');
      Object.entries(assetTypeGroups).forEach(([type, cexs]) => {
        console.log(`- ${type}: ${cexs.length} 个CEX`);
      });
      
      // 自定义分析2: 价值分布
      const totalValues = cexList
        .map(cex => parseFloat(cex.totalValue || 0))
        .filter(value => !isNaN(value))
        .sort((a, b) => b - a);
      
      if (totalValues.length > 0) {
        const max = Math.max(...totalValues);
        const min = Math.min(...totalValues);
        const avg = totalValues.reduce((sum, val) => sum + val, 0) / totalValues.length;
        
        console.log('\n💰 价值分布分析:');
        console.log(`- 最高价值: ${max.toFixed(2)}`);
        console.log(`- 最低价值: ${min.toFixed(2)}`);
        console.log(`- 平均价值: ${avg.toFixed(2)}`);
        console.log(`- 中位数: ${totalValues[Math.floor(totalValues.length / 2)].toFixed(2)}`);
      }
      
      // 自定义分析3: 保存分析结果
      const analysisResult = {
        timestamp: new Date().toISOString(),
        totalCEX: cexList.length,
        assetTypeGroups,
        valueAnalysis: {
          max: Math.max(...totalValues),
          min: Math.min(...totalValues),
          average: totalValues.reduce((sum, val) => sum + val, 0) / totalValues.length,
          median: totalValues[Math.floor(totalValues.length / 2)]
        }
      };
      
      await collector.saveData(analysisResult, 'custom_analysis.json');
      console.log('\n💾 自定义分析结果已保存');
    }
    
  } catch (error) {
    console.error('❌ 自定义分析失败:', error.message);
  }
}

// 主函数 - 运行所有示例
async function runExamples() {
  console.log('🚀 开始运行OKLink CEX采集器示例...\n');
  
  try {
    // 示例1: 只提取API Key
    await extractAPIKeyOnly();
    
    console.log('\n' + '='.repeat(60) + '\n');
    
    // 示例2: 使用已知API Key（这里使用你提供的API Key作为示例）
    const knownAPIKey = 'LWIzMWUtNDU0Ny05Mjk5LWI2ZDA3Yjc2MzFhYmEyYzkwM2NjfDI4NjY0MjQxNjc2ODc3Njc=';
    await getDataWithKnownAPIKey(knownAPIKey);
    
    console.log('\n' + '='.repeat(60) + '\n');
    
    // 示例3: 完整数据采集
    await fullDataCollection();
    
    console.log('\n' + '='.repeat(60) + '\n');
    
    // 示例4: 批量数据采集
    await batchDataCollection();
    
    console.log('\n' + '='.repeat(60) + '\n');
    
    // 示例5: 自定义数据分析
    await customDataAnalysis();
    
    console.log('\n✅ 所有示例运行完成!');
    
  } catch (error) {
    console.error('\n❌ 示例运行过程中出现错误:', error.message);
  }
}

// 如果直接运行此文件
if (import.meta.url === `file://${process.argv[1]}`) {
  runExamples();
}

export {
  extractAPIKeyOnly,
  getDataWithKnownAPIKey,
  fullDataCollection,
  batchDataCollection,
  customDataAnalysis,
  runExamples
};
