import puppeteer from 'puppeteer';
import axios from 'axios';
import fs from 'fs/promises';
import path from 'path';
import { createClient } from '@supabase/supabase-js';
import config from './config.js';

class UltimateAddressCollector {
  constructor() {
    this.baseURL = config.api.baseURL;
    this.outputDir = path.resolve(config.output.basePath);
    this.browser = null;
    this.page = null;
    this.apiKey = null;
    this.devId = null;
    this.xIdGroup = null;
    this.requestCount = 0;
    this.errorCount = 0;
    
    // 初始化Supabase客户端
    if (config.supabase && config.supabase.url && config.supabase.serviceRoleKey) {
      // 使用service_role密钥，绕过RLS策略
      this.supabase = createClient(config.supabase.url, config.supabase.serviceRoleKey);
      console.log(`✅ Supabase客户端已初始化（使用service_role密钥）`);
      console.log(`👤 用户ID: ${config.supabase.userId}`);
    } else if (config.supabase && config.supabase.url && config.supabase.anonKey) {
      // 使用anon密钥（受RLS策略限制）
      this.supabase = createClient(config.supabase.url, config.supabase.anonKey);
      console.log(`✅ Supabase客户端已初始化（使用anon密钥）`);
      console.log(`👤 用户ID: ${config.supabase.userId}`);
      console.log('ℹ️ 注意：将受RLS策略限制');
    } else {
      this.supabase = null;
      console.log('⚠️ Supabase配置缺失，跳过数据库保存');
    }
  }

  async init() {
    console.log('🚀 初始化终极地址收集器...');
    
    this.browser = await puppeteer.launch({
      headless: config.browser.headless,
      executablePath: config.browser.executablePath,
      args: config.browser.args
    });
    
    this.page = await this.browser.newPage();
    
    // 设置用户代理
    await this.page.setUserAgent('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36');
    
    // 设置视口
    await this.page.setViewport({ width: 1920, height: 1080 });
    
    // 创建日期文件夹
    await this.createDateFolder();
  }

  async createDateFolder() {
    // 生成当前日期文件夹名
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    this.dateFolderName = `${year}${month}${day}`;
    
    // 创建日期文件夹路径
    this.dateFolderPath = `${this.outputDir}/${this.dateFolderName}`;
    
    // 创建日期文件夹
    await fs.mkdir(this.dateFolderPath, { recursive: true });
    
    console.log(`📁 创建日期文件夹: ${this.dateFolderName}`);
    console.log(`📂 完整路径: ${this.dateFolderPath}`);
  }

  async testApiKeyValidity() {
    // 使用一个简单的API调用来测试key是否有效
    try {
      const response = await axios.get(`${this.baseURL}/binance/getCexTokenList?t=${Date.now()}`, {
        headers: this.getHeaders(),
        timeout: 10000
      });
      
      if (response.data && response.data.code === '0') {
        return true; // API key有效
      } else {
        throw new Error(`API响应异常: ${response.data?.msg || '未知错误'}`);
      }
    } catch (error) {
      if (error.response && error.response.data) {
        const errorCode = error.response.data.code;
        const errorMsg = error.response.data.msg;
        throw new Error(`${errorCode}: ${errorMsg}`);
      }
      throw error;
    }
  }

  async getLatestCredentials() {
    console.log('🔑 自动获取最新的API Key和认证信息...');
    
    try {
      // 每次获取认证信息时都创建新的浏览器实例，避免请求拦截冲突
      const browser = await puppeteer.launch({
        headless: config.browser.headless,
        executablePath: config.browser.executablePath,
        args: config.browser.args
      });
      
      const page = await browser.newPage();
      
      // 设置请求拦截
      await page.setRequestInterception(true);
      
      let apiKey = null;
      let devId = null;
      let xIdGroup = null;
      
      // 设置请求拦截器
      page.on('request', (request) => {
        const url = request.url();
        const headers = request.headers();
        
        // 寻找API Key
        if (url.includes('all-chain-list') && headers['x-apikey']) {
          apiKey = headers['x-apikey'];
          console.log('✅ 发现API Key:', apiKey);
        }
        
        // 寻找devId
        if (headers['devid']) {
          devId = headers['devid'];
          console.log('✅ 发现devId:', devId);
        }
        
        // 寻找x-id-group
        if (headers['x-id-group']) {
          xIdGroup = headers['x-id-group'];
          console.log('✅ 发现x-id-group:', xIdGroup);
        }
        
        request.continue();
      });

      // 访问CEX列表页面
      console.log('📱 访问CEX列表页面...');
      await page.goto('https://www.oklink.com/zh-hans/cex-list', {
        waitUntil: 'networkidle2',
        timeout: 30000
      });

      // 等待页面加载
      await page.waitForTimeout(5000);

      // 如果还没有获取到，尝试从localStorage和cookie获取
      if (!apiKey || !devId || !xIdGroup) {
        console.log('🔍 尝试从存储中获取认证信息...');
        
        const credentials = await page.evaluate(() => {
          const devId = localStorage.getItem('devId');
          const cookies = document.cookie.split(';');
          let traceId = null;
          
          for (const cookie of cookies) {
            if (cookie.trim().startsWith('traceId=')) {
              traceId = cookie.split('=')[1];
              break;
            }
          }
          
          return { devId, traceId };
        });
        
        if (credentials.devId && !devId) {
          devId = credentials.devId;
          console.log('✅ 从localStorage获取devId:', devId);
        }
        
        if (credentials.traceId && !xIdGroup) {
          xIdGroup = `${credentials.traceId}-c-1`;
          console.log('✅ 从cookie获取x-id-group:', xIdGroup);
        }
      }

      // 如果还是没有API Key，尝试从页面源码中查找
      if (!apiKey) {
        console.log('🔍 尝试从页面源码中查找API Key...');
        
        const pageContent = await page.content();
        const apiKeyMatch = pageContent.match(/x-apikey["\s]*:["\s]*([^"'\s]+)/i);
        
        if (apiKeyMatch) {
          apiKey = apiKeyMatch[1];
          console.log('✅ 从页面源码中获取API Key:', apiKey);
        }
      }

      // 如果还是没有API Key，尝试监听JavaScript变量
      if (!apiKey) {
        console.log('🔍 尝试监听JavaScript变量...');
        
        apiKey = await page.evaluate(() => {
          return new Promise((resolve) => {
            let found = false;
            
            // 拦截fetch请求
            const originalFetch = window.fetch;
            window.fetch = function(...args) {
              const url = args[0];
              if (typeof url === 'string' && url.includes('all-chain-list')) {
                const headers = args[1]?.headers;
                if (headers && headers['x-apikey']) {
                  found = true;
                  resolve(headers['x-apikey']);
                }
              }
              return originalFetch.apply(this, args);
            };

            // 超时处理
            setTimeout(() => {
              if (!found) {
                resolve(null);
              }
            }, 15000);
          });
        });
      }

      // 关闭浏览器
      await browser.close();
      
      if (!apiKey || !devId || !xIdGroup) {
        throw new Error(`认证信息不完整: apiKey=${!!apiKey}, devId=${!!devId}, xIdGroup=${!!xIdGroup}`);
      }
      
      // 更新认证信息
      this.apiKey = apiKey;
      this.devId = devId;
      this.xIdGroup = xIdGroup;
      
      console.log('🎉 成功获取所有认证信息!');
      console.log('- API Key:', apiKey);
      console.log('- devId:', devId);
      console.log('- x-id-group:', xIdGroup);
      
    } catch (error) {
      console.error('❌ 获取认证信息失败:', error.message);
      throw error;
    }
  }

  async getHeaders() {
    return {
      'accept': 'application/json',
      'accept-language': 'en,zh-CN;q=0.9,zh;q=0.8',
      'app-type': 'web',
      'devid': this.devId,
      'priority': 'u=1, i',
      'referer': 'https://www.oklink.com/zh-hans/cex-list',
      'sec-ch-ua': '"Not;A=Brand";v="99", "Google Chrome";v="139", "Chromium";v="139"',
      'sec-ch-ua-mobile': '?0',
      'sec-ch-ua-platform': '"macOS"',
      'sec-fetch-dest': 'empty',
      'sec-fetch-mode': 'cors',
      'sec-fetch-site': 'same-origin',
      'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36',
      'x-apikey': this.apiKey,
      'x-cdn': 'https://static.oklink.com',
      'x-id-group': this.xIdGroup,
      'x-locale': 'zh_CN',
      'x-simulated-trading': 'undefined',
      'x-site-info': '9FjOikHdpRnblJCLiskTJx0SPJiOiUGZvNmIsIySIJiOi42bpdWZyJye',
      'x-utc': '8',
      'x-zkdex-env': '0'
    };
  }

  async getCEXList() {
    console.log('📊 获取CEX列表...');
    
    try {
      const response = await axios.get(`${this.baseURL}/cexAssetDashboard`, {
        headers: await this.getHeaders(),
        params: {
          offset: 0,
          scale: '24h',
          sort: 'totalValue,desc',
          t: Date.now()
        },
        timeout: 30000
      });

      if (response.data.code === 0 && response.data.data.hits) {
        console.log(`✅ 成功获取 ${response.data.data.hits.length} 个CEX`);
        return response.data.data.hits;
      } else {
        throw new Error(`获取CEX列表失败: ${response.data.msg}`);
      }
    } catch (error) {
      console.error('❌ 获取CEX列表失败:', error.message);
      throw error;
    }
  }

  async getCexTokenList(cexTag, blockChain, retryCount = 0) {
    const url = `${this.baseURL}/${cexTag.toLowerCase()}/getCexTokenList`;
    
    // 构建完整的URL用于日志记录
    const fullUrl = `${url}?t=${Date.now()}`;
    
    try {
      const response = await axios.post(url, 
        { chains: [blockChain] },
        {
          headers: {
            ...await this.getHeaders(),
            'content-type': 'application/json',
            'origin': 'https://www.oklink.com',
            'referer': `https://www.oklink.com/zh-hans/cex-asset/${cexTag.toLowerCase()}/top100`
          },
          timeout: config.api.timeout
        }
      );

      if (response.data.code === 0) {
        return response.data.data;
      } else {
        console.warn(`⚠️ 获取币种列表失败 [${cexTag}-${blockChain}]`);
        console.warn(`   请求URL: ${fullUrl}`);
        console.warn(`   请求数据: {"chains":["${blockChain}"]}`);
        console.warn(`   错误代码: ${response.data.code}`);
        console.warn(`   错误信息: ${response.data.msg}`);
        
        // 如果是API key过期，立即重新获取并重试
        if (response.data.code === '5004' || response.data.msg.includes('VISIT_ALREADY_EXPIRED')) {
          if (retryCount < 1) {
            console.log(`   🔄 API key已过期，立即重新获取...`);
            try {
              await this.getLatestCredentials();
              console.log(`   ✅ 已重新获取API key，重试请求...`);
              return await this.getCexTokenList(cexTag, blockChain, retryCount + 1);
            } catch (refreshError) {
              console.error(`   ❌ 重新获取API key失败:`, refreshError.message);
            }
          }
        }
        
        // 根据错误类型决定是否重试
        if (this.shouldRetry(response.data.code, response.data.msg) && retryCount < config.api.maxRetries) {
          const retryDelay = this.getRetryDelay(response.data.msg);
          console.log(`    🔄 将在${retryDelay}ms后重试 (第${retryCount + 1}次)`);
          await this.sleep(retryDelay);
          return this.getCexTokenList(cexTag, blockChain, retryCount + 1);
        }
        
        return null;
      }
    } catch (error) {
      console.warn(`⚠️ 请求币种列表失败 [${cexTag}-${blockChain}]`);
      console.warn(`   请求URL: ${fullUrl}`);
      console.warn(`   错误类型: ${error.name}`);
      console.warn(`   错误信息: ${error.message}`);
      
      if (error.response) {
        console.warn(`   响应状态: ${error.response.status}`);
        console.warn(`   响应数据: ${JSON.stringify(error.response.data)}`);
      }
      
      // 网络错误重试
      if (retryCount < config.api.maxRetries && this.isNetworkError(error)) {
        const retryDelay = config.rateLimit.retryDelay.default;
        console.log(`    🔄 网络错误，将在${retryDelay}ms后重试 (第${retryCount + 1}次)`);
        await this.sleep(retryDelay);
        return this.getCexTokenList(cexTag, blockChain, retryCount + 1);
      }
      
      return null;
    }
  }

  async getAddressDetails(cexTag, blockChain, symbol, offset = 0, limit = 100, retryCount = 0) {
    const url = `${this.baseURL}/${cexTag.toLowerCase()}/assets/detail`;
    
    // 构建完整的URL用于日志记录
    const fullUrl = `${url}?offset=${offset}&blockChain=${blockChain}&symbols=${symbol}&limit=${limit}&t=${Date.now()}`;
    
    try {
      const response = await axios.get(url, {
        headers: await this.getHeaders(),
        params: {
          offset,
          blockChain,
          symbols: symbol,
          limit,
          t: Date.now()
        },
        timeout: config.api.timeout
      });

      if (response.data.code === 0) {
        return response.data.data;
      } else {
        console.warn(`⚠️ 获取地址详情失败 [${cexTag}-${blockChain}-${symbol}]`);
        console.warn(`   请求URL: ${fullUrl}`);
        console.warn(`   错误代码: ${response.data.code}`);
        console.warn(`   错误信息: ${response.data.msg}`);
        console.warn(`   详细错误: ${response.data.detailMsg || '无'}`);
        
        // 如果是API key过期，立即重新获取并重试
        if (response.data.code === '5004' || response.data.msg.includes('VISIT_ALREADY_EXPIRED')) {
          if (retryCount < 1) {
            console.log(`   🔄 API key已过期，立即重新获取...`);
            try {
              await this.getLatestCredentials();
              console.log(`   ✅ 已重新获取API key，重试请求...`);
              return await this.getAddressDetails(cexTag, blockChain, symbol, offset, limit, retryCount + 1);
            } catch (refreshError) {
              console.error(`   ❌ 重新获取API key失败:`, refreshError.message);
            }
          }
        }
        
        // 根据错误类型决定是否重试
        if (this.shouldRetry(response.data.code, response.data.msg) && retryCount < config.api.maxRetries) {
          const retryDelay = this.getRetryDelay(response.data.msg);
          console.log(`    🔄 将在${retryDelay}ms后重试 (第${retryCount + 1}次)`);
          await this.sleep(retryDelay);
          return this.getAddressDetails(cexTag, blockChain, symbol, offset, limit, retryCount + 1);
        }
        
        return null;
      }
    } catch (error) {
      console.warn(`⚠️ 请求失败 [${cexTag}-${blockChain}-${symbol}]`);
      console.warn(`   请求URL: ${fullUrl}`);
      console.warn(`   请求URL: ${fullUrl}`);
      console.warn(`   错误类型: ${error.name}`);
      console.warn(`   错误信息: ${error.message}`);
      
      if (error.response) {
        console.warn(`   响应状态: ${error.response.status}`);
        console.warn(`   响应数据: ${JSON.stringify(error.response.data)}`);
      }
      
      // 网络错误重试
      if (retryCount < config.api.maxRetries && this.isNetworkError(error)) {
        const retryDelay = config.rateLimit.retryDelay.default;
        console.log(`    🔄 网络错误，将在${retryDelay}ms后重试 (第${retryCount + 1}次)`);
        await this.sleep(retryDelay);
        return this.getAddressDetails(cexTag, blockChain, symbol, offset, limit, retryCount + 1);
      }
      
      return null;
    }
  }

  shouldRetry(errorCode, errorMsg) {
    // 判断是否应该重试
    const retryableErrors = ['RATE_LIMIT', 'TIMEOUT', 'NETWORK_ERROR'];
    
    // API key过期不应该通过普通重试机制处理，而是通过专门的刷新机制
    if (errorCode === '5004' || errorMsg.includes('VISIT_ALREADY_EXPIRED')) {
      return false;
    }
    
    return retryableErrors.some(err => errorMsg.includes(err));
  }

  getRetryDelay(errorMsg) {
    // 根据错误类型获取重试延迟
    if (errorMsg.includes('INVALID_PARAM')) {
      return config.rateLimit.retryDelay.INVALID_PARAM;
    } else if (errorMsg.includes('RATE_LIMIT')) {
      return config.rateLimit.retryDelay.RATE_LIMIT;
    }
    return config.rateLimit.retryDelay.default;
  }

  isNetworkError(error) {
    // 判断是否为网络错误
    return error.code === 'ECONNRESET' || 
           error.code === 'ENOTFOUND' || 
           error.code === 'ETIMEDOUT' ||
           error.message.includes('timeout');
  }

  async getAllAddressesForCEX(cex) {
    console.log(`\n🔍 收集 ${cex.cexTag} 的地址信息...`);
    
    const allAddresses = [];
    const blockChains = cex.blockChainList || [];
    
    console.log(`  - 支持链数: ${blockChains.length}`);
    
    // 存储每个链支持的币种信息
    const chainSupportData = [];
    
    // 第一步：获取每个链支持的币种列表
    for (const chain of blockChains) {
      console.log(`    🔗 获取 ${chain.blockChain} 链支持的币种列表...`);
      
      try {
        // 获取该链支持的币种列表
        const tokenListData = await this.getCexTokenList(
          cex.seoCexTag || cex.cexTag.toLowerCase(),
          chain.blockChain
        );
        
        if (tokenListData && tokenListData.tokenList && tokenListData.tokenList.length > 0) {
          const supportedTokens = tokenListData.tokenList;
          console.log(`      ✅ ${chain.blockChain} 链支持 ${supportedTokens.length} 个币种: ${supportedTokens.map(t => t.symbol).join(', ')}`);
          
          // 保存链支持币种信息
          chainSupportData.push({
            blockChain: chain.blockChain,
            blockChainId: chain.blockChainId,
            logo: chain.logo,
            lightLogo: chain.lightLogo,
            supportedTokens: supportedTokens
          });
          
          // 第二步：为每个支持的币种获取地址详情
          for (const token of supportedTokens) {
            console.log(`        📡 获取 ${chain.blockChain} 链上的 ${token.symbol} 地址...`);
            
            try {
              const addressData = await this.getAddressDetails(
                cex.seoCexTag || cex.cexTag.toLowerCase(),
                chain.blockChain,
                token.symbol
              );
              
              if (addressData && addressData.hits) {
                // 处理地址数据，按照你要求的格式
                const addresses = addressData.hits.map(hit => ({
                  cexTag: cex.cexTag,
                  symbol: token.symbol,
                  address: hit.address || hit.walletAddress || '',
                  value: hit.value || hit.balance || 0,
                  usdValue: hit.usdValue || hit.balanceUsd || 0,
                  isContract: hit.isContract || false
                }));
                
                allAddresses.push(...addresses);
                console.log(`          ✅ 获取到 ${addresses.length} 个地址`);
              }
              
              // 智能请求频率控制
              await this.smartDelay(cex.cexTag, chain.blockChain, token.symbol);
              
            } catch (error) {
              console.error(`          ❌ 获取失败: ${error.message}`);
            }
          }
        } else {
          console.warn(`      ⚠️ ${chain.blockChain} 链没有返回币种列表或币种列表为空`);
          console.warn(`      返回数据:`, JSON.stringify(tokenListData, null, 2));
          
          // 即使没有币种列表，也保存链信息
          chainSupportData.push({
            blockChain: chain.blockChain,
            blockChainId: chain.blockChainId,
            logo: chain.logo,
            lightLogo: chain.lightLogo,
            supportedTokens: []
          });
        }
        
      } catch (error) {
        console.error(`    ❌ 获取 ${chain.blockChain} 链币种列表失败: ${error.message}`);
        // 即使失败，也保存链信息
        chainSupportData.push({
          blockChain: chain.blockChain,
          blockChainId: chain.blockChainId,
          logo: chain.logo,
          lightLogo: chain.lightLogo,
          supportedTokens: []
        });
      }
      
    }
    
    // 所有链处理完成后，保存完整的链支持币种列表
    await this.saveChainSupportToken(cex.cexTag, chainSupportData, false);
    
    console.log(`  ✅ ${cex.cexTag} 总共收集到 ${allAddresses.length} 个地址`);
    return allAddresses;
  }

  async collectAllAddresses() {
    console.log('🚀 开始终极自动化收集所有CEX的地址信息...');
    
    try {
      // 获取最新认证信息
      await this.getLatestCredentials();
      
      // 获取CEX列表
      const cexList = await this.getCEXList();
      
      // 保存CEX列表到日期文件夹（如果配置允许）
      if (config.output.saveCEXList) {
        await this.saveCEXList(cexList);
      }
      
      // 收集所有地址
      const allAddresses = [];
      const cexResults = {};
      
      for (let i = 0; i < cexList.length; i++) {
        const cex = cexList[i];
        
        try {
          // 每处理3个CEX后，检查并重新获取API key
          if (i > 0 && i % 3 === 0) {
            console.log(`\n🔄 已处理 ${i} 个CEX，检查API key状态...`);
            try {
              // 尝试一个简单的API调用来验证key是否有效
              await this.testApiKeyValidity();
              console.log('✅ API key仍然有效，继续处理...');
            } catch (error) {
              if (error.message.includes('5004') || error.message.includes('VISIT_ALREADY_EXPIRED')) {
                console.log('⚠️ API key已过期，重新获取...');
                await this.getLatestCredentials();
                console.log('✅ 已重新获取API key，继续处理...');
              } else {
                console.log('⚠️ API key验证失败，但继续尝试...');
              }
            }
          }
          
          const addresses = await this.getAllAddressesForCEX(cex);
          allAddresses.push(...addresses);
          
          // 计算去重后的地址数量
          const uniqueAddresses = new Set(addresses.map(addr => addr.address));
          
          cexResults[cex.cexTag] = {
            totalAddresses: addresses.length,
            totalUniqueAddresses: uniqueAddresses.size,
            totalValue: cex.totalValue,
            blockChains: cex.blockChainList.length,
            symbols: cex.symbolList.length
          };
          
          // 保存单个CEX的结果
          await this.saveCEXAddresses(cex.cexTag, addresses);
          
        } catch (error) {
          // 检查是否是API key过期错误
          if (error.message.includes('5004') || error.message.includes('VISIT_ALREADY_EXPIRED')) {
            console.log(`\n🔄 ${cex.cexTag} 处理失败，API key可能已过期，尝试重新获取...`);
            try {
              await this.getLatestCredentials();
              console.log('✅ 已重新获取API key，重新尝试处理该CEX...');
              
              // 重新尝试处理这个CEX
              const addresses = await this.getAllAddressesForCEX(cex);
              allAddresses.push(...addresses);
              
              cexResults[cex.cexTag] = {
                totalAddresses: addresses.length,
                totalValue: cex.totalValue,
                blockChains: cex.blockChainList.length,
                symbols: cex.symbolList.length
              };
              
              await this.saveCEXAddresses(cex.cexTag, addresses);
              
            } catch (retryError) {
              console.error(`❌ 重新尝试处理 ${cex.cexTag} 仍然失败:`, retryError.message);
              cexResults[cex.cexTag] = { error: retryError.message };
            }
          } else {
            console.error(`❌ 收集 ${cex.cexTag} 地址失败:`, error.message);
            cexResults[cex.cexTag] = { error: error.message };
          }
        }
        
        // 避免请求过于频繁
        await this.sleep(1000);
      }
      
      // 生成总的地址汇总文件（包含所有CEX的去重统计）
      await this.saveTotalAddressesSummary(cexResults, allAddresses);
      
      // 计算总的去重地址数
      const totalUniqueAddresses = new Set(allAddresses.map(addr => addr.address));
      
      // 保存汇总结果
      const summary = {
        timestamp: new Date().toISOString(),
        totalCEX: cexList.length,
        totalAddresses: allAddresses.length,
        totalUniqueAddresses: totalUniqueAddresses.size,
        cexResults,
        allAddresses: allAddresses.slice(0, 1000) // 限制输出大小
      };
      
      await this.saveSummary(summary);
      
      // 保存标准格式的地址数据
      await this.saveStandardFormat(allAddresses);
      
      // 显示保存的文件列表
      await this.showSavedFiles();
      
      console.log('\n🎉 地址收集完成!');
      console.log(`📊 总计: ${cexList.length} 个CEX, ${allAddresses.length} 个地址`);
      console.log(`📁 所有数据已保存到日期文件夹: ${this.dateFolderName}`);
      
      return summary;
      
    } catch (error) {
      console.error('❌ 地址收集失败:', error.message);
      throw error;
    }
  }

  async saveCEXAddresses(cexTag, addresses) {
    const filename = `${cexTag.toLowerCase()}_addresses.json`;
    const filepath = `${this.dateFolderPath}/${filename}`;
    
    // 计算去重后的地址数量
    const uniqueAddresses = new Set(addresses.map(addr => addr.address));
    
    const data = {
      timestamp: new Date().toISOString(),
      cexTag,
      totalAddresses: addresses.length,
      totalUniqueAddresses: uniqueAddresses.size,
      addresses
    };
    
    await fs.writeFile(filepath, JSON.stringify(data, null, 2));
    console.log(`  💾 ${cexTag} 地址数据已保存到: ${this.dateFolderName}/${filename} (去重后: ${uniqueAddresses.size} 个地址)`);
    
    // 保存到Supabase数据库
    await this.saveToSupabase(cexTag, addresses);
  }

  async saveCEXList(cexList) {
    const filename = 'cex_list.json';
    const filepath = `${this.dateFolderPath}/${filename}`;
    
    const data = {
      timestamp: new Date().toISOString(),
      totalCEX: cexList.length,
      cexList: cexList.map(cex => ({
        cexTag: cex.cexTag,
        seoCexTag: cex.seoCexTag,
        totalValue: cex.totalValue,
        totalValueChange: cex.totalValueChange,
        netInflow: cex.netInflow,
        addressCount: cex.addressCount,
        blockChainList: cex.blockChainList,
        symbolList: cex.symbolList,
        rank: cex.rank
      }))
    };
    
    await fs.writeFile(filepath, JSON.stringify(data, null, 2));
    console.log(`💾 CEX列表已保存到: ${this.dateFolderName}/${filename}`);
  }

  async saveChainSupportToken(cexTag, chainSupportData, isImmediate = false) {
    const fileName = `${cexTag.toLowerCase()}_chain_support_token.json`;
    const filePath = path.join(this.dateFolderPath, fileName);
    
    const data = {
      timestamp: new Date().toISOString(),
      cexTag,
      totalChains: chainSupportData.length,
      chainSupportData
    };
    
    try {
      await fs.writeFile(filePath, JSON.stringify(data, null, 2), 'utf8');
      if (isImmediate) {
        console.log(`💾 ${cexTag} 链支持币种列表已立即保存到: ${this.dateFolderName}/${fileName}`);
      } else {
        console.log(`💾 链支持币种列表已保存到: ${this.dateFolderName}/${fileName}`);
      }
    } catch (error) {
      console.error(`❌ 保存${cexTag}链支持币种列表失败:`, error.message);
    }
  }

  async saveTotalAddressesSummary(cexResults, allAddresses) {
    const fileName = 'cex_addresses_summary.json';
    const filePath = path.join(this.dateFolderPath, fileName);
    
    // 对地址进行去重（基于address字段）
    const uniqueAddresses = new Set();
    allAddresses.forEach(addr => {
      if (addr.address && addr.address.trim()) {
        uniqueAddresses.add(addr.address.trim());
      }
    });
    
    // 为每个CEX计算去重后的地址数量
    const cexUniqueResults = {};
    for (const [cexTag, result] of Object.entries(cexResults)) {
      if (result.error) {
        cexUniqueResults[cexTag] = { error: result.error };
      } else {
        // 获取该CEX的地址进行去重
        const cexAddresses = allAddresses.filter(addr => addr.cexTag === cexTag);
        const cexUniqueAddresses = new Set();
        cexAddresses.forEach(addr => {
          if (addr.address && addr.address.trim()) {
            cexUniqueAddresses.add(addr.address.trim());
          }
        });
        cexUniqueResults[cexTag] = {
          totalUniqueAddresses: cexUniqueAddresses.size
        };
      }
    }
    
    const data = {
      timestamp: new Date().toISOString(),
      totalCEX: Object.keys(cexResults).length,
      totalUniqueAddresses: uniqueAddresses.size,
      cexResults: cexUniqueResults
    };
    
    try {
      await fs.writeFile(filePath, JSON.stringify(data, null, 2), 'utf8');
      console.log(`📊 总地址汇总已保存到: ${this.dateFolderName}/${fileName} (去重后总计: ${uniqueAddresses.size} 个地址)`);
    } catch (error) {
      console.error(`❌ 保存总地址汇总失败:`, error.message);
    }
  }

  async saveSummary(summary) {
    const filename = 'cex_addresses_summary.json';
    const filepath = `${this.dateFolderPath}/${filename}`;
    await fs.writeFile(filepath, JSON.stringify(summary, null, 2));
    console.log(`💾 汇总数据已保存到: ${this.dateFolderName}/${filename}`);
  }

  async saveStandardFormat(addresses) {
    // 按照你要求的格式保存：cexTag、symbol、address、value、usdValue、isContract
    const standardData = {
      timestamp: new Date().toISOString(),
      totalAddresses: addresses.length,
      addresses: addresses.map(addr => ({
        cexTag: addr.cexTag,
        symbol: addr.symbol,
        address: addr.address,
        value: addr.value,
        usdValue: addr.usdValue,
        isContract: addr.isContract
      }))
    };
    
    const filename = 'cex_addresses_standard.json';
    const filepath = `${this.dateFolderPath}/${filename}`;
    await fs.writeFile(filepath, JSON.stringify(standardData, null, 2));
    console.log(`💾 标准格式地址数据已保存到: ${this.dateFolderName}/${filename}`);
    
    // 保存完成后，自动开始增量导入到Supabase
    console.log('\n🚀 开始自动增量导入到Supabase...');
    await this.importToSupabase();
  }

  // 新增：增量导入到Supabase
  async importToSupabase() {
    try {
      console.log('📊 开始增量导入到Supabase...');
      
      // 检查Supabase配置
      if (!config.supabase || !config.supabase.url || !config.supabase.serviceRoleKey) {
        console.log('⚠️ Supabase配置缺失，跳过数据库导入');
        return false;
      }

      // 检查标准地址文件是否存在
      const standardFilePath = path.join(this.dateFolderPath, 'cex_addresses_standard.json');
      if (!await this.fileExists(standardFilePath)) {
        console.log('⚠️ 标准地址文件不存在，跳过数据库导入');
        return false;
      }

      // 第一步：加载数据库中已存在的记录
      await this.loadExistingRecordsForImport();
      
      // 第二步：读取并过滤新记录
      const newAddresses = await this.filterNewAddressesForImport(standardFilePath);
      
      if (newAddresses.length === 0) {
        console.log('✅ 所有记录都已存在，无需导入');
        return true;
      }
      
      // 第三步：批量导入新记录
      await this.batchImportToSupabase(newAddresses);
      
      // 第四步：生成导入报告
      await this.generateImportReport(newAddresses);
      
      console.log('🎉 Supabase增量导入完成！');
      return true;
      
    } catch (error) {
      console.error('❌ Supabase导入失败:', error.message);
      return false;
    }
  }

  async loadExistingRecordsForImport() {
    console.log('📊 加载数据库中已存在的记录...');
    
    try {
      let offset = 0;
      const limit = 1000;
      let totalLoaded = 0;
      let startTime = Date.now();
      
      this.existingRecordsForImport = new Set();
      
      while (true) {
        const { data: records, error: queryError } = await this.supabase
          .from(config.supabase.table)
          .select('cexTag, symbol, address')
          .range(offset, offset + limit - 1);

        if (queryError) {
          console.error('❌ 查询现有记录失败:', queryError.message);
          break;
        }

        if (!records || records.length === 0) {
          break;
        }

        // 添加到缓存
        records.forEach(record => {
          const key = `${record.cexTag}-${record.symbol}-${record.address}`;
          this.existingRecordsForImport.add(key);
        });

        totalLoaded += records.length;
        const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
        console.log(`   📥 已加载 ${totalLoaded} 条现有记录 (耗时: ${elapsed}s)...`);

        if (records.length < limit) {
          break; // 最后一页
        }

        offset += limit;
        
        // 避免长时间占用连接
        if (totalLoaded % 10000 === 0) {
          await this.sleep(100);
        }
      }

      const totalTime = ((Date.now() - startTime) / 1000).toFixed(1);
      console.log(`✅ 数据库中有 ${this.existingRecordsForImport.size} 条现有记录 (总耗时: ${totalTime}s)`);
      
    } catch (error) {
      console.error('❌ 加载现有记录失败:', error.message);
      throw error;
    }
  }

  async filterNewAddressesForImport(filePath) {
    console.log('🔍 过滤新记录...');
    
    try {
      const fileContent = await fs.readFile(filePath, 'utf8');
      const data = JSON.parse(fileContent);
      
      if (!data.addresses || !Array.isArray(data.addresses)) {
        throw new Error('地址数据格式错误');
      }
      
      const newAddresses = [];
      let skippedCount = 0;
      let startTime = Date.now();
      
      data.addresses.forEach((addr, index) => {
        const key = `${addr.cexTag}-${addr.symbol}-${addr.address}`;
        
        if (this.existingRecordsForImport.has(key)) {
          skippedCount++;
        } else {
          newAddresses.push(addr);
        }
        
        // 显示进度
        if ((index + 1) % 10000 === 0) {
          const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
          console.log(`   📊 已处理 ${index + 1}/${data.addresses.length} 条记录 (耗时: ${elapsed}s)...`);
        }
      });
      
      const totalTime = ((Date.now() - startTime) / 1000).toFixed(1);
      console.log(`✅ 过滤完成: 新记录 ${newAddresses.length}, 跳过 ${skippedCount} (总耗时: ${totalTime}s)`);
      
      this.importStats = {
        totalProcessed: data.addresses.length,
        totalNew: newAddresses.length,
        totalSkipped: skippedCount
      };
      
      return newAddresses;
      
    } catch (error) {
      console.error('❌ 过滤新记录失败:', error.message);
      throw error;
    }
  }

  async batchImportToSupabase(newAddresses) {
    console.log(`📦 开始批量导入 ${newAddresses.length} 条新记录...`);
    
    const BATCH_SIZE = 1000;
    let totalSuccess = 0;
    
    for (let i = 0; i < newAddresses.length; i += BATCH_SIZE) {
      const batch = newAddresses.slice(i, i + BATCH_SIZE);
      const batchNumber = Math.floor(i / BATCH_SIZE) + 1;
      const totalBatches = Math.ceil(newAddresses.length / BATCH_SIZE);
      
      console.log(`\n📦 处理第 ${batchNumber}/${totalBatches} 批 (${batch.length} 条记录)...`);
      
      try {
        const result = await this.processImportBatch(batch);
        totalSuccess += result.successCount;
        
        console.log(`   ✅ 第 ${batchNumber} 批完成: 成功 ${result.successCount}`);
        
        // 批次间延迟
        if (i + BATCH_SIZE < newAddresses.length) {
          const delay = this.calculateImportDelay(batchNumber, totalBatches);
          console.log(`   ⏰ 等待${delay}ms后处理下一批...`);
          await this.sleep(delay);
        }
        
      } catch (error) {
        console.error(`   ❌ 第 ${batchNumber} 批处理失败:`, error.message);
        throw error;
      }
    }
    
    this.importStats.totalSuccess = totalSuccess;
    console.log(`✅ 批量导入完成: 成功 ${totalSuccess}/${newAddresses.length} 条记录`);
  }

  async processImportBatch(batchData) {
    try {
      // 准备插入数据
      const insertData = batchData.map(addr => ({
        cexTag: addr.cexTag,
        symbol: addr.symbol,
        address: addr.address,
        isContract: addr.isContract || false
      }));

      // 使用insert，设置ignoreDuplicates为true
      const { data: insertResult, error: insertError } = await this.supabase
        .from(config.supabase.table)
        .insert(insertData, {
          ignoreDuplicates: true // 忽略重复，只插入新记录
        })
        .select();

      if (insertError) {
        console.error(`   ❌ 批次insert失败:`, insertError.message);
        throw insertError;
    }

      return {
        successCount: insertResult ? insertResult.length : 0,
        data: insertResult
      };
      
    } catch (error) {
      console.error(`   ❌ 批次处理失败:`, error.message);
      throw error;
    }
  }

  calculateImportDelay(batchNumber, totalBatches) {
    // 智能延迟策略
    let baseDelay = 100;
    
    // 根据批次数量调整延迟
    if (totalBatches > 50) {
      baseDelay = 150;
    } else if (totalBatches > 20) {
      baseDelay = 120;
    }
    
    // 批次越往后，延迟越长（避免被限流）
    const progressFactor = batchNumber / totalBatches;
    if (progressFactor > 0.8) {
      baseDelay = Math.floor(baseDelay * 1.5);
    }
    
    // 添加随机因子
    const randomFactor = 0.8 + Math.random() * 0.4; // 0.8-1.2
    
    return Math.floor(baseDelay * randomFactor);
  }

  async generateImportReport(newAddresses) {
    console.log('📊 生成导入报告...');
    
    try {
      const report = {
        importDate: new Date().toISOString().split('T')[0],
        dateFolder: this.dateFolderName,
        timestamp: new Date().toISOString(),
        summary: {
          totalProcessed: this.importStats.totalProcessed,
          totalSuccess: this.importStats.totalSuccess,
          totalSkipped: this.importStats.totalSkipped,
          totalNew: this.importStats.totalNew,
          existingRecords: this.existingRecordsForImport.size
        },
        performance: {
          newRecordsPercentage: this.importStats.totalProcessed > 0 ? ((this.importStats.totalNew / this.importStats.totalProcessed) * 100).toFixed(2) : 0,
          skipRate: this.importStats.totalProcessed > 0 ? ((this.importStats.totalSkipped / this.importStats.totalProcessed) * 100).toFixed(2) : 0
        }
      };

      // 保存报告到文件
      const reportPath = path.join(this.dateFolderPath, `import_report_${report.importDate}.json`);
      await fs.writeFile(reportPath, JSON.stringify(report, null, 2));
      
      console.log('📋 导入报告:');
      console.log(`   导入日期: ${report.importDate}`);
      console.log(`   目标文件夹: ${report.dateFolder}`);
      console.log(`   总处理: ${report.summary.totalProcessed}`);
      console.log(`   成功插入: ${report.summary.totalSuccess}`);
      console.log(`   跳过重复: ${report.summary.totalSkipped}`);
      console.log(`   新增记录: ${report.summary.totalNew}`);
      console.log(`   新记录比例: ${report.performance.newRecordsPercentage}%`);
      console.log(`   跳过率: ${report.performance.skipRate}%`);
      console.log(`   报告已保存到: ${reportPath}`);
      
    } catch (error) {
      console.error('❌ 生成导入报告失败:', error.message);
    }
  }

  async fileExists(filePath) {
    try {
      await fs.access(filePath);
      return true;
    } catch {
      return false;
    }
  }

  async saveToSupabase(cexTag, addresses) {
    if (!this.supabase) {
      console.log('⚠️ Supabase未配置，跳过数据库保存');
      return;
    }

    console.log(`🗄️ 开始批量保存 ${cexTag} 的地址数据到Supabase...`);
    
    try {
      // 准备批量插入的数据
      const insertData = addresses.map(addr => ({
        cexTag: addr.cexTag,
        symbol: addr.symbol,
        address: addr.address,
        isContract: addr.isContract || false
      }));

      console.log(`📊 准备插入 ${insertData.length} 条记录...`);

      // 批量大小控制（避免单次请求过大）
      const BATCH_SIZE = 1000; // 每批1000条记录
      let totalProcessed = 0;
      let totalSuccess = 0;

      if (insertData.length <= BATCH_SIZE) {
        // 数据量小，直接批量处理
        const result = await this.processBatch(insertData);
        totalSuccess = result.successCount;
        totalProcessed = insertData.length;
      } else {
        // 数据量大，分批处理
        console.log(`📦 数据量较大，将分批处理，每批 ${BATCH_SIZE} 条...`);
        
        for (let i = 0; i < insertData.length; i += BATCH_SIZE) {
          const batch = insertData.slice(i, i + BATCH_SIZE);
          const batchNumber = Math.floor(i / BATCH_SIZE) + 1;
          const totalBatches = Math.ceil(insertData.length / BATCH_SIZE);
          
          console.log(`📦 处理第 ${batchNumber}/${totalBatches} 批 (${batch.length} 条记录)...`);
          
          const result = await this.processBatch(batch);
          totalSuccess += result.successCount;
          totalProcessed += batch.length;
          
          // 批次间延迟，避免请求过于频繁
          if (i + BATCH_SIZE < insertData.length) {
            await this.sleep(100); // 100ms延迟
          }
        }
      }

      console.log(`✅ ${cexTag} 批量保存完成: 成功处理 ${totalSuccess}/${totalProcessed} 条记录`);
      
      // 如果需要更详细的统计，可以查询实际的新增数量
      if (totalSuccess > 0) {
        await this.logDetailedStats(cexTag, addresses);
      }
      
    } catch (error) {
      console.error(`❌ 批量保存到Supabase失败:`, error.message);
      console.log('🔄 回退到逐条插入模式...');
      
      // 回退到原来的逐条插入逻辑
      return await this.saveToSupabaseFallback(cexTag, addresses);
    }
  }

  // 处理单个批次的upsert
  async processBatch(batchData) {
    try {
      const { data: upsertData, error: upsertError } = await this.supabase
        .from(config.supabase.table)
        .upsert(batchData, {
          onConflict: 'cexTag,symbol,address',
          ignoreDuplicates: false
        });

      if (upsertError) {
        console.error(`❌ 批次upsert失败:`, upsertError.message);
        throw upsertError;
      }

      return {
        successCount: upsertData ? upsertData.length : 0,
        data: upsertData
      };
    } catch (error) {
      console.error(`❌ 批次处理失败:`, error.message);
      throw error;
    }
  }

  // 回退的逐条插入方法（保持原有逻辑）
  async saveToSupabaseFallback(cexTag, addresses) {
    console.log(`🔄 使用逐条插入模式保存 ${cexTag} 数据...`);
    
    try {
      let insertedCount = 0;
      let skippedCount = 0;
      
      for (const addr of addresses) {
        try {
          // 查询是否已存在相同的记录
          const { data: existingRecords, error: queryError } = await this.supabase
            .from(config.supabase.table)
            .select('id')
            .eq('cexTag', addr.cexTag)
            .eq('symbol', addr.symbol)
            .eq('address', addr.address)
            .limit(1);

          if (queryError) {
            console.error(`❌ 查询记录失败:`, queryError.message);
            continue;
          }

          // 如果记录不存在，则插入
          if (!existingRecords || existingRecords.length === 0) {
            const { error: insertError } = await this.supabase
              .from(config.supabase.table)
              .insert({
                cexTag: addr.cexTag,
                symbol: addr.symbol,
                address: addr.address,
                isContract: addr.isContract || false
              });

            if (insertError) {
              console.error(`❌ 插入记录失败:`, insertError.message);
            } else {
              insertedCount++;
            }
          } else {
            skippedCount++;
          }
        } catch (error) {
          console.error(`❌ 处理地址记录失败:`, error.message);
        }
      }

      console.log(`✅ ${cexTag} 逐条插入完成: 新增 ${insertedCount} 条，跳过 ${skippedCount} 条重复记录`);
      
    } catch (error) {
      console.error(`❌ 逐条插入失败:`, error.message);
    }
  }

  // 记录详细统计信息
  async logDetailedStats(cexTag, addresses) {
    try {
      // 查询该CEX在数据库中的总记录数
      const { data: totalRecords, error: countError } = await this.supabase
        .from(config.supabase.table)
        .select('id', { count: 'exact' })
        .eq('cexTag', cexTag);

      if (!countError && totalRecords !== null) {
        console.log(`📊 ${cexTag} 在数据库中的总记录数: ${totalRecords.length}`);
      }
    } catch (error) {
      console.log('ℹ️ 无法获取详细统计信息');
    }
  }

  async showSavedFiles() {
    try {
      const files = await fs.readdir(this.dateFolderPath);
      const jsonFiles = files.filter(file => file.endsWith('.json'));
      
      console.log(`\n📋 日期文件夹 ${this.dateFolderName} 中的文件列表:`);
      for (const file of jsonFiles) {
        const filePath = `${this.dateFolderPath}/${file}`;
        const stats = await fs.stat(filePath);
        const fileSize = (stats.size / 1024).toFixed(2);
        console.log(`  📄 ${file} (${fileSize} KB)`);
      }
    } catch (error) {
      console.log('⚠️ 无法读取文件列表:', error.message);
    }
  }

  sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  async smartDelay(cexTag, blockChain, symbol) {
    // 智能延迟策略，防止被OKLink封禁
    let delay = config.rateLimit.baseDelay[blockChain] || config.rateLimit.baseDelay.default;
    
    // 根据CEX调整延迟
    delay += config.rateLimit.cexDelay[cexTag] || config.rateLimit.cexDelay.default;
    
    // 随机化延迟，避免被识别为机器人
    const randomFactor = config.rateLimit.randomFactor.min + 
                        Math.random() * (config.rateLimit.randomFactor.max - config.rateLimit.randomFactor.min);
    delay = Math.floor(delay * randomFactor);
    
    // 批量请求延迟控制
    this.requestCount++;
    if (this.requestCount % 10 === 0) {
      delay += config.rateLimit.batchDelay.every10Requests;
      console.log(`    ⏰ 已发送${this.requestCount}个请求，增加额外延迟${config.rateLimit.batchDelay.every10Requests}ms`);
    }
    
    if (this.requestCount % 50 === 0) {
      delay += config.rateLimit.batchDelay.every50Requests;
      console.log(`    ⏰ 已发送${this.requestCount}个请求，增加额外延迟${config.rateLimit.batchDelay.every50Requests}ms`);
    }
    
    if (this.requestCount % 100 === 0) {
      delay += config.rateLimit.batchDelay.every100Requests;
      console.log(`    ⏰ 已发送${this.requestCount}个请求，增加额外延迟${config.rateLimit.batchDelay.every100Requests}ms`);
    }
    
    await this.sleep(delay);
  }

  async close() {
    if (this.browser) {
      await this.browser.close();
    }
  }
}

// 主函数
async function main() {
  const collector = new UltimateAddressCollector();
  
  try {
    await collector.init();
    const result = await collector.collectAllAddresses();
    console.log('✅ 程序执行完成!');
    return result;
  } catch (error) {
    console.error('❌ 程序执行失败:', error.message);
    process.exit(1);
  } finally {
    await collector.close();
  }
}

// 如果直接运行此文件
if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}

export default UltimateAddressCollector;
