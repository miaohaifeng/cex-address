import fs from 'fs/promises';

async function checkJsonDuplicates() {
  console.log('🔍 检查JSON文件中的重复数据...');
  
  try {
    // 读取JSON文件
    const filePath = './output/20250817/cex_addresses_standard.json';
    console.log(`📁 读取文件: ${filePath}`);
    
    const fileContent = await fs.readFile(filePath, 'utf8');
    const data = JSON.parse(fileContent);
    
    console.log(`📊 文件信息:`);
    console.log(`   时间戳: ${data.timestamp}`);
    console.log(`   总地址数: ${data.totalAddresses}`);
    console.log(`   地址数组长度: ${data.addresses.length}`);
    
    if (!data.addresses || !Array.isArray(data.addresses)) {
      throw new Error('地址数据格式错误');
    }
    
    // 检查重复数据
    console.log('\n🔍 检查重复数据...');
    
    const uniqueKeys = new Set();
    const duplicates = [];
    const duplicateCounts = {};
    
    data.addresses.forEach((addr, index) => {
      const key = `${addr.cexTag}-${addr.symbol}-${addr.address}`;
      
      if (uniqueKeys.has(key)) {
        duplicates.push({
          index,
          key,
          addr
        });
        
        const duplicateKey = `${addr.cexTag}-${addr.symbol}`;
        duplicateCounts[duplicateKey] = (duplicateCounts[duplicateKey] || 0) + 1;
      } else {
        uniqueKeys.add(key);
      }
    });
    
    console.log(`📊 重复数据统计:`);
    console.log(`   唯一记录数: ${uniqueKeys.size}`);
    console.log(`   重复记录数: ${duplicates.length}`);
    console.log(`   总记录数: ${data.addresses.length}`);
    
    if (duplicates.length > 0) {
      console.log('\n📋 重复数据示例（前10条）:');
      duplicates.slice(0, 10).forEach((dup, index) => {
        console.log(`   ${index + 1}. ${dup.addr.cexTag} - ${dup.addr.symbol} - ${dup.addr.address}`);
      });
      
      console.log('\n📊 按CEX-Symbol统计重复:');
      Object.entries(duplicateCounts)
        .sort(([,a], [,b]) => b - a)
        .slice(0, 10)
        .forEach(([key, count]) => {
          console.log(`   ${key}: ${count} 条重复`);
        });
    } else {
      console.log('✅ 没有发现重复数据');
    }
    
    // 检查前几批的数据
    console.log('\n🔍 检查前几批数据...');
    const batchSize = 2000;
    
    for (let i = 0; i < Math.min(3, Math.ceil(data.addresses.length / batchSize)); i++) {
      const start = i * batchSize;
      const end = Math.min(start + batchSize, data.addresses.length);
      const batch = data.addresses.slice(start, end);
      
      const batchUniqueKeys = new Set();
      const batchDuplicates = [];
      
      batch.forEach((addr, batchIndex) => {
        const key = `${addr.cexTag}-${addr.symbol}-${addr.address}`;
        if (batchUniqueKeys.has(key)) {
          batchDuplicates.push({
            batchIndex: start + batchIndex,
            key,
            addr
          });
        } else {
          batchUniqueKeys.add(key);
        }
      });
      
      console.log(`\n📦 第 ${i + 1} 批 (${start + 1}-${end}):`);
      console.log(`   唯一记录: ${batchUniqueKeys.size}`);
      console.log(`   重复记录: ${batchDuplicates.length}`);
      
      if (batchDuplicates.length > 0) {
        console.log(`   重复示例:`);
        batchDuplicates.slice(0, 3).forEach(dup => {
          console.log(`     ${dup.addr.cexTag} - ${dup.addr.symbol} - ${dup.addr.address}`);
        });
      }
    }
    
    console.log('\n🎯 重复数据检查完成！');
    
  } catch (error) {
    console.error('❌ 检查失败:', error.message);
    console.error('   堆栈:', error.stack);
  }
}

// 运行检查
checkJsonDuplicates();
