import config from './config.js';

console.log('🧪 测试配置文件...\n');

console.log('📋 Supabase配置:');
console.log('  URL:', config.supabase?.url || '未设置');
console.log('  Service Role Key:', config.supabase?.serviceRoleKey ? '已设置' : '未设置');
console.log('  Table:', config.supabase?.table || '未设置');
console.log('  User ID:', config.supabase?.userId || '未设置');

console.log('\n🔍 配置检查:');
console.log('  config.supabase 存在:', !!config.supabase);
console.log('  config.supabase.url 存在:', !!config.supabase?.url);
console.log('  config.supabase.serviceRoleKey 存在:', !!config.supabase?.serviceRoleKey);

if (config.supabase && config.supabase.url && config.supabase.serviceRoleKey) {
  console.log('\n✅ Supabase配置完整');
} else {
  console.log('\n❌ Supabase配置不完整');
}
