import { createClient } from '@supabase/supabase-js';
import config from '../config.js';

async function checkTableStructure() {
  console.log('🔍 检查数据库表结构...');
  
  try {
    const supabase = createClient(config.supabase.url, config.supabase.serviceRoleKey);
    
    // 1. 检查表是否存在
    console.log('\n📋 1. 检查表是否存在...');
    const { data: tableInfo, error: tableError } = await supabase
      .from(config.supabase.table)
      .select('*')
      .limit(0);
    
    if (tableError) {
      console.error('❌ 表不存在或无法访问:', tableError.message);
      return;
    }
    
    console.log('✅ 表存在');
    
    // 2. 检查表结构
    console.log('\n📊 2. 检查表结构...');
    const { data: sampleData, error: sampleError } = await supabase
      .from(config.supabase.table)
      .select('*')
      .limit(1);
    
    if (sampleError) {
      console.error('❌ 无法查询表数据:', sampleError.message);
      return;
    }
    
    if (sampleData && sampleData.length > 0) {
      console.log('📋 表字段:');
      Object.keys(sampleData[0]).forEach(key => {
        console.log(`   ${key}: ${typeof sampleData[0][key]}`);
      });
    }
    
    // 3. 检查约束
    console.log('\n🔐 3. 检查约束...');
    try {
      // 尝试插入重复数据来测试唯一约束
      const testData = {
        cexTag: 'TEST_CONSTRAINT',
        symbol: 'TEST',
        address: '0x1234567890abcdef'
      };
      
      // 第一次插入
      const { error: insert1Error } = await supabase
        .from(config.supabase.table)
        .insert(testData);
      
      if (insert1Error) {
        console.error('❌ 第一次插入失败:', insert1Error.message);
        return;
      }
      
      console.log('✅ 第一次插入成功');
      
      // 第二次插入（应该失败）
      const { error: insert2Error } = await supabase
        .from(config.supabase.table)
        .insert(testData);
      
      if (insert2Error) {
        if (insert2Error.message.includes('duplicate') || insert2Error.message.includes('unique')) {
          console.log('✅ 唯一约束工作正常');
        } else {
          console.log('⚠️ 约束检查异常:', insert2Error.message);
        }
      } else {
        console.log('❌ 唯一约束未生效');
      }
      
      // 清理测试数据
      await supabase
        .from(config.supabase.table)
        .delete()
        .eq('cexTag', 'TEST_CONSTRAINT');
      
    } catch (error) {
      console.error('❌ 约束检查失败:', error.message);
    }
    
    // 4. 检查现有数据
    console.log('\n📊 4. 检查现有数据...');
    const { data: countData, error: countError } = await supabase
      .from(config.supabase.table)
      .select('id', { count: 'exact' });
    
    if (countError) {
      console.error('❌ 无法获取记录数:', countError.message);
    } else {
      console.log(`📊 当前记录数: ${countData.length}`);
    }
    
    console.log('\n🎯 表结构检查完成！');
    
  } catch (error) {
    console.error('❌ 检查失败:', error.message);
  }
}

// 运行检查
checkTableStructure();
