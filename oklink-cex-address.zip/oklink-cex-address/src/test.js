import APIKeyExtractor from './apiKeyExtractor.js';
import OKLinkCEXCollector from './index.js';

async function testAPIKeyExtraction() {
  console.log('🧪 测试API Key提取功能...');
  
  const extractor = new APIKeyExtractor();
  
  try {
    await extractor.init();
    const apiKey = await extractor.extractAPIKey();
    
    if (apiKey) {
      console.log('✅ API Key提取成功:', apiKey);
      
      // 测试使用提取的API Key获取数据
      console.log('\n🧪 测试使用提取的API Key获取数据...');
      const collector = new OKLinkCEXCollector();
      
      try {
        await collector.init();
        const cexData = await collector.getCEXList(apiKey);
        console.log('✅ 数据获取成功!');
        console.log('数据预览:', JSON.stringify(cexData, null, 2).substring(0, 500) + '...');
        
        // 保存数据
        await collector.saveData(cexData, 'test_cex_data.json');
        
      } catch (error) {
        console.error('❌ 数据获取失败:', error.message);
      } finally {
        await collector.close();
      }
      
    } else {
      console.log('❌ API Key提取失败');
    }
    
  } catch (error) {
    console.error('❌ 测试失败:', error.message);
  } finally {
    await extractor.close();
  }
}

async function testFullCollector() {
  console.log('\n🧪 测试完整的数据采集器...');
  
  const collector = new OKLinkCEXCollector();
  
  try {
    const result = await collector.collectAllData();
    console.log('✅ 完整测试成功!');
    return result;
  } catch (error) {
    console.error('❌ 完整测试失败:', error.message);
    throw error;
  }
}

// 主测试函数
async function runTests() {
  console.log('🚀 开始运行测试...\n');
  
  try {
    // 测试1: API Key提取
    await testAPIKeyExtraction();
    
    console.log('\n' + '='.repeat(50) + '\n');
    
    // 测试2: 完整数据采集
    await testFullCollector();
    
    console.log('\n✅ 所有测试完成!');
    
  } catch (error) {
    console.error('\n❌ 测试过程中出现错误:', error.message);
    process.exit(1);
  }
}

// 如果直接运行此文件
if (import.meta.url === `file://${process.argv[1]}`) {
  runTests();
}

export { testAPIKeyExtraction, testFullCollector, runTests };
