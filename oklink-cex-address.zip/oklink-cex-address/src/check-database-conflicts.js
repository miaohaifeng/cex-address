import { createClient } from '@supabase/supabase-js';
import config from '../config.js';

async function checkDatabaseConflicts() {
  console.log('🔍 检查数据库冲突...');
  
  try {
    const supabase = createClient(config.supabase.url, config.supabase.serviceRoleKey);
    
    // 1. 检查现有数据
    console.log('\n📊 1. 检查现有数据...');
    const { data: existingData, error: countError } = await supabase
      .from(config.supabase.table)
      .select('*')
      .order('id')
      .limit(10);

    if (countError) {
      console.error('❌ 无法查询现有数据:', countError.message);
      return;
    }

    console.log(`📊 现有记录数: ${existingData.length}`);
    
    if (existingData.length > 0) {
      console.log('📋 前10条记录:');
      existingData.forEach((record, index) => {
        console.log(`   ${index + 1}. ID: ${record.id}, ${record.cexTag} - ${record.symbol} - ${record.address}`);
      });
    }

    // 2. 检查JSON文件前几条数据
    console.log('\n📄 2. 检查JSON文件前几条数据...');
    const fs = await import('fs/promises');
    const filePath = './output/20250817/cex_addresses_standard.json';
    const fileContent = await fs.readFile(filePath, 'utf8');
    const data = JSON.parse(fileContent);
    
    console.log('📋 JSON文件前5条记录:');
    data.addresses.slice(0, 5).forEach((addr, index) => {
      console.log(`   ${index + 1}. ${addr.cexTag} - ${addr.symbol} - ${addr.address}`);
    });

    // 3. 检查冲突
    console.log('\n⚠️ 3. 检查潜在冲突...');
    const jsonFirst5 = data.addresses.slice(0, 5);
    
    for (const jsonAddr of jsonFirst5) {
      const { data: conflictData, error: conflictError } = await supabase
        .from(config.supabase.table)
        .select('*')
        .eq('cexTag', jsonAddr.cexTag)
        .eq('symbol', jsonAddr.symbol)
        .eq('address', jsonAddr.address);

      if (conflictError) {
        console.error(`❌ 查询冲突失败:`, conflictError.message);
        continue;
      }

      if (conflictData && conflictData.length > 0) {
        console.log(`⚠️ 发现冲突: ${jsonAddr.cexTag} - ${jsonAddr.symbol} - ${jsonAddr.address}`);
        console.log(`   数据库中的记录:`, conflictData[0]);
      } else {
        console.log(`✅ 无冲突: ${jsonAddr.cexTag} - ${jsonAddr.symbol} - ${jsonAddr.address}`);
      }
    }

    // 4. 检查数据库中的唯一性
    console.log('\n🔐 4. 检查数据库唯一性...');
    const { data: allData, error: allError } = await supabase
      .from(config.supabase.table)
      .select('cexTag, symbol, address');

    if (allError) {
      console.error('❌ 无法查询所有数据:', allError.message);
      return;
    }

    const uniqueKeys = new Set();
    const duplicates = [];

    allData.forEach((record, index) => {
      const key = `${record.cexTag}-${record.symbol}-${record.address}`;
      if (uniqueKeys.has(key)) {
        duplicates.push({
          index,
          key,
          record
        });
      } else {
        uniqueKeys.add(key);
      }
    });

    console.log(`📊 数据库唯一性检查:`);
    console.log(`   总记录数: ${allData.length}`);
    console.log(`   唯一记录数: ${uniqueKeys.size}`);
    console.log(`   重复记录数: ${duplicates.length}`);

    if (duplicates.length > 0) {
      console.log('📋 数据库中的重复记录:');
      duplicates.slice(0, 5).forEach((dup, index) => {
        console.log(`   ${index + 1}. ${dup.record.cexTag} - ${dup.record.symbol} - ${dup.record.address}`);
      });
    }

    console.log('\n🎯 冲突检查完成！');
    
  } catch (error) {
    console.error('❌ 检查失败:', error.message);
    console.error('   堆栈:', error.stack);
  }
}

// 运行检查
checkDatabaseConflicts();
