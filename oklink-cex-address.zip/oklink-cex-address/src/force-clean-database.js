import { createClient } from '@supabase/supabase-js';
import config from '../config.js';

async function forceCleanDatabase() {
  console.log('🧹 强制清理数据库...');
  
  try {
    const supabase = createClient(config.supabase.url, config.supabase.serviceRoleKey);
    
    // 1. 检查现有数据
    console.log('\n📊 1. 检查现有数据...');
    const { data: existingData, error: countError } = await supabase
      .from(config.supabase.table)
      .select('*');

    if (countError) {
      console.error('❌ 无法查询现有数据:', countError.message);
      return;
    }

    console.log(`📊 发现 ${existingData.length} 条现有记录`);
    
    if (existingData.length > 0) {
      // 显示前几条记录作为示例
      console.log('📋 前5条记录示例:');
      existingData.slice(0, 5).forEach((record, index) => {
        console.log(`   ${index + 1}. ${record.cexTag} - ${record.symbol} - ${record.address}`);
      });
    }

    // 2. 强制删除所有数据
    console.log('\n🗑️ 2. 强制删除所有数据...');
    
    if (existingData.length > 0) {
      const { error: deleteError } = await supabase
        .from(config.supabase.table)
        .delete()
        .neq('id', 0); // 删除所有记录

      if (deleteError) {
        console.error('❌ 删除失败:', deleteError.message);
        return;
      }

      console.log('✅ 所有数据已删除');
    } else {
      console.log('✅ 数据库已经是空的');
    }

    // 3. 验证清理结果
    console.log('\n🔍 3. 验证清理结果...');
    const { data: verifyData, error: verifyError } = await supabase
      .from(config.supabase.table)
      .select('*');

    if (verifyError) {
      console.error('❌ 验证查询失败:', verifyError.message);
      return;
    }

    if (verifyData.length === 0) {
      console.log('✅ 数据库清理成功，现在为空');
    } else {
      console.log(`⚠️ 数据库清理不完整，仍有 ${verifyData.length} 条记录`);
    }

    // 4. 重置自增ID（可选）
    console.log('\n🔄 4. 重置自增ID...');
    try {
      // 注意：这需要超级用户权限，可能不工作
      const { error: resetError } = await supabase
        .rpc('reset_sequence', { 
          table_name: config.supabase.table,
          sequence_name: `${config.supabase.table}_id_seq`
        });

      if (resetError) {
        console.log('ℹ️ 无法重置自增ID（需要超级用户权限）');
      } else {
        console.log('✅ 自增ID已重置');
      }
    } catch (e) {
      console.log('ℹ️ 跳过自增ID重置');
    }

    console.log('\n🎯 强制清理完成！');
    
  } catch (error) {
    console.error('❌ 清理失败:', error.message);
    console.error('   堆栈:', error.stack);
  }
}

// 运行清理
forceCleanDatabase();
