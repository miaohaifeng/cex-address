import puppeteer from 'puppeteer';

class APIKeyExtractor {
  constructor() {
    this.browser = null;
    this.page = null;
  }

  async init() {
    this.browser = await puppeteer.launch({
      headless: false,
      executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
    this.page = await this.browser.newPage();
    
    // 设置用户代理
    await this.page.setUserAgent('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Safari/537.36');
    
    // 设置视口
    await this.page.setViewport({ width: 1920, height: 1080 });
  }

  async extractAPIKey() {
    console.log('🔍 开始提取API Key...');
    
    try {
      // 方法1: 监听网络请求
      const apiKeyFromNetwork = await this.extractFromNetwork();
      if (apiKeyFromNetwork) {
        return apiKeyFromNetwork;
      }

      // 方法2: 检查localStorage和sessionStorage
      const apiKeyFromStorage = await this.extractFromStorage();
      if (apiKeyFromStorage) {
        return apiKeyFromStorage;
      }

      // 方法3: 分析页面源码
      const apiKeyFromSource = await this.extractFromSource();
      if (apiKeyFromSource) {
        return apiKeyFromSource;
      }

      // 方法4: 检查cookie
      const apiKeyFromCookie = await this.extractFromCookie();
      if (apiKeyFromCookie) {
        return apiKeyFromCookie;
      }

      // 方法5: 检查JavaScript变量
      const apiKeyFromJS = await this.extractFromJavaScript();
      if (apiKeyFromJS) {
        return apiKeyFromJS;
      }

      throw new Error('所有方法都无法提取到API Key');
    } catch (error) {
      console.error('❌ API Key提取失败:', error.message);
      throw error;
    }
  }

  async extractFromNetwork() {
    console.log('🔍 方法1: 监听网络请求...');
    
    try {
      // 访问CEX列表页面
      await this.page.goto('https://www.oklink.com/zh-hans/cex-list', {
        waitUntil: 'networkidle2',
        timeout: 30000
      });

      // 等待页面加载
      await this.page.waitForTimeout(3000);

      // 监听所有网络请求
      const apiKey = await this.page.evaluate(() => {
        return new Promise((resolve) => {
          let found = false;
          
          // 拦截fetch请求
          const originalFetch = window.fetch;
          window.fetch = function(...args) {
            const url = args[0];
            if (typeof url === 'string' && url.includes('cexAssetDashboard')) {
              const headers = args[1]?.headers;
              if (headers && headers['x-apikey']) {
                found = true;
                resolve(headers['x-apikey']);
              }
            }
            return originalFetch.apply(this, args);
          };

          // 拦截XMLHttpRequest
          const originalXHR = window.XMLHttpRequest.prototype.open;
          window.XMLHttpRequest.prototype.open = function(method, url, ...rest) {
            if (url.includes('cexAssetDashboard')) {
              this.addEventListener('readystatechange', function() {
                if (this.readyState === 1) {
                  const apiKey = this.getRequestHeader('x-apikey');
                  if (apiKey && !found) {
                    found = true;
                    resolve(apiKey);
                  }
                }
              });
            }
            return originalXHR.apply(this, [method, url, ...rest]);
          };

          // 尝试触发API调用
          setTimeout(() => {
            if (!found) {
              // 滚动页面
              window.scrollTo(0, document.body.scrollHeight);
              
              // 尝试点击某些元素
              const buttons = document.querySelectorAll('button, .btn, [role="button"]');
              buttons.forEach(btn => {
                if (btn.textContent.includes('加载') || btn.textContent.includes('更多')) {
                  btn.click();
                }
              });
            }
          }, 2000);

          // 超时处理
          setTimeout(() => {
            if (!found) {
              resolve(null);
            }
          }, 10000);
        });
      });

      if (apiKey) {
        console.log('✅ 从网络请求中提取到API Key:', apiKey);
        return apiKey;
      }

      return null;
    } catch (error) {
      console.error('网络请求监听失败:', error.message);
      return null;
    }
  }

  async extractFromStorage() {
    console.log('🔍 方法2: 检查存储...');
    
    try {
      const apiKey = await this.page.evaluate(() => {
        const keys = [
          'x-apikey',
          'apiKey',
          'oklink_api_key',
          'oklink_apikey',
          'api_key',
          'apikey'
        ];
        
        for (const key of keys) {
          const value = localStorage.getItem(key) || sessionStorage.getItem(key);
          if (value) {
            return value;
          }
        }
        
        return null;
      });

      if (apiKey) {
        console.log('✅ 从存储中提取到API Key:', apiKey);
        return apiKey;
      }

      return null;
    } catch (error) {
      console.error('存储检查失败:', error.message);
      return null;
    }
  }

  async extractFromSource() {
    console.log('🔍 方法3: 分析页面源码...');
    
    try {
      const pageContent = await this.page.content();
      
      // 多种正则表达式模式
      const patterns = [
        /x-apikey["\s]*:["\s]*([^"'\s]+)/i,
        /apikey["\s]*:["\s]*([^"'\s]+)/i,
        /api_key["\s]*:["\s]*([^"'\s]+)/i,
        /"x-apikey"\s*:\s*"([^"]+)"/i,
        /'x-apikey'\s*:\s*'([^']+)'/i,
        /x-apikey\s*=\s*["']([^"']+)["']/i
      ];

      for (const pattern of patterns) {
        const match = pageContent.match(pattern);
        if (match && match[1]) {
          console.log('✅ 从页面源码中提取到API Key:', match[1]);
          return match[1];
        }
      }

      return null;
    } catch (error) {
      console.error('源码分析失败:', error.message);
      return null;
    }
  }

  async extractFromCookie() {
    console.log('🔍 方法4: 检查Cookie...');
    
    try {
      const cookies = await this.page.cookies();
      
      for (const cookie of cookies) {
        if (cookie.name.toLowerCase().includes('api') || 
            cookie.name.toLowerCase().includes('key') ||
            cookie.name.toLowerCase().includes('token')) {
          console.log('🔍 发现相关Cookie:', cookie.name, cookie.value);
          
          // 检查是否是Base64编码的API Key
          if (this.isValidAPIKey(cookie.value)) {
            console.log('✅ 从Cookie中提取到API Key:', cookie.value);
            return cookie.value;
          }
        }
      }

      return null;
    } catch (error) {
      console.error('Cookie检查失败:', error.message);
      return null;
    }
  }

  async extractFromJavaScript() {
    console.log('🔍 方法5: 检查JavaScript变量...');
    
    try {
      const apiKey = await this.page.evaluate(() => {
        // 检查全局变量
        const globalVars = [
          'window.x_apikey',
          'window.apiKey',
          'window.api_key',
          'window.oklink_api_key',
          'window.oklink_apikey'
        ];

        for (const varPath of globalVars) {
          try {
            const value = eval(varPath);
            if (value && typeof value === 'string') {
              return value;
            }
          } catch (e) {
            // 忽略错误
          }
        }

        // 检查页面上的script标签
        const scripts = document.querySelectorAll('script');
        for (const script of scripts) {
          const content = script.textContent || script.innerHTML;
          if (content.includes('x-apikey') || content.includes('apiKey')) {
            const match = content.match(/x-apikey["\s]*:["\s]*([^"'\s]+)/i) ||
                         content.match(/apiKey["\s]*:["\s]*([^"'\s]+)/i);
            if (match && match[1]) {
              return match[1];
            }
          }
        }

        return null;
      });

      if (apiKey) {
        console.log('✅ 从JavaScript中提取到API Key:', apiKey);
        return apiKey;
      }

      return null;
    } catch (error) {
      console.error('JavaScript检查失败:', error.message);
      return null;
    }
  }

  isValidAPIKey(key) {
    if (!key || typeof key !== 'string') return false;
    
    // 检查是否是Base64编码
    try {
      const decoded = atob(key);
      return decoded.length > 0;
    } catch (e) {
      return false;
    }
  }

  async close() {
    if (this.browser) {
      await this.browser.close();
    }
  }
}

export default APIKeyExtractor;
